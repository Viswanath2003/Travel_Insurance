# Crow's Foot ER Diagram — Travel Insurance Platform
> Render with: VS Code + Mermaid Preview extension | mermaid.live | GitHub native rendering

---

## About These Diagrams

**`ER_DIAGRAM_DBDIAGRAM.dbml`** — Upload to [dbdiagram.io](https://dbdiagram.io) to render a full interactive Crow's Foot ER diagram of all 82 tables across 11 PostgreSQL schemas with cross-schema FK annotations. Supports PNG/PDF export.

**`ER_DIAGRAM.md`** (this file) — Mermaid ER diagrams split per schema/service boundary. Render in VS Code (Mermaid Preview extension), GitHub (native), or [mermaid.live](https://mermaid.live). 82 tables, 11 schemas, sourced directly from V02–V12 DDL files.

---

## 1. Schema-Level Overview (Inter-Service Dependencies)

```mermaid
erDiagram
    INS_AUTH {
        string users PK
        string customer_profiles FK
        string user_sessions FK
    }
    INS_PRODUCT {
        string insurance_products PK
        string plans FK
        string coverages FK
    }
    INS_RULE {
        string rule_definitions PK
        bigint execution_logs FK
        string risk_routing_config FK
    }
    INS_POLICY {
        string quotes PK
        string policies FK
        string policy_agent_bindings FK
    }
    INS_UNDERWRITING {
        string uw_cases PK
    }
    INS_CLAIMS {
        string claims PK
        string claim_decisions FK
        string claim_payments FK
    }
    INS_FIELD {
        string field_assignments PK
        string field_reports FK
        string field_evidence_documents FK
    }
    INS_DOCUMENT {
        string document_templates PK
        string generated_documents FK
    }
    INS_NOTIFICATION {
        string notification_templates PK
        string notifications FK
    }
    INS_AUDIT {
        bigint audit_logs PK
    }
    INS_WORKFLOW {
        string workflow_definitions PK
        string risk_routing_config FK
        string platform_configurations FK
    }

    INS_AUTH         ||--o{ INS_POLICY         : "customer_id (via API)"
    INS_PRODUCT      ||--o{ INS_POLICY         : "plan_id (via API)"
    INS_RULE         ||--o{ INS_POLICY         : "risk score (via API)"
    INS_WORKFLOW     ||--o{ INS_POLICY         : "routing config (via API)"
    INS_POLICY       ||--o{ INS_UNDERWRITING   : "policy_id (via API)"
    INS_POLICY       ||--o{ INS_CLAIMS         : "policy snapshot (via API)"
    INS_CLAIMS       ||--o{ INS_FIELD          : "claim_id (via API)"
    INS_DOCUMENT     ||--o{ INS_POLICY         : "policy schedule PDF (via API)"
    INS_NOTIFICATION ||--o{ INS_POLICY         : "events (via API)"
    INS_NOTIFICATION ||--o{ INS_CLAIMS         : "events (via API)"
    INS_AUDIT        ||--o{ INS_AUTH           : "auth events (append-only)"
    INS_AUDIT        ||--o{ INS_POLICY         : "policy events (append-only)"
    INS_AUDIT        ||--o{ INS_CLAIMS         : "claim events (append-only)"
```

---

## 2. ins_auth — Authentication & Identity

```mermaid
erDiagram
    users {
        uuid id PK
        varchar username UK
        varchar email UK
        varchar mobile
        varchar full_name
        varchar password_hash
        varchar customer_type
        varchar status
        smallint failed_login_attempts
        timestamptz locked_until
        timestamptz last_login_at
        boolean email_verified
        boolean mobile_verified
        varchar profile_photo_path
        timestamptz created_at
        timestamptz updated_at
        bigint version
    }

    customer_profiles {
        uuid id PK
        uuid user_id FK "UNIQUE"
        date date_of_birth
        varchar gender
        char nationality
        varchar passport_number
        date passport_expiry_date
        varchar address_line1
        varchar address_line2
        varchar city
        varchar state_province
        varchar postal_code
        char country_code
        varchar emergency_contact_name
        varchar emergency_contact_phone
        varchar occupation
        varchar annual_income_band
        smallint profile_completeness
        timestamptz created_at
        timestamptz updated_at
    }

    profile_change_requests {
        uuid id PK
        uuid submitter_user_id FK
        uuid profile_id FK
        jsonb requested_changes
        varchar status
        uuid reviewed_by
        timestamptz reviewed_at
        text admin_notes
        timestamptz submitted_at
        timestamptz created_at
        timestamptz updated_at
    }

    roles {
        uuid id PK
        varchar role_code UK
        varchar role_name
        text description
        boolean is_system_role
        boolean is_active
        timestamptz created_at
        timestamptz updated_at
    }

    permissions {
        uuid id PK
        varchar permission_code UK
        varchar permission_name
        varchar domain
        text description
        boolean is_active
        timestamptz created_at
    }

    role_permissions {
        uuid id PK
        uuid role_id FK
        uuid permission_id FK
        uuid granted_by
        timestamptz granted_at
    }

    user_roles {
        uuid id PK
        uuid user_id FK
        uuid role_id FK
        uuid assigned_by
        timestamptz assigned_at
        timestamptz effective_from
        timestamptz effective_to
        boolean is_active
    }

    user_sessions {
        uuid id PK
        uuid user_id FK
        varchar refresh_token_hash
        varchar device_info
        varchar ip_address
        timestamptz issued_at
        timestamptz expires_at
        timestamptz revoked_at
        boolean is_revoked
    }

    otp_tokens {
        uuid id PK
        uuid user_id FK
        varchar otp_hash
        varchar purpose
        timestamptz expires_at
        timestamptz used_at
        boolean is_used
        timestamptz created_at
    }

    password_history {
        uuid id PK
        uuid user_id FK
        varchar password_hash
        timestamptz changed_at
    }

    users             ||--o{ user_sessions            : "has sessions"
    users             ||--o{ otp_tokens               : "has OTPs"
    users             ||--o| customer_profiles        : "has profile"
    users             ||--o{ profile_change_requests  : "submits change requests"
    customer_profiles ||--o{ profile_change_requests  : "change tracked via"
    users             ||--o{ user_roles               : "assigned roles via"
    roles             ||--o{ user_roles               : "granted to users via"
    roles             ||--o{ role_permissions         : "grants permissions via"
    permissions       ||--o{ role_permissions         : "granted by"
    users             ||--o{ password_history         : "password history"
```

---

## 3. ins_product — Product Catalog

```mermaid
erDiagram
    product_types {
        uuid id PK
        varchar type_code UK
        varchar type_name
        text description
        boolean is_active
        int sort_order
        timestamptz created_at
        timestamptz updated_at
    }

    insurance_products {
        uuid id PK
        varchar product_code UK
        varchar product_name
        uuid product_type_id FK
        text description
        boolean is_active
        date launch_date
        date discontinue_date
        timestamptz created_at
        timestamptz updated_at
    }

    plans {
        uuid id PK
        varchar plan_code UK
        varchar plan_name
        uuid product_id FK
        numeric base_premium
        numeric daily_rate
        char currency
        int min_trip_days
        int max_trip_days
        int min_traveler_age
        int max_traveler_age
        int max_travelers
        varchar status
        int version
        timestamptz published_at
        timestamptz created_at
        timestamptz updated_at
    }

    plan_versions {
        uuid id PK
        uuid plan_id FK
        int version_number
        jsonb version_data
        text change_summary
        uuid published_by
        timestamptz published_at
    }

    coverage_types {
        uuid id PK
        varchar coverage_code UK
        varchar coverage_name
        varchar coverage_category
        text description
        boolean is_active
        int sort_order
        timestamptz created_at
    }

    plan_coverages {
        uuid id PK
        uuid plan_id FK
        uuid coverage_type_id FK
        numeric min_limit
        numeric max_limit
        numeric default_limit
        numeric limit_step
        char currency
        numeric deductible
        boolean is_mandatory
        boolean is_adjustable
        boolean is_active
    }

    coverage_limit_risk_multipliers {
        uuid id PK
        varchar risk_level UK
        numeric multiplier_value
        boolean is_adjustable_at_risk_level
        text description
        boolean is_active
        uuid updated_by
        timestamptz updated_at
    }

    addons {
        uuid id PK
        varchar addon_code UK
        varchar addon_name
        varchar addon_category
        text description
        varchar pricing_type
        numeric pricing_value
        char currency
        boolean is_active
        int sort_order
        timestamptz created_at
        timestamptz updated_at
    }

    plan_addon_mappings {
        uuid id PK
        uuid plan_id FK
        uuid addon_id FK
        boolean is_active
        timestamptz created_at
    }

    destination_zones {
        uuid id PK
        varchar zone_code UK
        varchar zone_name
        varchar risk_tier
        text description
        boolean is_active
        int sort_order
        timestamptz created_at
    }

    zone_countries {
        uuid id PK
        uuid zone_id FK
        char country_code UK
        varchar country_name
    }

    plan_zone_mappings {
        uuid id PK
        uuid plan_id FK
        uuid zone_id FK
        numeric zone_base_loading_percent
        boolean is_active
    }

    plan_form_config {
        uuid id PK
        uuid product_type_id FK
        varchar field_name
        varchar field_label
        varchar field_type
        boolean is_required
        varchar placeholder_text
        text help_text
        jsonb validation_rules
        jsonb options
        int sort_order
        boolean is_active
        timestamptz created_at
        timestamptz updated_at
    }

    product_types     ||--o{ insurance_products   : "categorizes"
    insurance_products ||--o{ plans               : "has plans"
    plans             ||--o{ plan_versions        : "versioned as"
    plans             ||--o{ plan_coverages       : "includes coverages"
    coverage_types    ||--o{ plan_coverages       : "used in"
    plans             ||--o{ plan_addon_mappings  : "offers addons via"
    addons            ||--o{ plan_addon_mappings  : "available on plans via"
    destination_zones ||--o{ zone_countries       : "contains"
    plans             ||--o{ plan_zone_mappings   : "covers zones via"
    destination_zones ||--o{ plan_zone_mappings   : "covered by plans via"
    product_types     ||--o{ plan_form_config     : "has form config"
```

---

## 4. ins_rule — Rule Engine

```mermaid
erDiagram
    rule_definitions {
        uuid id PK
        varchar rule_code UK
        varchar rule_name
        varchar rule_type
        text description
        int priority
        varchar status
        boolean is_active
        boolean stop_on_match
        int version
        int current_version
        varchar logical_operator
        timestamptz published_at
        date effective_from
        date effective_to
        timestamptz created_at
        timestamptz updated_at
    }

    rule_condition_groups {
        uuid id PK
        uuid rule_id FK
        int group_number
        varchar logical_operator
    }

    rule_conditions {
        uuid id PK
        uuid group_id FK
        varchar field_name
        varchar operator
        varchar field_value
        varchar field_value2
        text value_list
        int sort_order
    }

    rule_actions {
        uuid id PK
        uuid rule_id FK
        varchar action_type
        varchar action_value
        varchar action_description
        int sort_order
    }

    rule_versions {
        uuid id PK
        uuid rule_id FK
        int version_number
        jsonb rule_snapshot
        uuid published_by
        timestamptz published_at
    }

    rule_execution_logs {
        bigint id PK
        uuid execution_batch_id
        uuid rule_id FK
        varchar rule_code
        int rule_version
        varchar context_type
        uuid context_id
        varchar rule_type
        jsonb input_context
        boolean condition_matched
        varchar action_applied
        numeric contribution_value
        numeric running_total
        varchar action_description
        timestamptz evaluated_at
    }

    risk_routing_config {
        uuid id PK
        numeric min_score
        numeric max_score
        varchar route_to UK
        varchar policy_status
        text route_description
        boolean is_active
        int sort_order
        uuid updated_by
        timestamptz updated_at
    }

    rule_definitions      ||--o{ rule_condition_groups : "has condition groups"
    rule_condition_groups ||--o{ rule_conditions       : "has conditions"
    rule_definitions      ||--o{ rule_actions          : "triggers actions"
    rule_definitions      ||--o{ rule_versions         : "versioned as"
    rule_definitions      ||--o{ rule_execution_logs   : "logged in"
```

> **Note:** `rule_execution_logs` uses `BIGSERIAL` PK and is partitioned monthly by `evaluated_at`. `risk_routing_config` is the `ins_rule` copy — same purpose also exists in `ins_workflow` (slightly different columns).

---

## 5. ins_policy — Policy Management

```mermaid
erDiagram
    quotes {
        uuid id PK
        varchar quote_reference UK
        uuid customer_id FK
        uuid product_id FK
        uuid plan_id FK
        varchar plan_code
        int plan_version
        char destination_country_code
        uuid destination_zone_id
        varchar destination_zone_code
        date trip_start_date
        date trip_end_date
        int trip_duration_days
        int num_travelers
        varchar trip_purpose
        numeric total_premium
        char currency
        numeric risk_score
        varchar risk_level
        varchar status
        uuid agent_id
        timestamptz expires_at
        timestamptz created_at
        timestamptz updated_at
    }

    quote_travelers {
        uuid id PK
        uuid quote_id FK
        int traveler_sequence
        varchar full_name
        date date_of_birth
        int age
        varchar age_band
        varchar passport_number
        char nationality
        varchar gender
        boolean is_primary
        boolean has_preexisting_condition
        boolean has_adventure_activity
        numeric individual_risk_score
        numeric individual_premium
    }

    quote_coverage_selections {
        uuid id PK
        uuid quote_id FK
        uuid coverage_type_id FK
        varchar coverage_code
        numeric selected_limit
        numeric base_limit
        numeric limit_premium
        char currency
    }

    quote_addon_selections {
        uuid id PK
        uuid quote_id FK
        uuid addon_id FK
        varchar addon_code
        numeric addon_premium
    }

    quote_premium_breakdown {
        uuid id PK
        uuid quote_id FK "UNIQUE"
        numeric base_premium
        numeric zone_loading
        numeric risk_loading
        numeric age_loading
        numeric duration_loading
        numeric coverage_loading
        numeric addon_premium_total
        numeric discount_amount
        numeric tax_amount
        numeric gross_premium
        numeric net_premium
        jsonb breakdown_json
    }

    quote_snapshots {
        uuid id PK
        uuid quote_id FK "UNIQUE"
        jsonb snapshot_data
        uuid plan_version_id
        jsonb risk_rule_versions
        jsonb premium_rule_versions
        timestamptz snapshotted_at
    }

    policies {
        uuid id PK
        varchar policy_number UK
        uuid quote_id FK
        uuid customer_id FK
        uuid product_id FK
        uuid plan_id FK
        varchar plan_code
        int plan_version
        char destination_country_code
        uuid destination_zone_id
        varchar destination_zone_code
        date trip_start_date
        date trip_end_date
        int trip_duration_days
        int num_travelers
        varchar trip_purpose
        numeric total_premium
        char currency
        numeric risk_score
        varchar risk_level
        varchar status
        timestamptz issue_date
        date expiry_date
        timestamptz cancellation_date
        text cancellation_reason
        uuid parent_policy_id
        int renewal_count
        varchar payment_reference
        timestamptz payment_recorded_at
        uuid policy_wording_id
        int policy_wording_version
        timestamptz created_at
        timestamptz updated_at
        bigint version
    }

    policy_travelers {
        uuid id PK
        uuid policy_id FK
        int traveler_sequence
        varchar full_name
        date date_of_birth
        int age
        varchar age_band
        varchar passport_number
        char nationality
        varchar gender
        varchar contact_number
        boolean is_primary
        boolean has_preexisting_condition
        boolean has_adventure_activity
        numeric individual_risk_score
        numeric individual_premium
        varchar nominee_name
        varchar nominee_relationship
    }

    policy_coverage_details {
        uuid id PK
        uuid policy_id FK
        uuid coverage_type_id FK
        varchar coverage_code
        varchar coverage_name
        numeric coverage_limit
        numeric deductible
        char currency
        boolean is_mandatory
    }

    policy_addon_selections {
        uuid id PK
        uuid policy_id FK
        uuid addon_id FK
        varchar addon_code
        varchar addon_name
        numeric addon_premium
    }

    policy_premium_breakdown {
        uuid id PK
        uuid policy_id FK "UNIQUE"
        numeric base_premium
        numeric zone_loading
        numeric risk_loading
        numeric age_loading
        numeric duration_loading
        numeric coverage_loading
        numeric addon_premium_total
        numeric discount_amount
        numeric tax_amount
        numeric gross_premium
        numeric net_premium
        jsonb breakdown_json
    }

    policy_snapshots {
        uuid id PK
        uuid policy_id FK
        int snapshot_version
        varchar snapshot_type
        jsonb snapshot_data
        timestamptz snapshotted_at
        uuid snapshotted_by
    }

    policy_status_history {
        uuid id PK
        uuid policy_id FK
        varchar from_status
        varchar to_status
        uuid changed_by
        timestamptz changed_at
        text reason
    }

    policy_wordings {
        uuid id PK
        varchar wording_code
        varchar product_type_code
        int version
        varchar title
        text content
        date effective_from
        date effective_to
        boolean is_active
        uuid published_by
        timestamptz published_at
        timestamptz created_at
    }

    policy_agent_bindings {
        uuid id PK
        uuid policy_id FK "UNIQUE"
        uuid agent_user_id FK
        varchar agent_code
        timestamptz bound_at
        numeric commission_rate
        text notes
        timestamptz created_at
    }

    agent_commissions {
        uuid id PK
        uuid policy_id FK "UNIQUE"
        uuid agent_user_id FK
        varchar agent_code
        varchar plan_code
        numeric commission_rate
        numeric net_premium
        numeric commission_amount
        char currency
        varchar status
        uuid approved_by
        timestamptz approved_at
        timestamptz paid_at
        varchar payment_reference
        text notes
        timestamptz created_at
        timestamptz updated_at
    }

    quotes                ||--o{ quote_travelers           : "has travelers"
    quotes                ||--o{ quote_coverage_selections : "has coverage selections"
    quotes                ||--o{ quote_addon_selections    : "has addon selections"
    quotes                ||--o| quote_premium_breakdown   : "has premium breakdown"
    quotes                ||--o| quote_snapshots           : "snapshotted as"
    quotes                ||--o| policies                  : "converts to"
    policies              ||--o{ policy_travelers          : "covers travelers"
    policies              ||--o{ policy_coverage_details   : "has locked coverages"
    policies              ||--o{ policy_addon_selections   : "has locked addons"
    policies              ||--o| policy_premium_breakdown  : "has premium breakdown"
    policies              ||--o{ policy_snapshots          : "snapshotted as"
    policies              ||--o{ policy_status_history     : "tracks state via"
    policies              ||--o| policy_agent_bindings     : "bound by agent via"
    policy_agent_bindings ||--o| agent_commissions         : "earns"
```

> **policy_snapshots** allows multiple snapshots per policy (UNIQUE on `policy_id, snapshot_version`). `snapshot_type` values: `ISSUANCE` | `ENDORSEMENT` | `RENEWAL` | `CANCELLATION`. Policy status has 11 values: `PENDING_PAYMENT` | `PENDING_CO_REVIEW` | `PENDING_UW_L1` | `PENDING_UW_L2` | `UNDER_REVIEW` | `ACTIVE` | `EXPIRED` | `CANCELLED` | `CANCELLATION_REQUESTED` | `REJECTED` | `LAPSED`.

---

## 6. ins_underwriting — Underwriting Review

```mermaid
erDiagram
    uw_cases {
        uuid id PK
        varchar case_reference UK
        uuid policy_id FK
        varchar policy_number
        uuid customer_id FK
        varchar customer_name
        numeric risk_score
        varchar risk_level
        uuid risk_execution_batch_id
        smallint uw_level
        varchar current_state
        uuid assigned_to_user_id FK
        varchar assigned_to_username
        uuid assigned_by_user_id
        timestamptz assigned_at
        int sla_hours
        timestamptz sla_due_at
        boolean sla_breached
        boolean is_locked
        uuid locked_by
        timestamptz locked_at
        numeric premium_loading_percent
        numeric final_premium
        boolean is_active
        timestamptz created_at
        timestamptz updated_at
        bigint version
    }

    uw_case_history {
        uuid id PK
        uuid case_id FK
        varchar from_state
        varchar to_state
        varchar trigger_event
        uuid actor_user_id
        varchar actor_username
        varchar actor_role
        text comments
        timestamptz transitioned_at
    }

    uw_notes {
        uuid id PK
        uuid case_id FK
        varchar note_type
        text note_text
        boolean is_internal
        uuid created_by
        timestamptz created_at
    }

    uw_conditions {
        uuid id PK
        uuid case_id FK
        varchar condition_code
        text condition_text
        date due_date
        boolean is_met
        timestamptz met_at
        uuid met_by
        text verification_notes
        uuid noted_by
        timestamptz created_at
        timestamptz updated_at
    }

    uw_info_requests {
        uuid id PK
        uuid case_id FK
        uuid requested_by
        timestamptz requested_at
        text request_details
        timestamptz response_received_at
        text response_details
        uuid response_submitted_by
        varchar status
    }

    uw_escalations {
        uuid id PK
        uuid case_id FK
        varchar escalation_type
        uuid escalated_by
        timestamptz escalated_at
        text escalation_reason
        uuid assigned_to_l2_user_id
        uuid resolved_by
        timestamptz resolved_at
    }

    uw_sla_config {
        uuid id PK
        varchar risk_level
        smallint uw_level
        int sla_hours
        varchar escalation_notify_roles
        boolean is_active
        uuid updated_by
        timestamptz updated_at
    }

    uw_cases ||--o{ uw_case_history  : "state changes logged in"
    uw_cases ||--o{ uw_notes         : "has notes"
    uw_cases ||--o{ uw_conditions    : "has conditions"
    uw_cases ||--o{ uw_info_requests : "has info requests"
    uw_cases ||--o{ uw_escalations   : "escalated via"
```

> **current_state values:** `NEW` | `ASSIGNED` | `UNDER_REVIEW` | `INFO_REQUESTED` | `INFO_RECEIVED` | `APPROVED` | `APPROVED_WITH_CONDITIONS` | `REJECTED` | `REFERRED_TO_L2` | `L2_UNDER_REVIEW` | `ESCALATED` | `CLOSED`. Partial unique index on `(policy_id) WHERE is_active = TRUE` — one active case per policy.

---

## 7. ins_claims — Claims Processing

```mermaid
erDiagram
    claim_types {
        uuid id PK
        varchar code UK
        varchar name
        text description
        jsonb required_docs
        int default_sla_hours
        boolean is_active
        timestamptz created_at
        timestamptz updated_at
    }

    claims {
        uuid id PK
        varchar claim_reference UK
        uuid policy_id FK
        varchar policy_number
        uuid policy_snapshot_id FK
        uuid customer_id FK
        uuid claim_type_id FK
        varchar claim_type_code
        varchar status
        date incident_date
        text incident_description
        numeric claimed_amount
        numeric approved_amount
        uuid assigned_officer_id FK
        timestamptz sla_due_at
        boolean sla_breached
        text decision_reason
        timestamptz decided_at
        uuid decided_by FK
        varchar decided_by_name
        boolean is_high_value
        boolean field_investigation_required
        varchar priority
        jsonb metadata
        timestamptz created_at
        timestamptz updated_at
        bigint version
    }

    claim_travelers {
        uuid id PK
        uuid claim_id FK
        varchar traveler_name
        varchar age_group
        boolean is_primary_claimant
        timestamptz created_at
    }

    claim_documents {
        uuid id PK
        uuid claim_id FK
        varchar document_type_code
        varchar document_name
        varchar storage_key
        bigint file_size_bytes
        varchar mime_type
        uuid uploaded_by FK
        boolean is_verified
        uuid verified_by
        timestamptz verified_at
        timestamptz created_at
    }

    claim_doc_checklist_config {
        uuid id PK
        uuid claim_type_id FK
        varchar document_type_code
        varchar document_label
        boolean is_mandatory
        smallint display_order
        timestamptz created_at
        timestamptz updated_at
    }

    claim_checklist_status {
        uuid id PK
        uuid claim_id FK
        varchar document_type_code
        boolean is_received
        timestamptz received_at
        text notes
        timestamptz updated_at
    }

    claim_workflow_history {
        bigint id PK
        uuid claim_id FK
        varchar from_status
        varchar to_status
        varchar action_code
        uuid performed_by FK
        varchar performed_by_name
        varchar performed_by_role
        text notes
        timestamptz created_at
    }

    claim_decisions {
        uuid id PK
        uuid claim_id FK
        varchar decision
        numeric partial_amount
        text decision_reason
        uuid decided_by FK
        varchar decided_by_name
        varchar decided_by_role
        timestamptz decided_at
    }

    claim_adjuster_notes {
        uuid id PK
        uuid claim_id FK
        text note_text
        boolean is_internal
        uuid created_by FK
        varchar created_by_name
        timestamptz created_at
        timestamptz updated_at
    }

    claim_payments {
        uuid id PK
        uuid claim_id FK
        numeric payment_amount
        varchar payment_reference
        varchar payment_method
        varchar bank_account_masked
        uuid processed_by FK
        varchar processed_by_name
        timestamptz processed_at
        text notes
    }

    claim_snapshots {
        uuid id PK
        uuid claim_id FK
        varchar snapshot_type
        jsonb snapshot_data
        uuid created_by FK
        timestamptz created_at
    }

    claim_sla_config {
        uuid id PK
        uuid claim_type_id FK
        varchar priority
        int resolution_hours
        int escalation_hours
        boolean is_active
        timestamptz created_at
        timestamptz updated_at
    }

    claim_types ||--o{ claims                    : "categorises"
    claim_types ||--o{ claim_doc_checklist_config : "defines docs for"
    claim_types ||--o{ claim_sla_config           : "has SLA"
    claims      ||--o{ claim_travelers            : "involves"
    claims      ||--o{ claim_documents            : "supported by"
    claims      ||--o{ claim_checklist_status     : "tracks docs via"
    claims      ||--o{ claim_workflow_history     : "state changes logged in"
    claims      ||--o{ claim_decisions            : "decided via"
    claims      ||--o{ claim_adjuster_notes       : "noted in"
    claims      ||--o{ claim_payments             : "settled via"
    claims      ||--o{ claim_snapshots            : "snapshotted as"
```

> **claim_workflow_history** uses `BIGINT GENERATED ALWAYS AS IDENTITY` PK. **claim_payments** allows multiple records per claim (no UNIQUE on claim_id). **claim_snapshots** allows multiple per claim (`snapshot_type`: `SUBMISSION` | `DECISION` | `PAYMENT` | `CLOSURE`). **claim_decisions.decision** values: `APPROVE_FULL` | `APPROVE_PARTIAL` | `DECLINE` | `REOPEN`.

---

## 8. ins_field — Field Investigation

```mermaid
erDiagram
    field_assignments {
        uuid id PK
        varchar assignment_reference UK
        uuid claim_id FK
        varchar claim_reference
        uuid assigned_officer_id FK
        varchar assigned_officer_name
        uuid assigned_by FK
        varchar assigned_by_name
        varchar assignment_status
        varchar priority
        varchar investigation_location
        varchar investigation_type
        timestamptz due_at
        boolean sla_breached
        text notes_for_officer
        timestamptz created_at
        timestamptz updated_at
    }

    field_reports {
        uuid id PK
        uuid assignment_id FK "UNIQUE"
        uuid claim_id FK
        uuid submitted_by FK
        varchar submitted_by_name
        date inspection_date
        varchar location_visited
        boolean claimant_present
        text findings
        varchar recommendation
        text recommendation_notes
        timestamptz submitted_at
        uuid reviewed_by
        timestamptz reviewed_at
        varchar review_outcome
    }

    field_evidence_documents {
        uuid id PK
        uuid report_id FK
        uuid assignment_id FK
        varchar document_type
        varchar document_name
        varchar storage_key
        bigint file_size_bytes
        varchar mime_type
        varchar caption
        uuid uploaded_by FK
        timestamptz created_at
    }

    field_assignments ||--o| field_reports            : "results in"
    field_reports     ||--o{ field_evidence_documents : "has evidence"
    field_assignments ||--o{ field_evidence_documents : "has evidence"
```

> **Assignment status flow:** `PENDING_START` → `IN_PROGRESS` → `REPORT_SUBMITTED` → `COMPLETED` | `CANCELLED`
> **recommendation values:** `APPROVE` | `PARTIAL_APPROVE` | `REJECT` | `FURTHER_INVESTIGATION_NEEDED`
> **review_outcome values:** `ACCEPTED` | `REJECTED` | `NEEDS_REWORK`
> **document_type values:** `PHOTO` | `RECEIPT` | `STATEMENT` | `OTHER`
> **field_evidence_documents.report_id is NOT NULL** — evidence upload requires a submitted report first.

---

## 9. ins_document — Document Generation

```mermaid
erDiagram
    document_templates {
        uuid id PK
        varchar template_code UK
        varchar template_name
        varchar document_category
        text description
        uuid current_version_id
        boolean is_active
        timestamptz created_at
        timestamptz updated_at
    }

    document_template_versions {
        uuid id PK
        uuid template_id FK
        int version_number
        text template_content
        varchar output_format
        boolean is_current
        uuid published_by
        timestamptz published_at
        timestamptz created_at
    }

    generated_documents {
        uuid id PK
        varchar document_reference UK
        uuid template_id FK
        uuid template_version_id FK
        varchar entity_type
        uuid entity_id FK
        varchar entity_reference
        uuid customer_id
        varchar document_name
        varchar storage_key
        bigint file_size_bytes
        varchar mime_type
        uuid generated_by
        jsonb generation_context
        boolean is_latest_version
        timestamptz created_at
    }

    document_versions {
        uuid id PK
        uuid generated_document_id FK
        int version_number
        varchar storage_key
        text reason
        uuid generated_by
        timestamptz created_at
    }

    document_templates         ||--o{ document_template_versions : "versioned as"
    document_templates         ||--o{ generated_documents        : "generates"
    document_template_versions ||--o{ generated_documents        : "used in generation"
    generated_documents        ||--o{ document_versions          : "archived versions"
```

> **document_category values:** `POLICY` | `CLAIM` | `FINANCE` | `SYSTEM`
> **entity_type values:** `POLICY` | `CLAIM` | `QUOTE` | `PAYMENT`
> **output_format values:** `PDF` | `HTML`

---

## 10. ins_notification — Notification System

```mermaid
erDiagram
    notification_templates {
        uuid id PK
        varchar event_code
        varchar title_template
        text body_template
        varchar target_role
        varchar channel
        boolean is_active
        timestamptz created_at
        timestamptz updated_at
    }

    notifications {
        uuid id PK
        varchar notification_ref UK
        uuid template_id FK
        varchar title
        text body
        varchar target_role
        uuid target_user_id
        varchar target_user_email
        varchar entity_type
        uuid entity_id
        varchar entity_reference
        varchar priority
        boolean is_read
        timestamptz read_at
        timestamptz created_at
    }

    notification_delivery_log {
        bigint id PK
        uuid notification_id FK
        varchar channel
        varchar delivery_status
        varchar provider_ref
        smallint attempt_count
        timestamptz last_attempt_at
        timestamptz delivered_at
        text failure_reason
        timestamptz created_at
    }

    notification_templates ||--o{ notifications           : "generates"
    notifications          ||--o{ notification_delivery_log : "delivery tracked in"
```

> **notification_delivery_log** uses `BIGINT GENERATED ALWAYS AS IDENTITY` PK. In-app notifications have no delivery log entries.
> **channel values:** `IN_APP` | `EMAIL` | `SMS` | `PUSH`
> **UNIQUE constraint:** `(event_code, channel)` on notification_templates.
> **delivery_status values:** `PENDING` | `SENT` | `DELIVERED` | `FAILED` | `BOUNCED`

---

## 11. ins_audit — Immutable Audit Log

```mermaid
erDiagram
    audit_logs {
        bigint id PK
        timestamptz event_time
        varchar request_id
        varchar service_name
        varchar action
        uuid actor_user_id
        varchar actor_username
        varchar actor_role
        inet actor_ip
        varchar entity_type
        varchar entity_id
        varchar entity_reference
        jsonb old_values
        jsonb new_values
        varchar result
        text failure_reason
        jsonb metadata
    }
```

> **Note:** `audit_logs` uses `BIGINT GENERATED ALWAYS AS IDENTITY` PK (sequential ordering). No FK constraints by design — audit records survive entity deletion. Row-level security (RLS) grants `ins_audit_role` INSERT + SELECT only. No `updated_at` column (append-only by design). **Not partitioned** (unlike `rule_execution_logs`).

---

## 12. ins_workflow — Shared Infrastructure

```mermaid
erDiagram
    workflow_definitions {
        uuid id PK
        varchar workflow_code UK
        varchar workflow_name
        varchar domain
        text description
        boolean is_active
        int version
        timestamptz created_at
        timestamptz updated_at
    }

    workflow_states {
        uuid id PK
        uuid workflow_id FK
        varchar state_code
        varchar state_name
        varchar state_type
        boolean is_active
        smallint display_order
        timestamptz created_at
    }

    workflow_transitions {
        uuid id PK
        uuid workflow_id FK
        uuid from_state_id FK
        uuid to_state_id FK
        varchar transition_code
        varchar transition_name
        varchar required_role
        varchar required_permission
        text condition_expression
        boolean is_active
        timestamptz created_at
    }

    risk_routing_config {
        uuid id PK
        varchar routing_band UK
        int score_min
        int score_max
        varchar target_status
        text notify_roles
        varchar description
        boolean is_active
        timestamptz effective_from
        timestamptz effective_to
        timestamptz created_at
        timestamptz updated_at
    }

    coverage_limit_risk_multipliers {
        uuid id PK
        varchar risk_level UK
        numeric multiplier
        varchar description
        boolean is_active
        timestamptz created_at
        timestamptz updated_at
    }

    platform_configurations {
        uuid id PK
        varchar config_key UK
        text config_value
        varchar value_type
        varchar description
        varchar group_name
        boolean is_active
        timestamptz created_at
        timestamptz updated_at
    }

    workflow_definitions ||--o{ workflow_states      : "has states"
    workflow_definitions ||--o{ workflow_transitions  : "has transitions"
    workflow_states      ||--o{ workflow_transitions  : "from state (from_state_id)"
    workflow_states      ||--o{ workflow_transitions  : "to state (to_state_id)"
```

> **workflow_transitions.from_state_id** and **to_state_id** are both UUID FKs to `workflow_states.id` — two relationship lines from `workflow_states`.
> **domain values:** `POLICY` | `UNDERWRITING` | `CLAIMS` | `FIELD`
> **state_type values:** `INITIAL` | `INTERMEDIATE` | `TERMINAL`
> **risk_routing_config** and **coverage_limit_risk_multipliers** also exist in `ins_rule` and `ins_product` respectively (same purpose, slightly different columns — the workflow copies are the authoritative admin-configurable versions).

---

## 13. Cross-Schema Logical Relationships (via API — no DB FK)

```mermaid
erDiagram
    AUTH_users {
        uuid id PK
        varchar email UK
        varchar status
        varchar customer_type
    }
    PRODUCT_plans {
        uuid id PK
        varchar plan_code UK
        numeric daily_rate
        varchar status
    }
    RULE_risk_routing_config {
        uuid id PK
        numeric min_score
        numeric max_score
        varchar route_to UK
        varchar policy_status
    }
    POLICY_quotes {
        uuid id PK
        varchar quote_reference UK
        uuid customer_id FK
        uuid plan_id FK
        numeric risk_score
        varchar status
    }
    POLICY_policies {
        uuid id PK
        uuid quote_id FK
        varchar policy_number UK
        varchar status
        varchar plan_code
    }
    POLICY_policy_snapshots {
        uuid id PK
        uuid policy_id FK
        int snapshot_version
        varchar snapshot_type
        jsonb snapshot_data
    }
    UW_uw_cases {
        uuid id PK
        uuid policy_id FK
        varchar current_state
        numeric risk_score
        boolean is_active
    }
    CLAIMS_claims {
        uuid id PK
        uuid policy_id FK
        uuid policy_snapshot_id FK
        varchar claim_reference UK
        varchar status
    }
    CLAIMS_claim_snapshots {
        uuid id PK
        uuid claim_id FK
        varchar snapshot_type
        jsonb snapshot_data
    }
    FIELD_field_assignments {
        uuid id PK
        uuid claim_id FK
        varchar assignment_status
    }
    NOTIF_notifications {
        uuid id PK
        varchar target_role
        uuid target_user_id
        varchar entity_type
        uuid entity_id
    }

    AUTH_users               ||--o{ POLICY_quotes           : "customer places (customer_id)"
    PRODUCT_plans            ||--o{ POLICY_quotes           : "priced by (plan_id)"
    RULE_risk_routing_config ||--o{ POLICY_policies         : "routes to status"
    POLICY_quotes            ||--o| POLICY_policies         : "converts to"
    POLICY_policies          ||--o{ POLICY_policy_snapshots : "snapshotted as"
    POLICY_policies          ||--o{ UW_uw_cases             : "reviewed in (policy_id)"
    POLICY_policy_snapshots  ||--o{ CLAIMS_claims           : "referenced by (policy_snapshot_id)"
    CLAIMS_claims            ||--o{ CLAIMS_claim_snapshots  : "snapshotted as"
    CLAIMS_claims            ||--o{ FIELD_field_assignments : "investigated via (claim_id)"
    AUTH_users               ||--o{ NOTIF_notifications     : "receives (target_user_id)"
```

---

## Legend

| Symbol | Meaning |
|--------|---------|
| `\|\|` | Exactly one (mandatory) |
| `o\|` | Zero or one (optional) |
| `o{` | Zero or many |
| `\|{` | One or many |
| `--` | Identifying relationship |
| `PK` | Primary Key |
| `FK` | Foreign Key |
| `UK` | Unique Key / Unique Constraint |
