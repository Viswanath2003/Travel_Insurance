-- =============================================================================
-- V10__notification_schema.sql
-- Schema: ins_notification
-- Service: notification-service
-- Description: Notification templates, in-app notifications, and delivery log.
--              Supports role-based notifications (addNotification('ROLE_X', ...))
--              as implemented in webapp/shared/utils.js.
--
-- NEW vs MySQL:
--   + notifications.target_role  — role-based targeting (ROLE_CUSTOMER, ROLE_ADMIN, etc.)
--   + notifications.target_user_email — for per-customer notifications (webapp: userEmail field)
--   + notifications.read_at  — timestamp when notification was read
--   + All TINYINT(1) → BOOLEAN, DATETIME → TIMESTAMPTZ
--   + VARCHAR(36) IDs → UUID
-- =============================================================================

SET search_path = ins_notification, public;

-- =============================================================================
-- notification_templates
-- Reusable message templates with variable placeholders.
-- event_code: unique identifier used by services to trigger notifications.
-- =============================================================================
CREATE TABLE ins_notification.notification_templates (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    event_code          VARCHAR(80)     NOT NULL,
                        -- POLICY_ACTIVE | POLICY_APPROVED | POLICY_REJECTED
                        -- CLAIM_SUBMITTED | CLAIM_APPROVED | CLAIM_SETTLED
                        -- UW_ESCALATED | FIELD_ASSIGNED | PREMIUM_RECEIVED
                        -- PROFILE_UPDATE_REQUEST | RENEWAL_REMINDER | etc.
    title_template      VARCHAR(200)    NOT NULL,
    body_template       TEXT            NOT NULL,
    target_role         VARCHAR(60)     NULL,
                        -- NULL = determined at runtime; set for fixed-role templates
    channel             VARCHAR(20)     NOT NULL DEFAULT 'IN_APP',
                        -- IN_APP | EMAIL | SMS | PUSH
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_notification_templates PRIMARY KEY (id),
    CONSTRAINT uq_notification_template_event UNIQUE (event_code, channel),
    CONSTRAINT chk_notif_channel CHECK (channel IN ('IN_APP','EMAIL','SMS','PUSH'))
);

CREATE TRIGGER trg_notif_templates_updated_at
    BEFORE UPDATE ON ins_notification.notification_templates
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

-- =============================================================================
-- notifications
-- Individual notification records.
-- Webapp: addNotification(role, {title, body, userEmail?}) → notification per role
-- target_role: maps to ROLE_CUSTOMER, ROLE_ADMIN, ROLE_UNDERWRITER_L1, etc.
-- target_user_id: set when notification is for a specific user (not role-broadcast)
-- target_user_email: denormalized email for customer-specific routing
-- =============================================================================
CREATE TABLE ins_notification.notifications (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    notification_ref    VARCHAR(30)     NOT NULL,
    template_id         UUID            NULL,
    title               VARCHAR(200)    NOT NULL,
    body                TEXT            NOT NULL,
    target_role         VARCHAR(60)     NOT NULL,
                        -- ROLE_CUSTOMER | ROLE_AGENT | ROLE_UNDERWRITER_L1
                        -- ROLE_UNDERWRITER_L2 | ROLE_CLAIMS_OFFICER
                        -- ROLE_FIELD_OFFICER | ROLE_FINANCE | ROLE_ADMIN
                        -- ROLE_RELATIONSHIP_MANAGER
    target_user_id      UUID            NULL,
                        -- Set for user-specific notifications
    target_user_email   VARCHAR(150)    NULL,
                        -- Denormalized for customer-specific routing
    entity_type         VARCHAR(30)     NULL,
                        -- POLICY | CLAIM | UW_CASE | PROFILE | PAYMENT
    entity_id           UUID            NULL,
    entity_reference    VARCHAR(30)     NULL,
    priority            VARCHAR(10)     NOT NULL DEFAULT 'NORMAL',
                        -- LOW | NORMAL | HIGH | URGENT
    is_read             BOOLEAN         NOT NULL DEFAULT FALSE,
    read_at             TIMESTAMPTZ     NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_notifications PRIMARY KEY (id),
    CONSTRAINT uq_notification_ref UNIQUE (notification_ref),
    CONSTRAINT fk_notifications_template FOREIGN KEY (template_id)
        REFERENCES ins_notification.notification_templates(id),
    CONSTRAINT chk_notification_priority CHECK (priority IN ('LOW','NORMAL','HIGH','URGENT')),
    CONSTRAINT chk_notif_role CHECK (target_role IN (
        'ROLE_CUSTOMER','ROLE_AGENT','ROLE_UNDERWRITER_L1','ROLE_UNDERWRITER_L2',
        'ROLE_CLAIMS_OFFICER','ROLE_FIELD_OFFICER','ROLE_FINANCE','ROLE_ADMIN',
        'ROLE_RELATIONSHIP_MANAGER'
    ))
);

CREATE INDEX idx_notifications_role         ON ins_notification.notifications (target_role);
CREATE INDEX idx_notifications_user         ON ins_notification.notifications (target_user_id) WHERE target_user_id IS NOT NULL;
CREATE INDEX idx_notifications_email        ON ins_notification.notifications (target_user_email) WHERE target_user_email IS NOT NULL;
CREATE INDEX idx_notifications_unread       ON ins_notification.notifications (target_role, is_read) WHERE is_read = FALSE;
CREATE INDEX idx_notifications_entity       ON ins_notification.notifications (entity_type, entity_id) WHERE entity_id IS NOT NULL;
CREATE INDEX idx_notifications_created      ON ins_notification.notifications (created_at DESC);

-- =============================================================================
-- notification_delivery_log
-- Tracks delivery attempts per channel (EMAIL, SMS, PUSH).
-- In-app notifications do not have delivery log entries.
-- =============================================================================
CREATE TABLE ins_notification.notification_delivery_log (
    id                  BIGINT          GENERATED ALWAYS AS IDENTITY,
    notification_id     UUID            NOT NULL,
    channel             VARCHAR(20)     NOT NULL,
    delivery_status     VARCHAR(20)     NOT NULL DEFAULT 'PENDING',
                        -- PENDING | SENT | DELIVERED | FAILED | BOUNCED
    provider_ref        VARCHAR(100)    NULL,
                        -- External provider message ID
    attempt_count       SMALLINT        NOT NULL DEFAULT 0,
    last_attempt_at     TIMESTAMPTZ     NULL,
    delivered_at        TIMESTAMPTZ     NULL,
    failure_reason      TEXT            NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_notif_delivery_log PRIMARY KEY (id),
    CONSTRAINT fk_notif_delivery_notif FOREIGN KEY (notification_id)
        REFERENCES ins_notification.notifications(id),
    CONSTRAINT chk_delivery_status CHECK (delivery_status IN (
        'PENDING','SENT','DELIVERED','FAILED','BOUNCED'
    )),
    CONSTRAINT chk_delivery_channel CHECK (channel IN ('IN_APP','EMAIL','SMS','PUSH'))
);

CREATE INDEX idx_notif_delivery_notif ON ins_notification.notification_delivery_log (notification_id);
CREATE INDEX idx_notif_delivery_status ON ins_notification.notification_delivery_log (delivery_status) WHERE delivery_status IN ('PENDING','FAILED');
