-- =============================================================================
-- V04__rule_engine_schema.sql
-- Schema: ins_rule
-- Service: rule-engine-service
-- Description: Custom DB-driven rule engine. No Drools, no Camunda, no AI/ML.
--              All rules are Admin-configurable via UI-033 (Premium Rules)
--              and UI-034 (Risk Rules).
--
-- NEW vs MySQL:
--   + rule_definitions.is_active, stop_on_match, current_version columns
--   + rule_type enum corrected to match backend: RISK_SCORING, PREMIUM_LOADING,
--     DISCOUNT, ELIGIBILITY, ROUTING, CLAIMS_AUTO_DECISION
--   + risk_routing_config — NEW: configurable routing thresholds (was hardcoded in webapp)
--   + rule_execution_logs: BIGSERIAL, partitioned monthly, JSONB → with GIN index
--   + All TINYINT(1) → BOOLEAN, DATETIME → TIMESTAMPTZ, JSON → JSONB
-- =============================================================================

SET search_path = ins_rule, public;

-- =============================================================================
-- rule_definitions
-- Master rule registry. Each rule has a type, priority, and lifecycle version.
-- Rules go through DRAFT → PUBLISHED lifecycle with versioning.
-- is_active: quick toggle without changing status
-- stop_on_match: if true, engine stops evaluating further rules of same type
-- current_version: points to the active rule_versions row
-- =============================================================================
CREATE TABLE ins_rule.rule_definitions (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    rule_code           VARCHAR(100)    NOT NULL,
    rule_name           VARCHAR(200)    NOT NULL,
    rule_type           VARCHAR(30)     NOT NULL,
                        -- RISK_SCORING | PREMIUM_LOADING | DISCOUNT | ELIGIBILITY
                        -- ROUTING | CLAIMS_AUTO_DECISION
    description         TEXT            NULL,
    priority            INT             NOT NULL DEFAULT 100,
                        -- Lower number = evaluated first
    status              VARCHAR(20)     NOT NULL DEFAULT 'DRAFT',
                        -- DRAFT | PUBLISHED | SUPERSEDED | INACTIVE
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    stop_on_match       BOOLEAN         NOT NULL DEFAULT FALSE,
                        -- If TRUE, engine stops evaluating further rules of same type after this match
    version             INT             NOT NULL DEFAULT 1,
    current_version     INT             NOT NULL DEFAULT 1,
                        -- Points to the active version in rule_versions (same as version unless branched)
    logical_operator    VARCHAR(5)      NOT NULL DEFAULT 'AND',
                        -- AND | OR (how condition groups combine)
    published_at        TIMESTAMPTZ     NULL,
    published_by        UUID            NULL,
    effective_from      DATE            NULL,
    effective_to        DATE            NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    created_by          UUID            NULL,

    CONSTRAINT pk_rule_definitions PRIMARY KEY (id),
    CONSTRAINT uq_rule_code_version UNIQUE (rule_code, version),
    CONSTRAINT chk_rule_type CHECK (rule_type IN (
        'RISK_SCORING','PREMIUM_LOADING','DISCOUNT','ELIGIBILITY',
        'ROUTING','CLAIMS_AUTO_DECISION'
    )),
    CONSTRAINT chk_rule_status CHECK (status IN (
        'DRAFT','PUBLISHED','SUPERSEDED','INACTIVE'
    )),
    CONSTRAINT chk_rule_logical_op CHECK (logical_operator IN ('AND','OR'))
);

CREATE INDEX idx_rd_type_status ON ins_rule.rule_definitions (rule_type, status);
CREATE INDEX idx_rd_priority ON ins_rule.rule_definitions (priority);
-- Partial index: only active published rules are queried at runtime
CREATE INDEX idx_rd_active_published ON ins_rule.rule_definitions (rule_type, priority)
    WHERE status = 'PUBLISHED' AND is_active = TRUE;

CREATE TRIGGER trg_rule_definitions_updated_at
    BEFORE UPDATE ON ins_rule.rule_definitions
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_rule.rule_definitions IS 'Master rule registry. stop_on_match controls engine short-circuit. current_version references active rule_versions row.';
COMMENT ON COLUMN ins_rule.rule_definitions.stop_on_match IS 'If TRUE, rule engine stops evaluating further rules of same type once this rule matches.';
COMMENT ON COLUMN ins_rule.rule_definitions.current_version IS 'Active version number. Matches version in rule_versions for the current published snapshot.';

-- =============================================================================
-- rule_condition_groups
-- Groups conditions with a logical operator (AND/OR within the group).
-- A rule can have multiple groups, combined by the rule's logical_operator.
-- =============================================================================
CREATE TABLE ins_rule.rule_condition_groups (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    rule_id             UUID            NOT NULL,
    group_number        INT             NOT NULL DEFAULT 1,
    logical_operator    VARCHAR(5)      NOT NULL DEFAULT 'AND',

    CONSTRAINT pk_rule_condition_groups PRIMARY KEY (id),
    CONSTRAINT fk_rcg_rule FOREIGN KEY (rule_id) REFERENCES ins_rule.rule_definitions (id) ON DELETE CASCADE,
    CONSTRAINT chk_rcg_logical_op CHECK (logical_operator IN ('AND','OR'))
);

CREATE INDEX idx_rcg_rule_id ON ins_rule.rule_condition_groups (rule_id);

COMMENT ON TABLE ins_rule.rule_condition_groups IS 'Condition group within a rule. Multiple groups combined by rule.logical_operator.';

-- =============================================================================
-- rule_conditions
-- Individual condition: field OPERATOR value.
-- field_name uses dot-notation to address nested context fields:
--   "traveler.age", "destination.risk_tier", "trip.duration_days",
--   "policy.risk_level", "claim.amount", "traveler.has_preexisting_condition"
-- =============================================================================
CREATE TABLE ins_rule.rule_conditions (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    group_id        UUID            NOT NULL,
    field_name      VARCHAR(200)    NOT NULL,
    operator        VARCHAR(15)     NOT NULL,
    field_value     VARCHAR(500)    NULL,
    field_value2    VARCHAR(500)    NULL,   -- For BETWEEN operator (upper bound)
    value_list      TEXT            NULL,   -- For IN / NOT_IN (comma-separated)
    sort_order      INT             NOT NULL DEFAULT 0,

    CONSTRAINT pk_rule_conditions PRIMARY KEY (id),
    CONSTRAINT fk_rc_group FOREIGN KEY (group_id) REFERENCES ins_rule.rule_condition_groups (id) ON DELETE CASCADE,
    CONSTRAINT chk_rc_operator CHECK (operator IN (
        'EQ','NEQ','GT','GTE','LT','LTE','IN','NOT_IN',
        'BETWEEN','IS_NULL','IS_NOT_NULL','CONTAINS'
    ))
);

CREATE INDEX idx_rc_group_id ON ins_rule.rule_conditions (group_id);

COMMENT ON TABLE ins_rule.rule_conditions IS 'Individual condition within a group. field_name uses dot-notation (traveler.age).';

-- =============================================================================
-- rule_actions
-- What happens when a rule matches. Multiple actions per rule, in sort_order.
-- =============================================================================
CREATE TABLE ins_rule.rule_actions (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    rule_id             UUID            NOT NULL,
    action_type         VARCHAR(30)     NOT NULL,
    action_value        VARCHAR(200)    NOT NULL,
    action_description  VARCHAR(300)    NULL,
    sort_order          INT             NOT NULL DEFAULT 0,

    CONSTRAINT pk_rule_actions PRIMARY KEY (id),
    CONSTRAINT fk_ra_rule FOREIGN KEY (rule_id) REFERENCES ins_rule.rule_definitions (id) ON DELETE CASCADE,
    CONSTRAINT chk_ra_action_type CHECK (action_type IN (
        'ADD_SCORE','SUBTRACT_SCORE','SET_SCORE',
        'MULTIPLY_PREMIUM','ADD_FLAT_AMOUNT','ADD_PERCENT','SUBTRACT_PERCENT',
        'SET_RISK_LEVEL','ROUTE_TO_UW','BLOCK_ELIGIBILITY',
        'AUTO_APPROVE','AUTO_DECLINE'
    ))
);

CREATE INDEX idx_ra_rule_id ON ins_rule.rule_actions (rule_id);

COMMENT ON TABLE ins_rule.rule_actions IS 'Actions executed when a rule matches. Multiple actions per rule in sort_order sequence.';

-- =============================================================================
-- rule_versions
-- Immutable snapshot of each rule at publish time.
-- Policy snapshots store which rule_version_id was active at quote time.
-- =============================================================================
CREATE TABLE ins_rule.rule_versions (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    rule_id         UUID            NOT NULL,
    version_number  INT             NOT NULL,
    rule_snapshot   JSONB           NOT NULL,
                    -- Complete rule: definition + condition groups + conditions + actions
    published_by    UUID            NULL,
    published_at    TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_rule_versions PRIMARY KEY (id),
    CONSTRAINT uq_rule_version UNIQUE (rule_id, version_number),
    CONSTRAINT fk_rv_rule FOREIGN KEY (rule_id) REFERENCES ins_rule.rule_definitions (id)
);

CREATE INDEX idx_rv_rule_id ON ins_rule.rule_versions (rule_id);
-- GIN index on rule_snapshot for fast JSONB queries
CREATE INDEX idx_rv_snapshot_gin ON ins_rule.rule_versions USING GIN (rule_snapshot);

-- Prevent updates to rule_versions (immutable audit trail)
CREATE TRIGGER trg_rule_versions_immutable
    BEFORE UPDATE ON ins_rule.rule_versions
    FOR EACH ROW EXECUTE FUNCTION ins_common.prevent_update();

COMMENT ON TABLE ins_rule.rule_versions IS 'Immutable rule snapshots at publish time. Enables auditability: which rule version priced this policy?';

-- =============================================================================
-- rule_execution_logs (PARTITIONED by month)
-- Records EVERY rule evaluation — both matched and unmatched.
-- This is the foundation of the explainability UI (UI-018, UI-035).
-- execution_batch_id groups all rules evaluated in a single engine call.
--
-- Partitioning: RANGE by evaluated_at (monthly) to support efficient
-- retention and archival. New partitions must be created monthly.
--
-- id: BIGSERIAL for high-volume insert performance (not UUID)
-- =============================================================================
CREATE TABLE ins_rule.rule_execution_logs (
    id                      BIGSERIAL       NOT NULL,
    execution_batch_id      UUID            NOT NULL,
    rule_id                 UUID            NULL,
    rule_code               VARCHAR(100)    NULL,
    rule_version            INT             NULL,
    context_type            VARCHAR(20)     NOT NULL,
                            -- QUOTE | POLICY | CLAIM | PREVIEW
    context_id              UUID            NULL,
    rule_type               VARCHAR(30)     NOT NULL,
    input_context           JSONB           NULL,
                            -- Rule evaluation context snapshot
    condition_matched       BOOLEAN         NOT NULL,
    action_applied          VARCHAR(200)    NULL,
    contribution_value      NUMERIC(15,4)   NULL,
    running_total           NUMERIC(15,4)   NULL,
    action_description      VARCHAR(500)    NULL,
    evaluated_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_rule_exec_logs PRIMARY KEY (id, evaluated_at),
    CONSTRAINT chk_rel_context_type CHECK (context_type IN (
        'QUOTE','POLICY','CLAIM','PREVIEW'
    ))
) PARTITION BY RANGE (evaluated_at);

-- Create initial monthly partitions (2026)
CREATE TABLE ins_rule.rule_execution_logs_2026_01
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2026-01-01') TO ('2026-02-01');

CREATE TABLE ins_rule.rule_execution_logs_2026_02
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2026-02-01') TO ('2026-03-01');

CREATE TABLE ins_rule.rule_execution_logs_2026_03
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2026-03-01') TO ('2026-04-01');

CREATE TABLE ins_rule.rule_execution_logs_2026_04
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2026-04-01') TO ('2026-05-01');

CREATE TABLE ins_rule.rule_execution_logs_2026_05
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2026-05-01') TO ('2026-06-01');

CREATE TABLE ins_rule.rule_execution_logs_2026_06
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2026-06-01') TO ('2026-07-01');

CREATE TABLE ins_rule.rule_execution_logs_2026_07
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2026-07-01') TO ('2026-08-01');

CREATE TABLE ins_rule.rule_execution_logs_2026_08
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');

CREATE TABLE ins_rule.rule_execution_logs_2026_09
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2026-09-01') TO ('2026-10-01');

CREATE TABLE ins_rule.rule_execution_logs_2026_10
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2026-10-01') TO ('2026-11-01');

CREATE TABLE ins_rule.rule_execution_logs_2026_11
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2026-11-01') TO ('2026-12-01');

CREATE TABLE ins_rule.rule_execution_logs_2026_12
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2026-12-01') TO ('2027-01-01');

CREATE TABLE ins_rule.rule_execution_logs_2027_01
    PARTITION OF ins_rule.rule_execution_logs
    FOR VALUES FROM ('2027-01-01') TO ('2027-02-01');

-- Indexes on partitioned table (applies to all partitions)
CREATE INDEX idx_rel_batch_id ON ins_rule.rule_execution_logs (execution_batch_id);
CREATE INDEX idx_rel_context ON ins_rule.rule_execution_logs (context_type, context_id);
CREATE INDEX idx_rel_rule_id ON ins_rule.rule_execution_logs (rule_id) WHERE rule_id IS NOT NULL;
CREATE INDEX idx_rel_evaluated_at ON ins_rule.rule_execution_logs (evaluated_at);
-- GIN index on input_context JSONB
CREATE INDEX idx_rel_context_gin ON ins_rule.rule_execution_logs USING GIN (input_context)
    WHERE input_context IS NOT NULL;

COMMENT ON TABLE ins_rule.rule_execution_logs IS
    'Partitioned (monthly RANGE) rule evaluation log. BIGSERIAL id. Every evaluation stored.
     Add new partition at start of each month:
     CREATE TABLE rule_execution_logs_YYYY_MM PARTITION OF rule_execution_logs
     FOR VALUES FROM (''YYYY-MM-01'') TO (''YYYY-MM+1-01'');';

-- =============================================================================
-- risk_routing_config
-- NEW: Configurable risk score routing thresholds.
-- Previously hardcoded in webapp JavaScript — now DB-driven and Admin-configurable.
--
-- Default configuration (seeded in V21):
--   min=0,  max=30  → route_to=AUTO_APPROVE    (policy.status = ACTIVE)
--   min=31, max=50  → route_to=CO_REVIEW       (policy.status = PENDING_CO_REVIEW)
--   min=51, max=70  → route_to=UW_L1           (policy.status = PENDING_UW_L1)
--   min=71, max=999 → route_to=UW_L2           (policy.status = PENDING_UW_L2)
-- =============================================================================
CREATE TABLE ins_rule.risk_routing_config (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    min_score           NUMERIC(5,2)    NOT NULL,
    max_score           NUMERIC(5,2)    NOT NULL,
    route_to            VARCHAR(30)     NOT NULL,
                        -- AUTO_APPROVE | CO_REVIEW | UW_L1 | UW_L2
    policy_status       VARCHAR(30)     NOT NULL,
                        -- ACTIVE | PENDING_CO_REVIEW | PENDING_UW_L1 | PENDING_UW_L2
    route_description   TEXT            NULL,
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    sort_order          INT             NOT NULL DEFAULT 0,
    updated_by          UUID            NULL,
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_risk_routing_config PRIMARY KEY (id),
    CONSTRAINT uq_rrc_route_to UNIQUE (route_to),
    CONSTRAINT chk_rrc_route_to CHECK (route_to IN (
        'AUTO_APPROVE','CO_REVIEW','UW_L1','UW_L2'
    )),
    CONSTRAINT chk_rrc_policy_status CHECK (policy_status IN (
        'ACTIVE','PENDING_CO_REVIEW','PENDING_UW_L1','PENDING_UW_L2'
    )),
    CONSTRAINT chk_rrc_score_range CHECK (max_score >= min_score AND min_score >= 0)
);

CREATE TRIGGER trg_risk_routing_config_updated_at
    BEFORE UPDATE ON ins_rule.risk_routing_config
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_rule.risk_routing_config IS
    'Risk score routing thresholds. Previously hardcoded in webapp — now DB-configurable.
     Admin can adjust score bands without code deployment.
     route_to maps to policy.status and underwriting queue assignment.';
