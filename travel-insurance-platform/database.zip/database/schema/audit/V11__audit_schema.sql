-- =============================================================================
-- V11__audit_schema.sql
-- Schema: ins_audit
-- Service: audit-service
-- Description: Immutable audit log for all platform actions.
--              The ins_audit_role has INSERT + SELECT only — no UPDATE/DELETE.
--              No triggers or updated_at column (intentionally append-only).
--
-- DESIGN DECISIONS:
--   + id: BIGINT GENERATED ALWAYS AS IDENTITY (not UUID) — sequential ordering
--     guarantees strict temporal order without index fragmentation on a high-
--     write append-only table.
--   + No foreign keys — audit service writes across domain boundaries; FKs
--     would create cross-schema dependencies that violate service isolation.
--   + new_values / old_values: JSONB — schema-independent change capture.
--   + request_id: distributed trace ID for cross-service correlation.
-- =============================================================================

SET search_path = ins_audit, public;

CREATE TABLE ins_audit.audit_logs (
    id                  BIGINT          GENERATED ALWAYS AS IDENTITY,
    event_time          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    request_id          VARCHAR(64)     NULL,
                        -- Distributed trace/correlation ID
    service_name        VARCHAR(60)     NOT NULL,
                        -- auth-service | policy-service | claims-service | etc.
    action              VARCHAR(80)     NOT NULL,
                        -- USER_LOGIN | POLICY_CREATED | CLAIM_APPROVED
                        -- UW_DECISION | PAYMENT_PROCESSED | RULE_PUBLISHED
                        -- PROFILE_UPDATE_REQUEST | RBAC_CHANGE | etc.
    actor_user_id       UUID            NULL,
    actor_username      VARCHAR(100)    NULL,
    actor_role          VARCHAR(60)     NULL,
    actor_ip            INET            NULL,
                        -- PostgreSQL native IP type
    entity_type         VARCHAR(60)     NULL,
                        -- USER | POLICY | CLAIM | UW_CASE | RULE | PAYMENT
    entity_id           VARCHAR(36)     NULL,
                        -- VARCHAR not UUID: allows non-UUID legacy IDs
    entity_reference    VARCHAR(60)     NULL,
                        -- Human-readable: policy number, claim reference, etc.
    old_values          JSONB           NULL,
                        -- State before change (UPDATE/DELETE events)
    new_values          JSONB           NULL,
                        -- State after change (INSERT/UPDATE events)
    result              VARCHAR(10)     NOT NULL DEFAULT 'SUCCESS',
                        -- SUCCESS | FAILURE | PARTIAL
    failure_reason      TEXT            NULL,
    metadata            JSONB           NULL,
                        -- Additional context: HTTP method, endpoint, user-agent

    CONSTRAINT pk_audit_logs PRIMARY KEY (id),
    CONSTRAINT chk_audit_result CHECK (result IN ('SUCCESS','FAILURE','PARTIAL'))
);

-- Partial indexes for common query patterns
CREATE INDEX idx_audit_actor_user     ON ins_audit.audit_logs (actor_user_id)    WHERE actor_user_id IS NOT NULL;
CREATE INDEX idx_audit_entity         ON ins_audit.audit_logs (entity_type, entity_id) WHERE entity_id IS NOT NULL;
CREATE INDEX idx_audit_action         ON ins_audit.audit_logs (action);
CREATE INDEX idx_audit_event_time     ON ins_audit.audit_logs (event_time DESC);
CREATE INDEX idx_audit_service        ON ins_audit.audit_logs (service_name);
CREATE INDEX idx_audit_request_id     ON ins_audit.audit_logs (request_id) WHERE request_id IS NOT NULL;

-- =============================================================================
-- Row-level security: prevent even the service role from deleting rows.
-- Only superuser can bypass RLS. Applied after table creation.
-- =============================================================================
ALTER TABLE ins_audit.audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY audit_insert_only ON ins_audit.audit_logs
    AS RESTRICTIVE
    FOR ALL
    TO ins_audit_role
    USING (TRUE)
    WITH CHECK (TRUE);
-- Note: The ins_audit_role has only INSERT+SELECT granted (see V00).
-- The RLS policy here is belt-and-suspenders defence for UPDATE/DELETE attempts
-- from any role that inherits audit schema USAGE in the future.
