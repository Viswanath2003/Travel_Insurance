-- =============================================================================
-- V06__underwriting_schema.sql
-- Schema: ins_underwriting
-- Service: underwriting-service
-- Description: Underwriting workflow for HIGH and VERY_HIGH risk policies.
--              Implements configurable state machine without external BPM.
--
-- NEW vs MySQL:
--   + uw_cases.current_state CHECK updated with APPROVED_WITH_CONDITIONS
--   + uw_cases.risk_score NUMERIC(5,2) (was INT)
--   + uw_cases unique constraint changed: allows multiple cases per policy
--     (with is_active partial unique index)
--   + uw_conditions — NEW: conditions for APPROVED_WITH_CONDITIONS decisions
--   + All TINYINT(1) → BOOLEAN, DATETIME → TIMESTAMPTZ
-- =============================================================================

SET search_path = ins_underwriting, public;

-- =============================================================================
-- uw_cases
-- One UW case is created per policy routing to underwriting.
-- is_locked / locked_by enforces single-underwriter access (US014).
-- risk_score: NUMERIC(5,2) — decimal precision from rule engine
-- is_active: FALSE when superseded by a re-submission after rejection
-- =============================================================================
CREATE TABLE ins_underwriting.uw_cases (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    case_reference          VARCHAR(30)     NOT NULL,
    policy_id               UUID            NOT NULL,
    policy_number           VARCHAR(30)     NOT NULL,
    customer_id             UUID            NOT NULL,
    customer_name           VARCHAR(100)    NULL,
    risk_score              NUMERIC(5,2)    NOT NULL,
    risk_level              VARCHAR(12)     NOT NULL,
                            -- HIGH | VERY_HIGH
    risk_execution_batch_id UUID            NULL,
    uw_level                SMALLINT        NOT NULL DEFAULT 1,
                            -- 1 = L1, 2 = L2
    current_state           VARCHAR(30)     NOT NULL DEFAULT 'NEW',
                            -- NEW | ASSIGNED | UNDER_REVIEW | INFO_REQUESTED
                            -- INFO_RECEIVED | APPROVED | APPROVED_WITH_CONDITIONS
                            -- REJECTED | REFERRED_TO_L2 | L2_UNDER_REVIEW
                            -- ESCALATED | CLOSED
    assigned_to_user_id     UUID            NULL,
    assigned_to_username    VARCHAR(50)     NULL,
    assigned_by_user_id     UUID            NULL,
    assigned_at             TIMESTAMPTZ     NULL,
    sla_hours               INT             NOT NULL,
    sla_due_at              TIMESTAMPTZ     NOT NULL,
    sla_breached            BOOLEAN         NOT NULL DEFAULT FALSE,
    is_locked               BOOLEAN         NOT NULL DEFAULT FALSE,
    locked_by               UUID            NULL,
    locked_at               TIMESTAMPTZ     NULL,
    premium_loading_percent DECIMAL(6,2)    NOT NULL DEFAULT 0.00,
    final_premium           DECIMAL(12,2)   NULL,
    is_active               BOOLEAN         NOT NULL DEFAULT TRUE,
                            -- FALSE when superseded by re-submission
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    version                 BIGINT          NOT NULL DEFAULT 0,

    CONSTRAINT pk_uw_cases PRIMARY KEY (id),
    CONSTRAINT uq_uw_case_reference UNIQUE (case_reference),
    CONSTRAINT chk_uw_state CHECK (current_state IN (
        'NEW','ASSIGNED','UNDER_REVIEW','INFO_REQUESTED','INFO_RECEIVED',
        'APPROVED','APPROVED_WITH_CONDITIONS','REJECTED',
        'REFERRED_TO_L2','L2_UNDER_REVIEW','ESCALATED','CLOSED'
    )),
    CONSTRAINT chk_uw_risk_level CHECK (risk_level IN ('HIGH','VERY_HIGH')),
    CONSTRAINT chk_uw_level CHECK (uw_level IN (1, 2))
);

-- Partial unique index: only ONE active case per policy
CREATE UNIQUE INDEX uq_uw_policy_active
    ON ins_underwriting.uw_cases (policy_id)
    WHERE is_active = TRUE;

CREATE INDEX idx_uw_state_assignee ON ins_underwriting.uw_cases (current_state, assigned_to_user_id);
CREATE INDEX idx_uw_sla ON ins_underwriting.uw_cases (sla_due_at, current_state, sla_breached)
    WHERE sla_breached = FALSE;
CREATE INDEX idx_uw_policy_id ON ins_underwriting.uw_cases (policy_id);
CREATE INDEX idx_uw_risk_level ON ins_underwriting.uw_cases (risk_level, current_state)
    WHERE is_active = TRUE;

CREATE TRIGGER trg_uw_cases_updated_at
    BEFORE UPDATE ON ins_underwriting.uw_cases
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_underwriting.uw_cases IS
    'UW case per policy routing. APPROVED_WITH_CONDITIONS state added.
     Partial unique index (is_active=TRUE) allows re-submission after rejection.';

-- =============================================================================
-- uw_case_history
-- Immutable audit of all state transitions on a UW case.
-- =============================================================================
CREATE TABLE ins_underwriting.uw_case_history (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    case_id         UUID            NOT NULL,
    from_state      VARCHAR(30)     NULL,
    to_state        VARCHAR(30)     NOT NULL,
    trigger_event   VARCHAR(100)    NOT NULL,
    actor_user_id   UUID            NULL,
    actor_username  VARCHAR(50)     NULL,
    actor_role      VARCHAR(50)     NULL,
    comments        TEXT            NULL,
    transitioned_at TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_uw_case_history PRIMARY KEY (id),
    CONSTRAINT fk_uch_case FOREIGN KEY (case_id) REFERENCES ins_underwriting.uw_cases (id)
);

CREATE INDEX idx_uch_case_id ON ins_underwriting.uw_case_history (case_id, transitioned_at DESC);

-- History is append-only — no deletes
CREATE TRIGGER trg_uw_case_history_no_delete
    BEFORE DELETE ON ins_underwriting.uw_case_history
    FOR EACH ROW EXECUTE FUNCTION ins_common.prevent_delete();

COMMENT ON TABLE ins_underwriting.uw_case_history IS 'Immutable UW case state transition audit. Displayed in UI-021 Audit Trail.';

-- =============================================================================
-- uw_notes
-- Underwriter notes attached to a case.
-- note_type categorizes for display filtering in case detail view.
-- =============================================================================
CREATE TABLE ins_underwriting.uw_notes (
    id          UUID            NOT NULL DEFAULT gen_random_uuid(),
    case_id     UUID            NOT NULL,
    note_type   VARCHAR(30)     NOT NULL,
                -- REVIEW_NOTE | INFO_REQUEST | INFO_RESPONSE | DECISION_NOTE
                -- ESCALATION_NOTE | CONDITION_NOTE
    note_text   TEXT            NOT NULL,
    is_internal BOOLEAN         NOT NULL DEFAULT TRUE,
                -- FALSE = visible to customer; TRUE = internal only
    created_by  UUID            NOT NULL,
    created_at  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_uw_notes PRIMARY KEY (id),
    CONSTRAINT chk_note_type CHECK (note_type IN (
        'REVIEW_NOTE','INFO_REQUEST','INFO_RESPONSE','DECISION_NOTE',
        'ESCALATION_NOTE','CONDITION_NOTE'
    )),
    CONSTRAINT fk_un_case FOREIGN KEY (case_id) REFERENCES ins_underwriting.uw_cases (id)
);

CREATE INDEX idx_un_case_id ON ins_underwriting.uw_notes (case_id, created_at DESC);

COMMENT ON TABLE ins_underwriting.uw_notes IS 'UW case notes. is_internal=FALSE makes note visible to customer via portal.';

-- =============================================================================
-- uw_conditions
-- NEW: Conditions attached to APPROVED_WITH_CONDITIONS decisions.
-- Each condition has a code, free-text description, and tracking of whether
-- the customer has met the condition.
-- =============================================================================
CREATE TABLE ins_underwriting.uw_conditions (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    case_id         UUID            NOT NULL,
    condition_code  VARCHAR(50)     NOT NULL,
                    -- e.g., PRE_EXISTING_WAIVER, MEDICAL_CERTIFICATE, DEDUCTIBLE_INCREASE
    condition_text  TEXT            NOT NULL,
                    -- Free-text description of the condition
    due_date        DATE            NULL,
                    -- When condition must be met (NULL = no deadline)
    is_met          BOOLEAN         NOT NULL DEFAULT FALSE,
    met_at          TIMESTAMPTZ     NULL,
    met_by          UUID            NULL,
                    -- User who marked condition as met
    verification_notes TEXT         NULL,
    noted_by        UUID            NOT NULL,
                    -- Underwriter who added this condition
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_uw_conditions PRIMARY KEY (id),
    CONSTRAINT fk_uwc_case FOREIGN KEY (case_id) REFERENCES ins_underwriting.uw_cases (id)
);

CREATE INDEX idx_uwc_case_id ON ins_underwriting.uw_conditions (case_id);
CREATE INDEX idx_uwc_unmet ON ins_underwriting.uw_conditions (case_id) WHERE is_met = FALSE;

CREATE TRIGGER trg_uw_conditions_updated_at
    BEFORE UPDATE ON ins_underwriting.uw_conditions
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_underwriting.uw_conditions IS
    'NEW: Conditions for APPROVED_WITH_CONDITIONS decisions.
     Each condition tracked independently with met_at timestamp.';

-- =============================================================================
-- uw_info_requests
-- Tracks requests for additional information sent to the customer.
-- Multiple info requests can exist per case (serial requests supported).
-- =============================================================================
CREATE TABLE ins_underwriting.uw_info_requests (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    case_id                 UUID            NOT NULL,
    requested_by            UUID            NOT NULL,
    requested_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    request_details         TEXT            NOT NULL,
    response_received_at    TIMESTAMPTZ     NULL,
    response_details        TEXT            NULL,
    response_submitted_by   UUID            NULL,
    status                  VARCHAR(15)     NOT NULL DEFAULT 'PENDING',
                            -- PENDING | RESPONDED | WAIVED

    CONSTRAINT pk_uw_info_requests PRIMARY KEY (id),
    CONSTRAINT chk_uir_status CHECK (status IN ('PENDING','RESPONDED','WAIVED')),
    CONSTRAINT fk_uir_case FOREIGN KEY (case_id) REFERENCES ins_underwriting.uw_cases (id)
);

CREATE INDEX idx_uir_case_id ON ins_underwriting.uw_info_requests (case_id, status);

COMMENT ON TABLE ins_underwriting.uw_info_requests IS 'Additional information requests to customer. Multiple requests per case supported.';

-- =============================================================================
-- uw_escalations
-- Records escalation events: manual L1→L2 referral or SLA breach.
-- =============================================================================
CREATE TABLE ins_underwriting.uw_escalations (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    case_id                 UUID            NOT NULL,
    escalation_type         VARCHAR(20)     NOT NULL,
                            -- MANUAL_REFERRAL | SLA_BREACH
    escalated_by            UUID            NULL,
    escalated_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    escalation_reason       TEXT            NULL,
    assigned_to_l2_user_id  UUID            NULL,
    resolved_by             UUID            NULL,
    resolved_at             TIMESTAMPTZ     NULL,

    CONSTRAINT pk_uw_escalations PRIMARY KEY (id),
    CONSTRAINT chk_ue_type CHECK (escalation_type IN ('MANUAL_REFERRAL','SLA_BREACH')),
    CONSTRAINT fk_ue_case FOREIGN KEY (case_id) REFERENCES ins_underwriting.uw_cases (id)
);

CREATE INDEX idx_ue_case_id ON ins_underwriting.uw_escalations (case_id);
CREATE INDEX idx_ue_unresolved ON ins_underwriting.uw_escalations (case_id)
    WHERE resolved_at IS NULL;

COMMENT ON TABLE ins_underwriting.uw_escalations IS 'Escalation records: manual L1→L2 referral or SLA breach auto-escalation.';

-- =============================================================================
-- uw_sla_config
-- Admin-configurable SLA thresholds per risk level and UW level.
-- =============================================================================
CREATE TABLE ins_underwriting.uw_sla_config (
    id                          UUID            NOT NULL DEFAULT gen_random_uuid(),
    risk_level                  VARCHAR(12)     NOT NULL,
                                -- HIGH | VERY_HIGH
    uw_level                    SMALLINT        NOT NULL,
                                -- 1 | 2
    sla_hours                   INT             NOT NULL,
    escalation_notify_roles     VARCHAR(300)    NULL,
                                -- Comma-separated roles to notify on SLA breach
    is_active                   BOOLEAN         NOT NULL DEFAULT TRUE,
    updated_by                  UUID            NULL,
    updated_at                  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_uw_sla_config PRIMARY KEY (id),
    CONSTRAINT uq_sla_risk_level UNIQUE (risk_level, uw_level),
    CONSTRAINT chk_sla_risk_level CHECK (risk_level IN ('HIGH','VERY_HIGH')),
    CONSTRAINT chk_sla_uw_level CHECK (uw_level IN (1, 2)),
    CONSTRAINT chk_sla_hours CHECK (sla_hours > 0)
);

CREATE TRIGGER trg_uw_sla_config_updated_at
    BEFORE UPDATE ON ins_underwriting.uw_sla_config
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_underwriting.uw_sla_config IS 'Admin-configurable SLA hours per risk level and UW level. Used by scheduler to detect breaches.';
