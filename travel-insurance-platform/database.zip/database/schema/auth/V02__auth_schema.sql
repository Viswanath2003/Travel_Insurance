-- =============================================================================
-- V02__auth_schema.sql
-- Schema: ins_auth
-- Service: auth-service
-- Description: Identity management, session management, RBAC, customer PII,
--              profile change requests.
--
-- NEW vs MySQL:
--   + customer_profiles — PII separated from users table
--   + profile_change_requests — admin-approved profile update workflow
--   + user_roles.effective_from / effective_to — time-bounded role assignments
--   + All TINYINT(1) → BOOLEAN
--   + All DATETIME → TIMESTAMPTZ
--   + VARCHAR(36) PKs → UUID DEFAULT gen_random_uuid()
--   + ON UPDATE CURRENT_TIMESTAMP → trigger-based updated_at
--   + ENGINE=InnoDB removed
-- =============================================================================

SET search_path = ins_auth, public;

-- =============================================================================
-- users
-- Core authentication record. Supports all 9 roles.
-- PII (phone, DOB, passport, address) is in customer_profiles, not here.
-- password_hash: BCrypt encoded (60 chars), stored as VARCHAR(255) for future algo changes.
-- status lifecycle: PENDING_VERIFICATION → ACTIVE → INACTIVE | LOCKED
-- =============================================================================
CREATE TABLE ins_auth.users (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    username                VARCHAR(50)     NOT NULL,
    email                   VARCHAR(100)    NOT NULL,
    mobile                  VARCHAR(20)     NULL,
    full_name               VARCHAR(100)    NOT NULL,
    password_hash           VARCHAR(255)    NOT NULL,
    customer_type           VARCHAR(20)     NOT NULL DEFAULT 'INDIVIDUAL',
                            -- INDIVIDUAL | CORPORATE
    status                  VARCHAR(30)     NOT NULL DEFAULT 'PENDING_VERIFICATION',
                            -- ACTIVE | INACTIVE | LOCKED | PENDING_VERIFICATION
    failed_login_attempts   SMALLINT        NOT NULL DEFAULT 0,
    locked_until            TIMESTAMPTZ     NULL,
    last_login_at           TIMESTAMPTZ     NULL,
    email_verified          BOOLEAN         NOT NULL DEFAULT FALSE,
    mobile_verified         BOOLEAN         NOT NULL DEFAULT FALSE,
    profile_photo_path      VARCHAR(500)    NULL,
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    created_by              UUID            NULL,
    version                 BIGINT          NOT NULL DEFAULT 0,

    CONSTRAINT pk_users PRIMARY KEY (id),
    CONSTRAINT uq_users_username UNIQUE (username),
    CONSTRAINT uq_users_email UNIQUE (email),
    CONSTRAINT chk_users_status CHECK (status IN ('ACTIVE','INACTIVE','LOCKED','PENDING_VERIFICATION')),
    CONSTRAINT chk_users_customer_type CHECK (customer_type IN ('INDIVIDUAL','CORPORATE'))
);

CREATE INDEX idx_users_status ON ins_auth.users (status);
CREATE INDEX idx_users_mobile ON ins_auth.users (mobile) WHERE mobile IS NOT NULL;
CREATE INDEX idx_users_email ON ins_auth.users (email);

-- updated_at trigger
CREATE TRIGGER trg_users_updated_at
    BEFORE UPDATE ON ins_auth.users
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_auth.users IS 'Core authentication accounts for all platform roles. PII stored in customer_profiles.';
COMMENT ON COLUMN ins_auth.users.customer_type IS 'INDIVIDUAL or CORPORATE — drives form fields and premium calculation.';
COMMENT ON COLUMN ins_auth.users.version IS 'Optimistic locking version for Spring @Version annotation.';

-- =============================================================================
-- customer_profiles
-- PII table for customers only (ROLE_CUSTOMER). Separated from users for:
--   1. GDPR/data protection compliance — easier to scope data access
--   2. Admin approval workflow for profile changes
--   3. Clean separation of auth data vs personal data
-- Linked 1:1 to users.id but only customers have a profile row.
-- =============================================================================
CREATE TABLE ins_auth.customer_profiles (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    user_id                 UUID            NOT NULL,
    date_of_birth           DATE            NULL,
    gender                  VARCHAR(10)     NULL,
                            -- MALE | FEMALE | OTHER | PREFER_NOT_TO_SAY
    nationality             CHAR(2)         NULL,     -- ISO 3166-1 alpha-2
    passport_number         VARCHAR(20)     NULL,
    passport_expiry_date    DATE            NULL,
    address_line1           VARCHAR(200)    NULL,
    address_line2           VARCHAR(200)    NULL,
    city                    VARCHAR(100)    NULL,
    state_province          VARCHAR(100)    NULL,
    postal_code             VARCHAR(20)     NULL,
    country_code            CHAR(2)         NULL,     -- ISO 3166-1 alpha-2
    emergency_contact_name  VARCHAR(100)    NULL,
    emergency_contact_phone VARCHAR(20)     NULL,
    occupation              VARCHAR(100)    NULL,
    annual_income_band      VARCHAR(30)     NULL,
                            -- BELOW_300K | 300K_TO_1M | 1M_TO_3M | ABOVE_3M
    profile_completeness    SMALLINT        NOT NULL DEFAULT 0,
                            -- 0–100 percent complete (calculated by service)
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_customer_profiles PRIMARY KEY (id),
    CONSTRAINT uq_cp_user_id UNIQUE (user_id),
    CONSTRAINT fk_cp_user FOREIGN KEY (user_id) REFERENCES ins_auth.users (id) ON DELETE CASCADE,
    CONSTRAINT chk_cp_gender CHECK (gender IN ('MALE','FEMALE','OTHER','PREFER_NOT_TO_SAY') OR gender IS NULL),
    CONSTRAINT chk_cp_income_band CHECK (annual_income_band IN (
        'BELOW_300K','300K_TO_1M','1M_TO_3M','ABOVE_3M') OR annual_income_band IS NULL)
);

CREATE INDEX idx_cp_user_id ON ins_auth.customer_profiles (user_id);
CREATE INDEX idx_cp_nationality ON ins_auth.customer_profiles (nationality) WHERE nationality IS NOT NULL;

CREATE TRIGGER trg_customer_profiles_updated_at
    BEFORE UPDATE ON ins_auth.customer_profiles
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_auth.customer_profiles IS 'PII data for ROLE_CUSTOMER users. Changes require admin approval via profile_change_requests.';

-- =============================================================================
-- profile_change_requests
-- When a customer submits a profile update, it creates a pending request here.
-- An admin reviews and either approves (applying the change) or rejects.
-- requested_changes is a JSONB diff: {"field": "passport_number", "old": "...", "new": "..."}
-- =============================================================================
CREATE TABLE ins_auth.profile_change_requests (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    submitter_user_id   UUID            NOT NULL,
    profile_id          UUID            NOT NULL,
    requested_changes   JSONB           NOT NULL,
                        -- Array of change objects: [{field, old_value, new_value}]
    status              VARCHAR(20)     NOT NULL DEFAULT 'PENDING',
                        -- PENDING | APPROVED | REJECTED | WITHDRAWN
    reviewed_by         UUID            NULL,
    reviewed_at         TIMESTAMPTZ     NULL,
    admin_notes         TEXT            NULL,
    submitted_at        TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_profile_change_requests PRIMARY KEY (id),
    CONSTRAINT chk_pcr_status CHECK (status IN ('PENDING','APPROVED','REJECTED','WITHDRAWN')),
    CONSTRAINT fk_pcr_user FOREIGN KEY (submitter_user_id) REFERENCES ins_auth.users (id),
    CONSTRAINT fk_pcr_profile FOREIGN KEY (profile_id) REFERENCES ins_auth.customer_profiles (id)
);

CREATE INDEX idx_pcr_user_id ON ins_auth.profile_change_requests (submitter_user_id, status);
CREATE INDEX idx_pcr_status ON ins_auth.profile_change_requests (status) WHERE status = 'PENDING';

-- GIN index on requested_changes JSONB for fast field-based queries
CREATE INDEX idx_pcr_changes_gin ON ins_auth.profile_change_requests USING GIN (requested_changes);

CREATE TRIGGER trg_profile_change_requests_updated_at
    BEFORE UPDATE ON ins_auth.profile_change_requests
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_auth.profile_change_requests IS 'Admin approval queue for customer profile PII changes. Approved changes are applied to customer_profiles.';
COMMENT ON COLUMN ins_auth.profile_change_requests.requested_changes IS 'JSONB array: [{field: "passport_number", old_value: "OLD123", new_value: "NEW456"}]';

-- =============================================================================
-- roles
-- Role definitions. is_system_role prevents accidental deletion of core roles.
-- role_code matches Spring Security authority names (ROLE_CUSTOMER, etc.)
-- =============================================================================
CREATE TABLE ins_auth.roles (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    role_code       VARCHAR(50)     NOT NULL,
                    -- ROLE_CUSTOMER | ROLE_AGENT | ROLE_UNDERWRITER_L1
                    -- ROLE_UNDERWRITER_L2 | ROLE_CLAIMS_OFFICER
                    -- ROLE_FIELD_OFFICER | ROLE_FINANCE | ROLE_ADMIN
                    -- ROLE_RELATIONSHIP_MANAGER
    role_name       VARCHAR(100)    NOT NULL,
    description     TEXT            NULL,
    is_system_role  BOOLEAN         NOT NULL DEFAULT FALSE,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_roles PRIMARY KEY (id),
    CONSTRAINT uq_roles_code UNIQUE (role_code)
);

CREATE INDEX idx_roles_active ON ins_auth.roles (is_active);

CREATE TRIGGER trg_roles_updated_at
    BEFORE UPDATE ON ins_auth.roles
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_auth.roles IS 'Role registry. role_code must match Spring Security authority strings exactly.';

-- =============================================================================
-- permissions
-- Fine-grained permission codes organized by domain.
-- Displayed in Admin RBAC matrix (UI-039).
-- permission_code format: DOMAIN_ACTION (e.g., POLICY_READ, UW_APPROVE)
-- =============================================================================
CREATE TABLE ins_auth.permissions (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    permission_code     VARCHAR(100)    NOT NULL,
    permission_name     VARCHAR(150)    NOT NULL,
    domain              VARCHAR(50)     NOT NULL,
                        -- POLICY | UNDERWRITING | CLAIMS | FIELD | FINANCE
                        -- ADMIN | REPORTING | DOCUMENT | NOTIFICATION
    description         TEXT            NULL,
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_permissions PRIMARY KEY (id),
    CONSTRAINT uq_permissions_code UNIQUE (permission_code)
);

CREATE INDEX idx_permissions_domain ON ins_auth.permissions (domain);
CREATE INDEX idx_permissions_active ON ins_auth.permissions (is_active);

COMMENT ON TABLE ins_auth.permissions IS 'Fine-grained permissions. Displayed in Admin RBAC matrix.';

-- =============================================================================
-- role_permissions
-- Many-to-many: permissions assigned to roles.
-- Admin manages this via RBAC matrix (UI-039).
-- =============================================================================
CREATE TABLE ins_auth.role_permissions (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    role_id         UUID            NOT NULL,
    permission_id   UUID            NOT NULL,
    granted_by      UUID            NULL,
    granted_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_role_permissions PRIMARY KEY (id),
    CONSTRAINT uq_role_permission UNIQUE (role_id, permission_id),
    CONSTRAINT fk_rp_role FOREIGN KEY (role_id) REFERENCES ins_auth.roles (id) ON DELETE CASCADE,
    CONSTRAINT fk_rp_permission FOREIGN KEY (permission_id) REFERENCES ins_auth.permissions (id) ON DELETE CASCADE
);

CREATE INDEX idx_rp_role_id ON ins_auth.role_permissions (role_id);
CREATE INDEX idx_rp_permission_id ON ins_auth.role_permissions (permission_id);

COMMENT ON TABLE ins_auth.role_permissions IS 'Role-to-permission M:M mapping. Managed by admin via RBAC matrix.';

-- =============================================================================
-- user_roles
-- Many-to-many: roles assigned to users.
-- Time-bounded via effective_from / effective_to (NULL effective_to = permanent).
-- A user can have multiple roles (e.g., Admin can also be Finance Officer).
-- =============================================================================
CREATE TABLE ins_auth.user_roles (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    user_id         UUID            NOT NULL,
    role_id         UUID            NOT NULL,
    assigned_by     UUID            NULL,
    assigned_at     TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    effective_from  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    effective_to    TIMESTAMPTZ     NULL,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,

    CONSTRAINT pk_user_roles PRIMARY KEY (id),
    CONSTRAINT uq_user_role UNIQUE (user_id, role_id),
    CONSTRAINT fk_ur_user FOREIGN KEY (user_id) REFERENCES ins_auth.users (id) ON DELETE CASCADE,
    CONSTRAINT fk_ur_role FOREIGN KEY (role_id) REFERENCES ins_auth.roles (id)
);

CREATE INDEX idx_ur_user_id ON ins_auth.user_roles (user_id);
CREATE INDEX idx_ur_role_id ON ins_auth.user_roles (role_id);
-- Partial index: fast lookup of currently active roles for a user
CREATE INDEX idx_ur_user_active ON ins_auth.user_roles (user_id, role_id) WHERE is_active = TRUE;

COMMENT ON TABLE ins_auth.user_roles IS 'User-to-role M:M assignments. Time-bounded with effective_from/effective_to.';

-- =============================================================================
-- user_sessions
-- Refresh token store. Access tokens are stateless JWT; only refresh tokens
-- are persisted here for revocation support.
-- refresh_token_hash: SHA-256 hash of the refresh token (never store raw)
-- device_info: User-Agent header (truncated to 500 chars)
-- =============================================================================
CREATE TABLE ins_auth.user_sessions (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    user_id                 UUID            NOT NULL,
    refresh_token_hash      VARCHAR(255)    NOT NULL,
    device_info             VARCHAR(500)    NULL,
    ip_address              VARCHAR(45)     NULL,   -- IPv6 up to 45 chars
    issued_at               TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    expires_at              TIMESTAMPTZ     NOT NULL,
    revoked_at              TIMESTAMPTZ     NULL,
    is_revoked              BOOLEAN         NOT NULL DEFAULT FALSE,

    CONSTRAINT pk_user_sessions PRIMARY KEY (id),
    CONSTRAINT fk_us_user FOREIGN KEY (user_id) REFERENCES ins_auth.users (id) ON DELETE CASCADE
);

CREATE INDEX idx_us_user_active ON ins_auth.user_sessions (user_id, is_revoked) WHERE is_revoked = FALSE;
CREATE INDEX idx_us_expires ON ins_auth.user_sessions (expires_at);
CREATE INDEX idx_us_token_hash ON ins_auth.user_sessions (refresh_token_hash);

COMMENT ON TABLE ins_auth.user_sessions IS 'Refresh token store. Access tokens are stateless JWT (not stored). Partial index on is_revoked=FALSE.';

-- =============================================================================
-- otp_tokens
-- OTP for: forgot-password, email/mobile verification, profile updates.
-- otp_hash: BCrypt hash of the 6-digit OTP — never stored as plaintext.
-- =============================================================================
CREATE TABLE ins_auth.otp_tokens (
    id          UUID            NOT NULL DEFAULT gen_random_uuid(),
    user_id     UUID            NOT NULL,
    otp_hash    VARCHAR(255)    NOT NULL,
    purpose     VARCHAR(30)     NOT NULL,
                -- FORGOT_PASSWORD | EMAIL_VERIFY | MOBILE_VERIFY | PROFILE_UPDATE
                -- MFA_LOGIN
    expires_at  TIMESTAMPTZ     NOT NULL,
    used_at     TIMESTAMPTZ     NULL,
    is_used     BOOLEAN         NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_otp_tokens PRIMARY KEY (id),
    CONSTRAINT chk_otp_purpose CHECK (purpose IN (
        'FORGOT_PASSWORD','EMAIL_VERIFY','MOBILE_VERIFY','PROFILE_UPDATE','MFA_LOGIN'
    )),
    CONSTRAINT fk_otp_user FOREIGN KEY (user_id) REFERENCES ins_auth.users (id) ON DELETE CASCADE
);

-- Partial index: only valid (unused, not expired) OTPs are frequently queried
CREATE INDEX idx_otp_user_valid ON ins_auth.otp_tokens (user_id, is_used, expires_at)
    WHERE is_used = FALSE;

COMMENT ON TABLE ins_auth.otp_tokens IS 'OTP storage. Hash only — no plaintext. Partial index on unused OTPs.';

-- =============================================================================
-- password_history
-- Prevents reuse of the last N passwords. N is configurable via
-- platform_configurations.password.history.limit (default 5).
-- =============================================================================
CREATE TABLE ins_auth.password_history (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    user_id         UUID            NOT NULL,
    password_hash   VARCHAR(255)    NOT NULL,
    changed_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_password_history PRIMARY KEY (id),
    CONSTRAINT fk_ph_user FOREIGN KEY (user_id) REFERENCES ins_auth.users (id) ON DELETE CASCADE
);

CREATE INDEX idx_ph_user_id ON ins_auth.password_history (user_id, changed_at DESC);

COMMENT ON TABLE ins_auth.password_history IS 'Last N password hashes per user. N from platform_configurations.password.history.limit.';
