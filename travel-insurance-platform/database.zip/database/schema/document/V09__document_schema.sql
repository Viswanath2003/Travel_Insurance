-- =============================================================================
-- V09__document_schema.sql
-- Schema: ins_document
-- Service: document-service
-- Description: Document template management and generated document storage.
--              Templates support Handlebars/Thymeleaf variable substitution.
--              Customers can view/download generated docs from the portal.
--
-- NEW vs MySQL:
--   + document_templates.document_category — groups templates by portal
--   + generated_documents.storage_key — blob storage path (was just doc name)
--   + All TINYINT(1) → BOOLEAN, DATETIME → TIMESTAMPTZ
--   + VARCHAR(36) IDs → UUID
-- =============================================================================

SET search_path = ins_document, public;

-- =============================================================================
-- document_templates
-- Master template definitions. Each type (POLICY_WORDING, INVOICE, etc.)
-- has a current active version. New versions are published, not overwritten.
-- =============================================================================
CREATE TABLE ins_document.document_templates (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    template_code           VARCHAR(80)     NOT NULL,
    template_name           VARCHAR(150)    NOT NULL,
    document_category       VARCHAR(40)     NOT NULL,
                            -- POLICY | CLAIM | FINANCE | SYSTEM
    description             TEXT            NULL,
    current_version_id      UUID            NULL,
                            -- FK to document_template_versions; set after first publish
    is_active               BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_document_templates PRIMARY KEY (id),
    CONSTRAINT uq_document_templates_code UNIQUE (template_code),
    CONSTRAINT chk_document_category CHECK (document_category IN (
        'POLICY','CLAIM','FINANCE','SYSTEM'
    ))
);

CREATE TRIGGER trg_doc_templates_updated_at
    BEFORE UPDATE ON ins_document.document_templates
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

-- =============================================================================
-- document_template_versions
-- Versioned content of each template.
-- is_current: denormalized boolean for fast lookup of live version.
-- =============================================================================
CREATE TABLE ins_document.document_template_versions (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    template_id         UUID            NOT NULL,
    version_number      INT             NOT NULL,
    template_content    TEXT            NOT NULL,
                        -- Handlebars/Thymeleaf template body
    output_format       VARCHAR(10)     NOT NULL DEFAULT 'PDF',
                        -- PDF | HTML
    is_current          BOOLEAN         NOT NULL DEFAULT FALSE,
    published_by        UUID            NULL,
    published_at        TIMESTAMPTZ     NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_doc_template_versions PRIMARY KEY (id),
    CONSTRAINT uq_doc_template_version UNIQUE (template_id, version_number),
    CONSTRAINT fk_doc_template_versions_template FOREIGN KEY (template_id)
        REFERENCES ins_document.document_templates(id)
);

CREATE INDEX idx_doc_template_versions_current
    ON ins_document.document_template_versions (template_id)
    WHERE is_current = TRUE;

-- =============================================================================
-- generated_documents
-- One row per generated document instance (policy certificate, claim receipt,
-- invoice, etc.). storage_key points to blob storage (S3/MinIO).
-- =============================================================================
CREATE TABLE ins_document.generated_documents (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    document_reference  VARCHAR(30)     NOT NULL,
    template_id         UUID            NOT NULL,
    template_version_id UUID            NOT NULL,
    entity_type         VARCHAR(30)     NOT NULL,
                        -- POLICY | CLAIM | QUOTE | PAYMENT
    entity_id           UUID            NOT NULL,
    entity_reference    VARCHAR(30)     NULL,
                        -- Human-readable: policy number, claim reference, etc.
    customer_id         UUID            NULL,
    document_name       VARCHAR(200)    NOT NULL,
    storage_key         VARCHAR(500)    NOT NULL,
                        -- S3/MinIO object key for download
    file_size_bytes     BIGINT          NULL,
    mime_type           VARCHAR(60)     NOT NULL DEFAULT 'application/pdf',
    generated_by        UUID            NULL,
    generation_context  JSONB           NULL,
                        -- Variables substituted into template at generation time
    is_latest_version   BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_generated_documents PRIMARY KEY (id),
    CONSTRAINT uq_generated_doc_reference UNIQUE (document_reference),
    CONSTRAINT fk_generated_docs_template FOREIGN KEY (template_id)
        REFERENCES ins_document.document_templates(id),
    CONSTRAINT fk_generated_docs_version FOREIGN KEY (template_version_id)
        REFERENCES ins_document.document_template_versions(id),
    CONSTRAINT chk_generated_doc_entity CHECK (entity_type IN (
        'POLICY','CLAIM','QUOTE','PAYMENT'
    ))
);

CREATE INDEX idx_gen_docs_entity          ON ins_document.generated_documents (entity_type, entity_id);
CREATE INDEX idx_gen_docs_customer        ON ins_document.generated_documents (customer_id) WHERE customer_id IS NOT NULL;
CREATE INDEX idx_gen_docs_created         ON ins_document.generated_documents (created_at DESC);

-- =============================================================================
-- document_versions
-- Superseded/updated versions of a generated document.
-- Kept for audit: if a policy wording is reissued with amendments.
-- =============================================================================
CREATE TABLE ins_document.document_versions (
    id                          UUID        NOT NULL DEFAULT gen_random_uuid(),
    generated_document_id       UUID        NOT NULL,
    version_number              INT         NOT NULL,
    storage_key                 VARCHAR(500) NOT NULL,
    reason                      TEXT        NULL,
    generated_by                UUID        NULL,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_document_versions PRIMARY KEY (id),
    CONSTRAINT uq_document_version UNIQUE (generated_document_id, version_number),
    CONSTRAINT fk_document_versions_doc FOREIGN KEY (generated_document_id)
        REFERENCES ins_document.generated_documents(id)
);

CREATE INDEX idx_document_versions_doc ON ins_document.document_versions (generated_document_id);
