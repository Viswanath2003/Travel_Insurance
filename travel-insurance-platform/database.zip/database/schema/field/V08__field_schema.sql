-- =============================================================================
-- V08__field_schema.sql
-- Schema: ins_field
-- Service: field-service (part of claims-service in smaller deployments)
-- Description: Field investigation assignments, reports, and evidence.
--              A Claims Officer assigns field investigations to Field Officers.
--              Field Officers submit reports with findings and recommendations.
--
-- NEW vs MySQL:
--   + field_assignments.priority  — HIGH | MEDIUM | LOW (from webapp)
--   + field_assignments.assignment_status  — enum aligned with webapp statuses
--   + field_reports.recommendation  — explicit enum matching webapp options
--   + field_reports.claimant_present  — BOOLEAN (webapp form field)
--   + All TINYINT(1) → BOOLEAN, DATETIME → TIMESTAMPTZ
--   + VARCHAR(36) IDs → UUID
-- =============================================================================

SET search_path = ins_field, public;

-- =============================================================================
-- field_assignments
-- A Claims Officer creates one assignment per field investigation request.
-- Links claim → field officer with SLA deadline and priority.
-- =============================================================================
CREATE TABLE ins_field.field_assignments (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    assignment_reference    VARCHAR(30)     NOT NULL,
                            -- e.g. FA20250520001
    claim_id                UUID            NOT NULL,
    claim_reference         VARCHAR(30)     NOT NULL,
    assigned_officer_id     UUID            NOT NULL,
    assigned_officer_name   VARCHAR(100)    NULL,
    assigned_by             UUID            NOT NULL,
    assigned_by_name        VARCHAR(100)    NULL,
    assignment_status       VARCHAR(30)     NOT NULL DEFAULT 'PENDING_START',
                            -- PENDING_START | IN_PROGRESS | REPORT_SUBMITTED
                            -- COMPLETED | CANCELLED
    priority                VARCHAR(10)     NOT NULL DEFAULT 'MEDIUM',
                            -- LOW | MEDIUM | HIGH
    investigation_location  VARCHAR(300)    NULL,
                            -- Physical address/location to visit
    investigation_type      VARCHAR(60)     NULL,
                            -- Medical Verification | Baggage Loss | Property Damage
                            -- Accident Verification | Other
    due_at                  TIMESTAMPTZ     NOT NULL,
    sla_breached            BOOLEAN         NOT NULL DEFAULT FALSE,
    notes_for_officer       TEXT            NULL,
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_field_assignments PRIMARY KEY (id),
    CONSTRAINT uq_field_assignments_reference UNIQUE (assignment_reference),
    CONSTRAINT chk_field_assignment_status CHECK (assignment_status IN (
        'PENDING_START','IN_PROGRESS','REPORT_SUBMITTED','COMPLETED','CANCELLED'
    )),
    CONSTRAINT chk_field_assignment_priority CHECK (priority IN ('LOW','MEDIUM','HIGH'))
);

CREATE INDEX idx_field_assignments_claim    ON ins_field.field_assignments (claim_id);
CREATE INDEX idx_field_assignments_officer  ON ins_field.field_assignments (assigned_officer_id);
CREATE INDEX idx_field_assignments_status   ON ins_field.field_assignments (assignment_status);
CREATE INDEX idx_field_assignments_due      ON ins_field.field_assignments (due_at) WHERE assignment_status NOT IN ('COMPLETED','CANCELLED');

CREATE TRIGGER trg_field_assignments_updated_at
    BEFORE UPDATE ON ins_field.field_assignments
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

-- =============================================================================
-- field_reports
-- Submitted by Field Officers after completing their investigation.
-- recommendation maps directly to webapp select options.
-- =============================================================================
CREATE TABLE ins_field.field_reports (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    assignment_id           UUID            NOT NULL,
    claim_id                UUID            NOT NULL,
    submitted_by            UUID            NOT NULL,
    submitted_by_name       VARCHAR(100)    NULL,
    inspection_date         DATE            NOT NULL,
    location_visited        VARCHAR(300)    NOT NULL,
    claimant_present        BOOLEAN         NOT NULL DEFAULT FALSE,
    findings                TEXT            NOT NULL,
    recommendation          VARCHAR(40)     NOT NULL,
                            -- APPROVE | PARTIAL_APPROVE | REJECT
                            -- FURTHER_INVESTIGATION_NEEDED
    recommendation_notes    TEXT            NULL,
    submitted_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    reviewed_by             UUID            NULL,
    reviewed_at             TIMESTAMPTZ     NULL,
    review_outcome          VARCHAR(30)     NULL,
                            -- ACCEPTED | REJECTED | NEEDS_REWORK

    CONSTRAINT pk_field_reports PRIMARY KEY (id),
    CONSTRAINT uq_field_reports_assignment UNIQUE (assignment_id),
                            -- One report per assignment
    CONSTRAINT fk_field_reports_assignment FOREIGN KEY (assignment_id)
        REFERENCES ins_field.field_assignments(id),
    CONSTRAINT chk_field_report_recommendation CHECK (recommendation IN (
        'APPROVE','PARTIAL_APPROVE','REJECT','FURTHER_INVESTIGATION_NEEDED'
    ))
);

CREATE INDEX idx_field_reports_claim ON ins_field.field_reports (claim_id);
CREATE INDEX idx_field_reports_officer ON ins_field.field_reports (submitted_by);

-- =============================================================================
-- field_evidence_documents
-- Photos and supporting documents uploaded by the Field Officer.
-- =============================================================================
CREATE TABLE ins_field.field_evidence_documents (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    report_id           UUID            NOT NULL,
    assignment_id       UUID            NOT NULL,
    document_type       VARCHAR(60)     NOT NULL,
                        -- PHOTO | RECEIPT | STATEMENT | OTHER
    document_name       VARCHAR(200)    NOT NULL,
    storage_key         VARCHAR(500)    NOT NULL,
    file_size_bytes     BIGINT          NULL,
    mime_type           VARCHAR(100)    NULL,
    caption             VARCHAR(300)    NULL,
    uploaded_by         UUID            NOT NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_field_evidence PRIMARY KEY (id),
    CONSTRAINT fk_field_evidence_report FOREIGN KEY (report_id)
        REFERENCES ins_field.field_reports(id) ON DELETE CASCADE,
    CONSTRAINT fk_field_evidence_assignment FOREIGN KEY (assignment_id)
        REFERENCES ins_field.field_assignments(id)
);

CREATE INDEX idx_field_evidence_report     ON ins_field.field_evidence_documents (report_id);
CREATE INDEX idx_field_evidence_assignment ON ins_field.field_evidence_documents (assignment_id);
