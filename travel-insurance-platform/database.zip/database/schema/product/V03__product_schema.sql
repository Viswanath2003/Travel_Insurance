-- =============================================================================
-- V03__product_schema.sql
-- Schema: ins_product
-- Service: product-service
-- Description: Insurance product catalog — fully configuration-driven.
--              No product type, plan name, coverage, or add-on is hardcoded.
--
-- NEW vs MySQL:
--   + coverage_limit_risk_multipliers — configurable risk-based max limit multipliers
--   + plan_form_config — per product_type form field configuration
--   + plans.daily_rate — webapp uses daily rate for premium calculation
--   + All TINYINT(1) → BOOLEAN
--   + All DATETIME → TIMESTAMPTZ
--   + JSON → JSONB with GIN indexes
--   + UUID PKs with gen_random_uuid()
-- =============================================================================

SET search_path = ins_product, public;

-- =============================================================================
-- product_types
-- Configurable product type registry. Admin adds new types from UI-031.
-- Examples: SINGLE_TRIP, ANNUAL_MULTI_TRIP, STUDENT, FAMILY, CORPORATE,
--           SENIOR_CITIZEN, GROUP
-- =============================================================================
CREATE TABLE ins_product.product_types (
    id          UUID            NOT NULL DEFAULT gen_random_uuid(),
    type_code   VARCHAR(50)     NOT NULL,
    type_name   VARCHAR(100)    NOT NULL,
    description TEXT            NULL,
    is_active   BOOLEAN         NOT NULL DEFAULT TRUE,
    sort_order  INT             NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    created_by  UUID            NULL,

    CONSTRAINT pk_product_types PRIMARY KEY (id),
    CONSTRAINT uq_product_type_code UNIQUE (type_code)
);

CREATE INDEX idx_pt_active ON ins_product.product_types (is_active, sort_order);

CREATE TRIGGER trg_product_types_updated_at
    BEFORE UPDATE ON ins_product.product_types
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_product.product_types IS 'Product type registry. Admin-configurable from UI-031.';

-- =============================================================================
-- insurance_products
-- Master product catalog. Each product belongs to a product type.
-- =============================================================================
CREATE TABLE ins_product.insurance_products (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    product_code        VARCHAR(50)     NOT NULL,
    product_name        VARCHAR(150)    NOT NULL,
    product_type_id     UUID            NOT NULL,
    description         TEXT            NULL,
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    launch_date         DATE            NULL,
    discontinue_date    DATE            NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    created_by          UUID            NULL,

    CONSTRAINT pk_insurance_products PRIMARY KEY (id),
    CONSTRAINT uq_product_code UNIQUE (product_code),
    CONSTRAINT fk_ip_product_type FOREIGN KEY (product_type_id) REFERENCES ins_product.product_types (id)
);

CREATE INDEX idx_ip_product_type ON ins_product.insurance_products (product_type_id);
CREATE INDEX idx_ip_active ON ins_product.insurance_products (is_active);

CREATE TRIGGER trg_insurance_products_updated_at
    BEFORE UPDATE ON ins_product.insurance_products
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_product.insurance_products IS 'Master product catalog. Each product is linked to a product type.';

-- =============================================================================
-- plans
-- Plan catalog. Each plan belongs to a product. Plans go through
-- DRAFT → ACTIVE publish workflow. Versioning tracks configuration changes.
-- plan_code: short code referenced in policy, agent commission, and PDF generation
-- daily_rate: used by webapp customer portal for per-day premium display
-- =============================================================================
CREATE TABLE ins_product.plans (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    plan_code           VARCHAR(50)     NOT NULL,
    plan_name           VARCHAR(150)    NOT NULL,
    product_id          UUID            NOT NULL,
    base_premium        DECIMAL(12,2)   NOT NULL,
    daily_rate          DECIMAL(10,4)   NOT NULL DEFAULT 0.0000,
                        -- Per-day premium rate used in customer portal display
    currency            CHAR(3)         NOT NULL DEFAULT 'INR',
    min_trip_days       INT             NOT NULL DEFAULT 1,
    max_trip_days       INT             NOT NULL DEFAULT 365,
    min_traveler_age    INT             NOT NULL DEFAULT 0,
    max_traveler_age    INT             NOT NULL DEFAULT 99,
    max_travelers       INT             NOT NULL DEFAULT 10,
    status              VARCHAR(20)     NOT NULL DEFAULT 'DRAFT',
                        -- DRAFT | ACTIVE | INACTIVE | DISCONTINUED
    version             INT             NOT NULL DEFAULT 1,
    published_at        TIMESTAMPTZ     NULL,
    published_by        UUID            NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    created_by          UUID            NULL,

    CONSTRAINT pk_plans PRIMARY KEY (id),
    CONSTRAINT uq_plan_code UNIQUE (plan_code),
    CONSTRAINT chk_plan_status CHECK (status IN ('DRAFT','ACTIVE','INACTIVE','DISCONTINUED')),
    CONSTRAINT fk_plans_product FOREIGN KEY (product_id) REFERENCES ins_product.insurance_products (id),
    CONSTRAINT chk_plan_trip_days CHECK (max_trip_days >= min_trip_days),
    CONSTRAINT chk_plan_traveler_age CHECK (max_traveler_age >= min_traveler_age)
);

CREATE INDEX idx_plans_product ON ins_product.plans (product_id);
CREATE INDEX idx_plans_status ON ins_product.plans (status);
-- Partial index: common portal query — only ACTIVE plans
CREATE INDEX idx_plans_active ON ins_product.plans (product_id, plan_code) WHERE status = 'ACTIVE';

CREATE TRIGGER trg_plans_updated_at
    BEFORE UPDATE ON ins_product.plans
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_product.plans IS 'Plan catalog. plan_code used by policies, commissions, and PDF generation.';
COMMENT ON COLUMN ins_product.plans.daily_rate IS 'Per-day rate displayed in customer portal. Used for trip-length-based pricing display.';

-- =============================================================================
-- plan_versions
-- Immutable snapshots of plan configuration at each publish.
-- Policy issuance stores which plan version was in force at quote time.
-- =============================================================================
CREATE TABLE ins_product.plan_versions (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    plan_id         UUID            NOT NULL,
    version_number  INT             NOT NULL,
    version_data    JSONB           NOT NULL,
                    -- Complete plan + coverages + addons + zones snapshot
    change_summary  TEXT            NULL,
    published_by    UUID            NULL,
    published_at    TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_plan_versions PRIMARY KEY (id),
    CONSTRAINT uq_plan_version UNIQUE (plan_id, version_number),
    CONSTRAINT fk_pv_plan FOREIGN KEY (plan_id) REFERENCES ins_product.plans (id)
);

CREATE INDEX idx_pv_plan_id ON ins_product.plan_versions (plan_id);
CREATE INDEX idx_pv_version_data_gin ON ins_product.plan_versions USING GIN (version_data);

COMMENT ON TABLE ins_product.plan_versions IS 'Immutable plan snapshots at each publish. Referenced by policies for auditability.';

-- Prevent updates to plan_versions (immutable)
CREATE TRIGGER trg_plan_versions_immutable
    BEFORE UPDATE ON ins_product.plan_versions
    FOR EACH ROW EXECUTE FUNCTION ins_common.prevent_update();

-- =============================================================================
-- coverage_types
-- Master catalog of coverage categories. Admin-configurable.
-- =============================================================================
CREATE TABLE ins_product.coverage_types (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    coverage_code       VARCHAR(50)     NOT NULL,
    coverage_name       VARCHAR(150)    NOT NULL,
    coverage_category   VARCHAR(50)     NULL,
                        -- HEALTH | TRAVEL | FINANCIAL | PERSONAL | ADVENTURE
    description         TEXT            NULL,
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    sort_order          INT             NOT NULL DEFAULT 0,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_coverage_types PRIMARY KEY (id),
    CONSTRAINT uq_coverage_code UNIQUE (coverage_code)
);

CREATE INDEX idx_ct_category ON ins_product.coverage_types (coverage_category, is_active);

COMMENT ON TABLE ins_product.coverage_types IS 'Master coverage type catalog. 17 types seeded in V21.';

-- =============================================================================
-- plan_coverages
-- Defines coverage limits per plan. min/max/default/step support
-- the coverage slider in the Adaptive Policy Builder (UI-010).
-- is_adjustable = true → customer can slide between min_limit and max_limit
-- is_adjustable = false → fixed at default_limit
-- =============================================================================
CREATE TABLE ins_product.plan_coverages (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    plan_id             UUID            NOT NULL,
    coverage_type_id    UUID            NOT NULL,
    min_limit           DECIMAL(15,2)   NOT NULL DEFAULT 0,
    max_limit           DECIMAL(15,2)   NOT NULL,
    default_limit       DECIMAL(15,2)   NOT NULL,
    limit_step          DECIMAL(15,2)   NOT NULL DEFAULT 1000,
                        -- Slider increment step in the customer portal
    currency            CHAR(3)         NOT NULL DEFAULT 'INR',
    deductible          DECIMAL(12,2)   NOT NULL DEFAULT 0,
    is_mandatory        BOOLEAN         NOT NULL DEFAULT FALSE,
    is_adjustable       BOOLEAN         NOT NULL DEFAULT FALSE,
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,

    CONSTRAINT pk_plan_coverages PRIMARY KEY (id),
    CONSTRAINT uq_plan_coverage UNIQUE (plan_id, coverage_type_id),
    CONSTRAINT fk_pc_plan FOREIGN KEY (plan_id) REFERENCES ins_product.plans (id),
    CONSTRAINT fk_pc_coverage_type FOREIGN KEY (coverage_type_id) REFERENCES ins_product.coverage_types (id),
    CONSTRAINT chk_pc_limits CHECK (default_limit BETWEEN min_limit AND max_limit),
    CONSTRAINT chk_pc_max_limit CHECK (max_limit > 0),
    CONSTRAINT chk_pc_step CHECK (limit_step > 0)
);

CREATE INDEX idx_pc_plan_id ON ins_product.plan_coverages (plan_id);
CREATE INDEX idx_pc_adjustable ON ins_product.plan_coverages (plan_id, is_adjustable) WHERE is_adjustable = TRUE;

COMMENT ON TABLE ins_product.plan_coverages IS 'Coverage limit configuration per plan. Adjustable limits power the customer portal slider.';

-- =============================================================================
-- coverage_limit_risk_multipliers
-- NEW: Configurable risk-level-based max coverage limit multipliers.
-- Controls the maximum coverage amount a customer can choose based on risk level.
--
-- Business rule (from webapp, now DB-driven):
--   LOW risk      → max_limit × 1.5  (customer can select up to 150% of plan max)
--   MEDIUM risk   → max_limit × 1.25
--   HIGH risk     → max_limit × 1.1
--   VERY_HIGH risk → max_limit × 1.0  (cannot increase; capped at plan max)
--                    is_adjustable_at_risk_level = FALSE
--
-- Admin can modify these multipliers from the Admin portal.
-- =============================================================================
CREATE TABLE ins_product.coverage_limit_risk_multipliers (
    id                              UUID            NOT NULL DEFAULT gen_random_uuid(),
    risk_level                      VARCHAR(12)     NOT NULL,
                                    -- LOW | MEDIUM | HIGH | VERY_HIGH
    multiplier_value                NUMERIC(5,3)    NOT NULL,
                                    -- e.g., 1.500, 1.250, 1.100, 1.000
    is_adjustable_at_risk_level     BOOLEAN         NOT NULL DEFAULT TRUE,
                                    -- FALSE for VERY_HIGH: slider disabled
    description                     TEXT            NULL,
    is_active                       BOOLEAN         NOT NULL DEFAULT TRUE,
    updated_by                      UUID            NULL,
    updated_at                      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_coverage_limit_risk_multipliers PRIMARY KEY (id),
    CONSTRAINT uq_clrm_risk_level UNIQUE (risk_level),
    CONSTRAINT chk_clrm_risk_level CHECK (risk_level IN ('LOW','MEDIUM','HIGH','VERY_HIGH')),
    CONSTRAINT chk_clrm_multiplier CHECK (multiplier_value > 0 AND multiplier_value <= 3.0)
);

CREATE TRIGGER trg_coverage_limit_risk_multipliers_updated_at
    BEFORE UPDATE ON ins_product.coverage_limit_risk_multipliers
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_product.coverage_limit_risk_multipliers IS
    'Risk-level-based coverage limit multipliers. Previously hardcoded in webapp JS — now DB-configurable.
     LOW=1.5x, MEDIUM=1.25x, HIGH=1.1x, VERY_HIGH=1.0x (slider disabled).';

-- =============================================================================
-- addons
-- Add-on catalog. Admin manages from UI-032.
-- =============================================================================
CREATE TABLE ins_product.addons (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    addon_code      VARCHAR(50)     NOT NULL,
    addon_name      VARCHAR(150)    NOT NULL,
    addon_category  VARCHAR(50)     NULL,
                    -- MEDICAL | TRAVEL | FINANCIAL | ADVENTURE | PERSONAL | CORPORATE
    description     TEXT            NULL,
    pricing_type    VARCHAR(20)     NOT NULL,
                    -- FLAT | PERCENT_OF_BASE | PER_DAY | PER_TRAVELER
    pricing_value   DECIMAL(12,4)   NOT NULL,
    currency        CHAR(3)         NOT NULL DEFAULT 'INR',
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    sort_order      INT             NOT NULL DEFAULT 0,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    created_by      UUID            NULL,

    CONSTRAINT pk_addons PRIMARY KEY (id),
    CONSTRAINT uq_addon_code UNIQUE (addon_code),
    CONSTRAINT chk_addon_pricing_type CHECK (pricing_type IN ('FLAT','PERCENT_OF_BASE','PER_DAY','PER_TRAVELER')),
    CONSTRAINT chk_addon_pricing_value CHECK (pricing_value >= 0)
);

CREATE INDEX idx_addons_active ON ins_product.addons (is_active, sort_order);

CREATE TRIGGER trg_addons_updated_at
    BEFORE UPDATE ON ins_product.addons
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_product.addons IS 'Add-on catalog. 17 add-ons seeded in V21. Admin-configurable from UI-032.';

-- =============================================================================
-- plan_addon_mappings
-- Controls which add-ons are available for which plans.
-- =============================================================================
CREATE TABLE ins_product.plan_addon_mappings (
    id          UUID            NOT NULL DEFAULT gen_random_uuid(),
    plan_id     UUID            NOT NULL,
    addon_id    UUID            NOT NULL,
    is_active   BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_plan_addon_mappings PRIMARY KEY (id),
    CONSTRAINT uq_plan_addon UNIQUE (plan_id, addon_id),
    CONSTRAINT fk_pam_plan FOREIGN KEY (plan_id) REFERENCES ins_product.plans (id),
    CONSTRAINT fk_pam_addon FOREIGN KEY (addon_id) REFERENCES ins_product.addons (id)
);

CREATE INDEX idx_pam_plan_id ON ins_product.plan_addon_mappings (plan_id) WHERE is_active = TRUE;
CREATE INDEX idx_pam_addon_id ON ins_product.plan_addon_mappings (addon_id);

COMMENT ON TABLE ins_product.plan_addon_mappings IS 'Add-on availability per plan. Controls what customer can see in Policy Builder.';

-- =============================================================================
-- destination_zones
-- Geographic risk zones. risk_tier feeds into the rule engine for premium loading.
-- =============================================================================
CREATE TABLE ins_product.destination_zones (
    id          UUID            NOT NULL DEFAULT gen_random_uuid(),
    zone_code   VARCHAR(20)     NOT NULL,
                -- ZONE_DOMESTIC | ZONE_ASIA | ZONE_EUROPE
                -- ZONE_USA_CANADA | ZONE_WORLDWIDE | etc.
    zone_name   VARCHAR(100)    NOT NULL,
    risk_tier   VARCHAR(10)     NOT NULL DEFAULT 'TIER_1',
                -- TIER_1 (lowest) ... TIER_5 (highest)
    description TEXT            NULL,
    is_active   BOOLEAN         NOT NULL DEFAULT TRUE,
    sort_order  INT             NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_destination_zones PRIMARY KEY (id),
    CONSTRAINT uq_zone_code UNIQUE (zone_code),
    CONSTRAINT chk_risk_tier CHECK (risk_tier IN ('TIER_1','TIER_2','TIER_3','TIER_4','TIER_5'))
);

CREATE INDEX idx_dz_active ON ins_product.destination_zones (is_active, sort_order);

COMMENT ON TABLE ins_product.destination_zones IS 'Geographic risk zones. TIER_1=lowest, TIER_5=highest risk premium loading.';

-- =============================================================================
-- zone_countries
-- Maps countries to zones. ISO 3166-1 alpha-2 country codes.
-- =============================================================================
CREATE TABLE ins_product.zone_countries (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    zone_id         UUID            NOT NULL,
    country_code    CHAR(2)         NOT NULL,
    country_name    VARCHAR(100)    NOT NULL,

    CONSTRAINT pk_zone_countries PRIMARY KEY (id),
    CONSTRAINT uq_zone_country UNIQUE (country_code),
    CONSTRAINT fk_zc_zone FOREIGN KEY (zone_id) REFERENCES ins_product.destination_zones (id)
);

CREATE INDEX idx_zc_zone_id ON ins_product.zone_countries (zone_id);
CREATE INDEX idx_zc_country_code ON ins_product.zone_countries (country_code);

COMMENT ON TABLE ins_product.zone_countries IS 'Country-to-zone mapping. ISO 3166-1 alpha-2 codes. One country per zone.';

-- =============================================================================
-- plan_zone_mappings
-- Defines which zones a plan covers and any zone-specific base loading.
-- =============================================================================
CREATE TABLE ins_product.plan_zone_mappings (
    id                          UUID            NOT NULL DEFAULT gen_random_uuid(),
    plan_id                     UUID            NOT NULL,
    zone_id                     UUID            NOT NULL,
    zone_base_loading_percent   DECIMAL(6,2)    NOT NULL DEFAULT 0.00,
                                -- Additional premium % for this zone (e.g., USA_CANADA = 15.00%)
    is_active                   BOOLEAN         NOT NULL DEFAULT TRUE,

    CONSTRAINT pk_plan_zone_mappings PRIMARY KEY (id),
    CONSTRAINT uq_plan_zone UNIQUE (plan_id, zone_id),
    CONSTRAINT fk_pzm_plan FOREIGN KEY (plan_id) REFERENCES ins_product.plans (id),
    CONSTRAINT fk_pzm_zone FOREIGN KEY (zone_id) REFERENCES ins_product.destination_zones (id)
);

CREATE INDEX idx_pzm_plan_id ON ins_product.plan_zone_mappings (plan_id) WHERE is_active = TRUE;

COMMENT ON TABLE ins_product.plan_zone_mappings IS 'Plan-zone availability and base loading percent. Controls which zones a plan covers.';

-- =============================================================================
-- plan_form_config
-- NEW: Per-product-type form field configuration.
-- Controls which fields appear in the customer portal for each product type.
-- Different product types (STUDENT, SENIOR, CORPORATE) require different fields.
-- Validation rules stored as JSONB: {"type": "regex", "pattern": "^[A-Z0-9]{6,20}$"}
-- =============================================================================
CREATE TABLE ins_product.plan_form_config (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    product_type_id     UUID            NOT NULL,
    field_name          VARCHAR(100)    NOT NULL,
                        -- e.g., university_name, employee_id, company_name
    field_label         VARCHAR(200)    NOT NULL,
    field_type          VARCHAR(30)     NOT NULL,
                        -- TEXT | NUMBER | DATE | BOOLEAN | SELECT | FILE | PHONE | EMAIL
    is_required         BOOLEAN         NOT NULL DEFAULT FALSE,
    placeholder_text    VARCHAR(200)    NULL,
    help_text           TEXT            NULL,
    validation_rules    JSONB           NULL,
                        -- {"type": "regex", "pattern": "...", "min": 0, "max": 100}
    options             JSONB           NULL,
                        -- For SELECT type: [{"value": "A", "label": "Option A"}]
    sort_order          INT             NOT NULL DEFAULT 0,
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_plan_form_config PRIMARY KEY (id),
    CONSTRAINT uq_pfc_type_field UNIQUE (product_type_id, field_name),
    CONSTRAINT fk_pfc_product_type FOREIGN KEY (product_type_id) REFERENCES ins_product.product_types (id),
    CONSTRAINT chk_pfc_field_type CHECK (field_type IN (
        'TEXT','NUMBER','DATE','BOOLEAN','SELECT','FILE','PHONE','EMAIL','TEXTAREA'
    ))
);

CREATE INDEX idx_pfc_product_type ON ins_product.plan_form_config (product_type_id, sort_order)
    WHERE is_active = TRUE;
CREATE INDEX idx_pfc_validation_gin ON ins_product.plan_form_config USING GIN (validation_rules)
    WHERE validation_rules IS NOT NULL;

CREATE TRIGGER trg_plan_form_config_updated_at
    BEFORE UPDATE ON ins_product.plan_form_config
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_product.plan_form_config IS
    'Per-product-type form field configuration. Controls customer portal form fields.
     validation_rules JSONB: {type, pattern, min, max, maxLength}.';
