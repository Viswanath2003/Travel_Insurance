-- =============================================================================
-- V05__policy_schema.sql
-- Schema: ins_policy
-- Service: policy-service
-- Description: Complete quote-to-policy lifecycle.
--              Quotes are immutable after calculation.
--              Policies are immutable after activation (snapshots capture state).
--
-- NEW vs MySQL:
--   + policies.plan_code column added
--   + policies.status CHECK updated with all 11 statuses
--   + policies.risk_score NUMERIC(5,2) (was INT)
--   + quotes.risk_score NUMERIC(5,2) (was INT)
--   + policy_agent_bindings — NEW: agent binding record
--   + agent_commissions — NEW: commission tracking per policy
--   + JSONB GIN indexes on all breakdown/snapshot tables
--   + All TINYINT(1) → BOOLEAN, DATETIME → TIMESTAMPTZ
--   + plan_code VARCHAR on policies for denormalized display
-- =============================================================================

SET search_path = ins_policy, public;

-- =============================================================================
-- quotes
-- Quote lifecycle. A quote has configurable validity (default 48 hours).
-- On purchase confirmation, quote converts 1:1 to a policy.
-- risk_score: NUMERIC(5,2) — supports decimal scoring from weighted rules
-- =============================================================================
CREATE TABLE ins_policy.quotes (
    id                                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    quote_reference                     VARCHAR(30)     NOT NULL,
    customer_id                         UUID            NOT NULL,
    product_id                          UUID            NOT NULL,
    plan_id                             UUID            NOT NULL,
    plan_code                           VARCHAR(50)     NOT NULL,
    plan_version                        INT             NOT NULL DEFAULT 1,
    destination_country_code            CHAR(2)         NOT NULL,
    destination_zone_id                 UUID            NULL,
    destination_zone_code               VARCHAR(20)     NULL,
    trip_start_date                     DATE            NOT NULL,
    trip_end_date                       DATE            NOT NULL,
    trip_duration_days                  INT             NOT NULL,
    num_travelers                       INT             NOT NULL DEFAULT 1,
    trip_purpose                        VARCHAR(30)     NOT NULL DEFAULT 'LEISURE',
                                        -- LEISURE | BUSINESS | EDUCATION | MEDICAL | PILGRIMAGE | ADVENTURE
    total_premium                       DECIMAL(12,2)   NULL,
    currency                            CHAR(3)         NOT NULL DEFAULT 'INR',
    risk_score                          NUMERIC(5,2)    NULL,
    risk_level                          VARCHAR(12)     NULL,
                                        -- LOW | MEDIUM | HIGH | VERY_HIGH
    status                              VARCHAR(30)     NOT NULL DEFAULT 'DRAFT',
                                        -- DRAFT | CALCULATED | EXPIRED | CONVERTED | ABANDONED
    risk_rule_execution_batch_id        UUID            NULL,
    premium_rule_execution_batch_id     UUID            NULL,
    agent_id                            UUID            NULL,  -- If quote initiated by agent
    expires_at                          TIMESTAMPTZ     NOT NULL,
    created_at                          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at                          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    created_by                          UUID            NULL,

    CONSTRAINT pk_quotes PRIMARY KEY (id),
    CONSTRAINT uq_quote_reference UNIQUE (quote_reference),
    CONSTRAINT chk_quote_status CHECK (status IN ('DRAFT','CALCULATED','EXPIRED','CONVERTED','ABANDONED')),
    CONSTRAINT chk_quote_dates CHECK (trip_end_date >= trip_start_date),
    CONSTRAINT chk_quote_purpose CHECK (trip_purpose IN (
        'LEISURE','BUSINESS','EDUCATION','MEDICAL','PILGRIMAGE','ADVENTURE'
    ))
);

CREATE INDEX idx_quotes_customer ON ins_policy.quotes (customer_id, status);
CREATE INDEX idx_quotes_expires ON ins_policy.quotes (expires_at, status) WHERE status = 'CALCULATED';
CREATE INDEX idx_quotes_plan ON ins_policy.quotes (plan_id);
CREATE INDEX idx_quotes_agent ON ins_policy.quotes (agent_id) WHERE agent_id IS NOT NULL;

CREATE TRIGGER trg_quotes_updated_at
    BEFORE UPDATE ON ins_policy.quotes
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_policy.quotes IS 'Quote lifecycle. Converted 1:1 to policy on purchase. Default validity 48 hours.';

-- =============================================================================
-- quote_travelers
-- Traveler data at quote stage. Full name and passport optional at quote;
-- mandatory at policy issuance.
-- =============================================================================
CREATE TABLE ins_policy.quote_travelers (
    id                          UUID            NOT NULL DEFAULT gen_random_uuid(),
    quote_id                    UUID            NOT NULL,
    traveler_sequence           INT             NOT NULL,
    full_name                   VARCHAR(100)    NULL,
    date_of_birth               DATE            NOT NULL,
    age                         INT             NOT NULL,
    age_band                    VARCHAR(25)     NULL,
                                -- CHILD_0_17 | ADULT_18_35 | ADULT_36_59
                                -- SENIOR_60_70 | SENIOR_71_PLUS
    passport_number             VARCHAR(20)     NULL,
    nationality                 CHAR(2)         NULL,
    gender                      VARCHAR(10)     NULL,
    is_primary                  BOOLEAN         NOT NULL DEFAULT FALSE,
    has_preexisting_condition   BOOLEAN         NOT NULL DEFAULT FALSE,
    has_adventure_activity      BOOLEAN         NOT NULL DEFAULT FALSE,
    individual_risk_score       NUMERIC(5,2)    NULL,
    individual_premium          DECIMAL(10,2)   NULL,

    CONSTRAINT pk_quote_travelers PRIMARY KEY (id),
    CONSTRAINT uq_qt_sequence UNIQUE (quote_id, traveler_sequence),
    CONSTRAINT fk_qt_quote FOREIGN KEY (quote_id) REFERENCES ins_policy.quotes (id) ON DELETE CASCADE,
    CONSTRAINT chk_qt_age_band CHECK (age_band IN (
        'CHILD_0_17','ADULT_18_35','ADULT_36_59','SENIOR_60_70','SENIOR_71_PLUS') OR age_band IS NULL)
);

CREATE INDEX idx_qt_quote_id ON ins_policy.quote_travelers (quote_id);

COMMENT ON TABLE ins_policy.quote_travelers IS 'Traveler data at quote stage. Full PII not required until policy issuance.';

-- =============================================================================
-- quote_coverage_selections
-- Customer-selected coverage limits from the Adaptive Policy Builder slider.
-- =============================================================================
CREATE TABLE ins_policy.quote_coverage_selections (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    quote_id            UUID            NOT NULL,
    coverage_type_id    UUID            NOT NULL,
    coverage_code       VARCHAR(50)     NOT NULL,
    selected_limit      DECIMAL(15,2)   NOT NULL,
    base_limit          DECIMAL(15,2)   NOT NULL,
    limit_premium       DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    currency            CHAR(3)         NOT NULL DEFAULT 'INR',

    CONSTRAINT pk_qcs PRIMARY KEY (id),
    CONSTRAINT uq_qcs_quote_coverage UNIQUE (quote_id, coverage_type_id),
    CONSTRAINT fk_qcs_quote FOREIGN KEY (quote_id) REFERENCES ins_policy.quotes (id) ON DELETE CASCADE
);

CREATE INDEX idx_qcs_quote_id ON ins_policy.quote_coverage_selections (quote_id);

COMMENT ON TABLE ins_policy.quote_coverage_selections IS 'Customer-selected coverage limits from slider. limit_premium = extra cost for choosing above default.';

-- =============================================================================
-- quote_addon_selections
-- Add-ons selected during Policy Builder (UI-011).
-- =============================================================================
CREATE TABLE ins_policy.quote_addon_selections (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    quote_id        UUID            NOT NULL,
    addon_id        UUID            NOT NULL,
    addon_code      VARCHAR(50)     NOT NULL,
    addon_premium   DECIMAL(10,2)   NOT NULL,

    CONSTRAINT pk_qas PRIMARY KEY (id),
    CONSTRAINT uq_qas_quote_addon UNIQUE (quote_id, addon_id),
    CONSTRAINT fk_qas_quote FOREIGN KEY (quote_id) REFERENCES ins_policy.quotes (id) ON DELETE CASCADE
);

CREATE INDEX idx_qas_quote_id ON ins_policy.quote_addon_selections (quote_id);

COMMENT ON TABLE ins_policy.quote_addon_selections IS 'Add-ons selected at quote stage. Carried forward to policy on conversion.';

-- =============================================================================
-- quote_premium_breakdown
-- Full itemized premium breakdown for the quote.
-- Displayed in UI-012 Dynamic Pricing.
-- breakdown_json holds rule-by-rule contribution detail for explainability.
-- =============================================================================
CREATE TABLE ins_policy.quote_premium_breakdown (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    quote_id                UUID            NOT NULL,
    base_premium            DECIMAL(12,2)   NOT NULL,
    zone_loading            DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    risk_loading            DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    age_loading             DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    duration_loading        DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    coverage_loading        DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    addon_premium_total     DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    discount_amount         DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    tax_amount              DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    gross_premium           DECIMAL(12,2)   NOT NULL,
    net_premium             DECIMAL(12,2)   NOT NULL,
    breakdown_json          JSONB           NULL,
                            -- Rule-by-rule contribution detail for explainability

    CONSTRAINT pk_qpb PRIMARY KEY (id),
    CONSTRAINT uq_qpb_quote UNIQUE (quote_id),
    CONSTRAINT fk_qpb_quote FOREIGN KEY (quote_id) REFERENCES ins_policy.quotes (id) ON DELETE CASCADE
);

CREATE INDEX idx_qpb_breakdown_gin ON ins_policy.quote_premium_breakdown USING GIN (breakdown_json)
    WHERE breakdown_json IS NOT NULL;

COMMENT ON TABLE ins_policy.quote_premium_breakdown IS 'Itemized premium breakdown. breakdown_json has rule-by-rule explainability data.';

-- =============================================================================
-- quote_snapshots
-- Immutable snapshot of quote at the time of premium calculation.
-- Captures which plan_version and rule_versions were used.
-- =============================================================================
CREATE TABLE ins_policy.quote_snapshots (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    quote_id                UUID            NOT NULL,
    snapshot_data           JSONB           NOT NULL,
    plan_version_id         UUID            NULL,
    risk_rule_versions      JSONB           NULL,
    premium_rule_versions   JSONB           NULL,
    snapshotted_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_quote_snapshots PRIMARY KEY (id),
    CONSTRAINT uq_qs_quote UNIQUE (quote_id),
    CONSTRAINT fk_qs_quote FOREIGN KEY (quote_id) REFERENCES ins_policy.quotes (id)
);

CREATE INDEX idx_qs_snapshot_gin ON ins_policy.quote_snapshots USING GIN (snapshot_data);

CREATE TRIGGER trg_quote_snapshots_immutable
    BEFORE UPDATE ON ins_policy.quote_snapshots
    FOR EACH ROW EXECUTE FUNCTION ins_common.prevent_update();

COMMENT ON TABLE ins_policy.quote_snapshots IS 'Immutable quote snapshot. Captures plan and rule versions active at calculation time.';

-- =============================================================================
-- policies
-- Core policy record. Immutable after status transitions to ACTIVE.
-- plan_code: denormalized for PDF generation and commission calculation
-- risk_score: NUMERIC(5,2) — decimal scoring from weighted rules
-- status: 11-value enum matching all routing states from webapp + backend
-- =============================================================================
CREATE TABLE ins_policy.policies (
    id                                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    policy_number                       VARCHAR(30)     NOT NULL,
    quote_id                            UUID            NOT NULL,
    customer_id                         UUID            NOT NULL,
    product_id                          UUID            NOT NULL,
    plan_id                             UUID            NOT NULL,
    plan_code                           VARCHAR(50)     NOT NULL,
                                        -- Denormalized from plans.plan_code
    plan_version                        INT             NOT NULL DEFAULT 1,
    destination_country_code            CHAR(2)         NOT NULL,
    destination_zone_id                 UUID            NULL,
    destination_zone_code               VARCHAR(20)     NULL,
    trip_start_date                     DATE            NOT NULL,
    trip_end_date                       DATE            NOT NULL,
    trip_duration_days                  INT             NOT NULL,
    num_travelers                       INT             NOT NULL DEFAULT 1,
    trip_purpose                        VARCHAR(30)     NULL,
    total_premium                       DECIMAL(12,2)   NOT NULL,
    currency                            CHAR(3)         NOT NULL DEFAULT 'INR',
    risk_score                          NUMERIC(5,2)    NULL,
    risk_level                          VARCHAR(12)     NULL,
    status                              VARCHAR(30)     NOT NULL,
                                        -- Full status list:
                                        -- PENDING_PAYMENT | PENDING_CO_REVIEW | PENDING_UW_L1
                                        -- PENDING_UW_L2 | UNDER_REVIEW | ACTIVE | EXPIRED
                                        -- CANCELLED | CANCELLATION_REQUESTED | REJECTED | LAPSED
    issue_date                          TIMESTAMPTZ     NULL,
    expiry_date                         DATE            NULL,
    cancellation_date                   TIMESTAMPTZ     NULL,
    cancellation_reason                 TEXT            NULL,
    parent_policy_id                    UUID            NULL,  -- For renewals
    renewal_count                       INT             NOT NULL DEFAULT 0,
    payment_reference                   VARCHAR(100)    NULL,
    payment_recorded_at                 TIMESTAMPTZ     NULL,
    risk_rule_execution_batch_id        UUID            NULL,
    premium_rule_execution_batch_id     UUID            NULL,
    policy_wording_id                   UUID            NULL,
    policy_wording_version              INT             NULL,
    created_at                          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at                          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    created_by                          UUID            NULL,
    version                             BIGINT          NOT NULL DEFAULT 0,

    CONSTRAINT pk_policies PRIMARY KEY (id),
    CONSTRAINT uq_policy_number UNIQUE (policy_number),
    CONSTRAINT chk_policy_status CHECK (status IN (
        'PENDING_PAYMENT','PENDING_CO_REVIEW','PENDING_UW_L1','PENDING_UW_L2',
        'UNDER_REVIEW','ACTIVE','EXPIRED','CANCELLED','CANCELLATION_REQUESTED',
        'REJECTED','LAPSED'
    )),
    CONSTRAINT fk_policies_quote FOREIGN KEY (quote_id) REFERENCES ins_policy.quotes (id),
    CONSTRAINT fk_policies_parent FOREIGN KEY (parent_policy_id) REFERENCES ins_policy.policies (id)
);

CREATE INDEX idx_policies_customer ON ins_policy.policies (customer_id, status);
CREATE INDEX idx_policies_status_risk ON ins_policy.policies (status, risk_level);
CREATE INDEX idx_policies_plan ON ins_policy.policies (plan_id, plan_code);
CREATE INDEX idx_policies_expiry ON ins_policy.policies (expiry_date, status) WHERE status = 'ACTIVE';
-- Partial indexes for each review queue
CREATE INDEX idx_policies_pending_co ON ins_policy.policies (customer_id) WHERE status = 'PENDING_CO_REVIEW';
CREATE INDEX idx_policies_pending_uwl1 ON ins_policy.policies (customer_id) WHERE status = 'PENDING_UW_L1';
CREATE INDEX idx_policies_pending_uwl2 ON ins_policy.policies (customer_id) WHERE status = 'PENDING_UW_L2';

CREATE TRIGGER trg_policies_updated_at
    BEFORE UPDATE ON ins_policy.policies
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_policy.policies IS 'Core policy record. plan_code denormalized for PDF/commission. 11-status enum covers all routing states.';
COMMENT ON COLUMN ins_policy.policies.plan_code IS 'Denormalized from plans.plan_code. Used in PDF generation and agent commission calculation.';

-- =============================================================================
-- policy_travelers
-- Complete traveler details locked at policy issuance. All fields mandatory.
-- =============================================================================
CREATE TABLE ins_policy.policy_travelers (
    id                          UUID            NOT NULL DEFAULT gen_random_uuid(),
    policy_id                   UUID            NOT NULL,
    traveler_sequence           INT             NOT NULL,
    full_name                   VARCHAR(100)    NOT NULL,
    date_of_birth               DATE            NOT NULL,
    age                         INT             NOT NULL,
    age_band                    VARCHAR(25)     NULL,
    passport_number             VARCHAR(20)     NOT NULL,
    nationality                 CHAR(2)         NULL,
    gender                      VARCHAR(10)     NULL,
    contact_number              VARCHAR(20)     NULL,
    is_primary                  BOOLEAN         NOT NULL DEFAULT FALSE,
    has_preexisting_condition   BOOLEAN         NOT NULL DEFAULT FALSE,
    has_adventure_activity      BOOLEAN         NOT NULL DEFAULT FALSE,
    individual_risk_score       NUMERIC(5,2)    NULL,
    individual_premium          DECIMAL(10,2)   NULL,
    nominee_name                VARCHAR(100)    NULL,
    nominee_relationship        VARCHAR(50)     NULL,

    CONSTRAINT pk_policy_travelers PRIMARY KEY (id),
    CONSTRAINT uq_pt_sequence UNIQUE (policy_id, traveler_sequence),
    CONSTRAINT fk_pt_policy FOREIGN KEY (policy_id) REFERENCES ins_policy.policies (id) ON DELETE CASCADE
);

CREATE INDEX idx_pt_policy_id ON ins_policy.policy_travelers (policy_id);

COMMENT ON TABLE ins_policy.policy_travelers IS 'Locked traveler details at policy issuance. All fields mandatory (unlike quote_travelers).';

-- =============================================================================
-- policy_coverage_details
-- Coverage details locked at issuance. These are the authoritative coverage
-- terms for claims processing. Claims always use policy_snapshot, not live.
-- =============================================================================
CREATE TABLE ins_policy.policy_coverage_details (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    policy_id           UUID            NOT NULL,
    coverage_type_id    UUID            NOT NULL,
    coverage_code       VARCHAR(50)     NOT NULL,
    coverage_name       VARCHAR(150)    NOT NULL,
    coverage_limit      DECIMAL(15,2)   NOT NULL,
    deductible          DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
    currency            CHAR(3)         NOT NULL DEFAULT 'INR',
    is_mandatory        BOOLEAN         NOT NULL DEFAULT FALSE,

    CONSTRAINT pk_policy_coverage_details PRIMARY KEY (id),
    CONSTRAINT uq_pcd_policy_coverage UNIQUE (policy_id, coverage_type_id),
    CONSTRAINT fk_pcd_policy FOREIGN KEY (policy_id) REFERENCES ins_policy.policies (id) ON DELETE CASCADE
);

CREATE INDEX idx_pcd_policy_id ON ins_policy.policy_coverage_details (policy_id);

COMMENT ON TABLE ins_policy.policy_coverage_details IS 'Coverage details locked at policy issuance. Authoritative source for claims adjudication.';

-- =============================================================================
-- policy_addon_selections
-- Add-ons locked at issuance. Denormalized (code + name) for immutability.
-- =============================================================================
CREATE TABLE ins_policy.policy_addon_selections (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    policy_id       UUID            NOT NULL,
    addon_id        UUID            NOT NULL,
    addon_code      VARCHAR(50)     NOT NULL,
    addon_name      VARCHAR(150)    NOT NULL,
    addon_premium   DECIMAL(10,2)   NOT NULL,

    CONSTRAINT pk_policy_addon_selections PRIMARY KEY (id),
    CONSTRAINT uq_pas_policy_addon UNIQUE (policy_id, addon_id),
    CONSTRAINT fk_pas_policy FOREIGN KEY (policy_id) REFERENCES ins_policy.policies (id) ON DELETE CASCADE
);

CREATE INDEX idx_pas_policy_id ON ins_policy.policy_addon_selections (policy_id);

COMMENT ON TABLE ins_policy.policy_addon_selections IS 'Add-ons locked at issuance. Denormalized to preserve accuracy even after catalog changes.';

-- =============================================================================
-- policy_premium_breakdown
-- Full itemized premium breakdown locked at issuance.
-- =============================================================================
CREATE TABLE ins_policy.policy_premium_breakdown (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    policy_id               UUID            NOT NULL,
    base_premium            DECIMAL(12,2)   NOT NULL,
    zone_loading            DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    risk_loading            DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    age_loading             DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    duration_loading        DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    coverage_loading        DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    addon_premium_total     DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    discount_amount         DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    tax_amount              DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    gross_premium           DECIMAL(12,2)   NOT NULL,
    net_premium             DECIMAL(12,2)   NOT NULL,
    breakdown_json          JSONB           NULL,

    CONSTRAINT pk_ppb PRIMARY KEY (id),
    CONSTRAINT uq_ppb_policy UNIQUE (policy_id),
    CONSTRAINT fk_ppb_policy FOREIGN KEY (policy_id) REFERENCES ins_policy.policies (id) ON DELETE CASCADE
);

CREATE INDEX idx_ppb_breakdown_gin ON ins_policy.policy_premium_breakdown USING GIN (breakdown_json)
    WHERE breakdown_json IS NOT NULL;

COMMENT ON TABLE ins_policy.policy_premium_breakdown IS 'Locked premium breakdown at issuance. breakdown_json has rule-by-rule explainability.';

-- =============================================================================
-- policy_snapshots
-- THE most critical table for claims integrity.
-- Immutable JSON snapshot at each significant lifecycle event.
-- Claims service ALWAYS reads from here — never from live policy tables.
-- snapshot_version starts at 1 (issuance); increments on endorsement/renewal.
-- =============================================================================
CREATE TABLE ins_policy.policy_snapshots (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    policy_id           UUID            NOT NULL,
    snapshot_version    INT             NOT NULL DEFAULT 1,
    snapshot_type       VARCHAR(20)     NOT NULL,
                        -- ISSUANCE | ENDORSEMENT | RENEWAL | CANCELLATION
    snapshot_data       JSONB           NOT NULL,
    snapshotted_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    snapshotted_by      UUID            NULL,

    CONSTRAINT pk_policy_snapshots PRIMARY KEY (id),
    CONSTRAINT uq_ps_policy_version UNIQUE (policy_id, snapshot_version),
    CONSTRAINT chk_ps_type CHECK (snapshot_type IN ('ISSUANCE','ENDORSEMENT','RENEWAL','CANCELLATION')),
    CONSTRAINT fk_ps_policy FOREIGN KEY (policy_id) REFERENCES ins_policy.policies (id)
);

CREATE INDEX idx_ps_policy_id ON ins_policy.policy_snapshots (policy_id);
CREATE INDEX idx_ps_snapshot_gin ON ins_policy.policy_snapshots USING GIN (snapshot_data);

-- Immutable: no updates allowed
CREATE TRIGGER trg_policy_snapshots_immutable
    BEFORE UPDATE ON ins_policy.policy_snapshots
    FOR EACH ROW EXECUTE FUNCTION ins_common.prevent_update();

COMMENT ON TABLE ins_policy.policy_snapshots IS 'CRITICAL: Immutable policy state snapshots. Claims-service ALWAYS reads coverage terms from here, never from live tables.';

-- =============================================================================
-- policy_status_history
-- Immutable audit trail of all policy status changes.
-- =============================================================================
CREATE TABLE ins_policy.policy_status_history (
    id          UUID            NOT NULL DEFAULT gen_random_uuid(),
    policy_id   UUID            NOT NULL,
    from_status VARCHAR(30)     NULL,
    to_status   VARCHAR(30)     NOT NULL,
    changed_by  UUID            NULL,
    changed_at  TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    reason      TEXT            NULL,

    CONSTRAINT pk_policy_status_history PRIMARY KEY (id),
    CONSTRAINT fk_psh_policy FOREIGN KEY (policy_id) REFERENCES ins_policy.policies (id)
);

CREATE INDEX idx_psh_policy_id ON ins_policy.policy_status_history (policy_id, changed_at DESC);

-- Status history is append-only — no deletes
CREATE TRIGGER trg_policy_status_history_no_delete
    BEFORE DELETE ON ins_policy.policy_status_history
    FOR EACH ROW EXECUTE FUNCTION ins_common.prevent_delete();

COMMENT ON TABLE ins_policy.policy_status_history IS 'Append-only policy status audit trail. Deletes blocked by trigger.';

-- =============================================================================
-- policy_wordings
-- Versioned policy wording documents. The wording version active at issuance
-- is linked to the policy and captured in its snapshot.
-- =============================================================================
CREATE TABLE ins_policy.policy_wordings (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    wording_code        VARCHAR(50)     NOT NULL,
    product_type_code   VARCHAR(50)     NULL,
    version             INT             NOT NULL,
    title               VARCHAR(200)    NOT NULL,
    content             TEXT            NOT NULL,
    effective_from      DATE            NOT NULL,
    effective_to        DATE            NULL,
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    published_by        UUID            NULL,
    published_at        TIMESTAMPTZ     NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_policy_wordings PRIMARY KEY (id),
    CONSTRAINT uq_pw_code_version UNIQUE (wording_code, version)
);

CREATE INDEX idx_pw_active ON ins_policy.policy_wordings (wording_code, is_active);

COMMENT ON TABLE ins_policy.policy_wordings IS 'Versioned legal policy wording documents. Version at issuance captured in policy_snapshots.';

-- =============================================================================
-- policy_agent_bindings
-- NEW: Records which agent bound a policy. Created at payment confirmation.
-- agent_code: denormalized from agent profile for fast reporting queries.
-- commission_rate: rate applied at binding time (% varies by plan_code).
-- =============================================================================
CREATE TABLE ins_policy.policy_agent_bindings (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    policy_id           UUID            NOT NULL,
    agent_user_id       UUID            NOT NULL,
    agent_code          VARCHAR(50)     NOT NULL,
                        -- Denormalized from agent profile
    bound_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    commission_rate     NUMERIC(5,2)    NOT NULL,
                        -- Commission % locked at binding time
    notes               TEXT            NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_policy_agent_bindings PRIMARY KEY (id),
    CONSTRAINT uq_pab_policy UNIQUE (policy_id),
                        -- One binding per policy
    CONSTRAINT fk_pab_policy FOREIGN KEY (policy_id) REFERENCES ins_policy.policies (id)
);

CREATE INDEX idx_pab_agent ON ins_policy.policy_agent_bindings (agent_user_id, bound_at DESC);
CREATE INDEX idx_pab_policy ON ins_policy.policy_agent_bindings (policy_id);

COMMENT ON TABLE ins_policy.policy_agent_bindings IS 'NEW: Agent binding record per policy. One binding per policy. commission_rate locked at binding time.';

-- =============================================================================
-- agent_commissions
-- NEW: Commission record per policy per agent.
-- Created when a policy becomes ACTIVE. Updated when payment is processed.
-- status lifecycle: PENDING → CALCULATED → APPROVED → PAID | CANCELLED
-- =============================================================================
CREATE TABLE ins_policy.agent_commissions (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    policy_id           UUID            NOT NULL,
    agent_user_id       UUID            NOT NULL,
    agent_code          VARCHAR(50)     NOT NULL,
    plan_code           VARCHAR(50)     NOT NULL,
                        -- Plan code at time of commission calculation
    commission_rate     NUMERIC(5,2)    NOT NULL,
                        -- Percentage (e.g., 10.00, 12.00, 15.00)
    net_premium         DECIMAL(12,2)   NOT NULL,
                        -- Net premium on which commission is calculated
    commission_amount   DECIMAL(12,2)   NOT NULL,
                        -- = net_premium × commission_rate / 100
    currency            CHAR(3)         NOT NULL DEFAULT 'INR',
    status              VARCHAR(20)     NOT NULL DEFAULT 'PENDING',
                        -- PENDING | CALCULATED | APPROVED | PAID | CANCELLED
    approved_by         UUID            NULL,
    approved_at         TIMESTAMPTZ     NULL,
    paid_at             TIMESTAMPTZ     NULL,
    payment_reference   VARCHAR(100)    NULL,
    notes               TEXT            NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_agent_commissions PRIMARY KEY (id),
    CONSTRAINT uq_ac_policy UNIQUE (policy_id),
    CONSTRAINT chk_ac_status CHECK (status IN (
        'PENDING','CALCULATED','APPROVED','PAID','CANCELLED'
    )),
    CONSTRAINT fk_ac_policy FOREIGN KEY (policy_id) REFERENCES ins_policy.policies (id),
    CONSTRAINT chk_ac_commission_amount CHECK (commission_amount >= 0)
);

CREATE INDEX idx_ac_agent ON ins_policy.agent_commissions (agent_user_id, status);
CREATE INDEX idx_ac_plan_code ON ins_policy.agent_commissions (plan_code);
-- Partial index: unpaid commissions
CREATE INDEX idx_ac_pending ON ins_policy.agent_commissions (agent_user_id)
    WHERE status IN ('PENDING','CALCULATED','APPROVED');

CREATE TRIGGER trg_agent_commissions_updated_at
    BEFORE UPDATE ON ins_policy.agent_commissions
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

COMMENT ON TABLE ins_policy.agent_commissions IS
    'NEW: Commission record per policy. Rates: Basic=10%, Plus=12%, Pro=15%.
     commission_amount = net_premium × commission_rate / 100.';
