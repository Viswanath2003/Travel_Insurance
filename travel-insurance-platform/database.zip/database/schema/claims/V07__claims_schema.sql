-- =============================================================================
-- V07__claims_schema.sql
-- Schema: ins_claims
-- Service: claims-service
-- Description: Full claims lifecycle — submission, document review, investigation
--              assignment, decision (approve/partially approve/reject), payment,
--              settlement, and closure.
--
-- NEW vs MySQL:
--   + claim_adjuster_notes  — NEW: internal adjuster notes per claim
--   + claim_payments.payment_reference  — tracks payout transaction reference
--   + claim_decisions.partial_amount  — explicit partial approval amount
--   + claims.is_high_value  — BOOLEAN flag for high-value fast-track (>₹1L)
--   + All TINYINT(1) → BOOLEAN, DATETIME → TIMESTAMPTZ
--   + JSON → JSONB
--   + VARCHAR(36) IDs → UUID
--   + status CHECK constraint aligned with webapp statuses
-- =============================================================================

SET search_path = ins_claims, public;

-- =============================================================================
-- claim_types
-- Master list of claim types (Medical, Baggage, Trip Cancellation, etc.)
-- =============================================================================
CREATE TABLE ins_claims.claim_types (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    code                VARCHAR(80)     NOT NULL,
    name                VARCHAR(120)    NOT NULL,
    description         TEXT            NULL,
    required_docs       JSONB           NULL,
                        -- Array of required document type codes
    default_sla_hours   INT             NOT NULL DEFAULT 48,
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_claim_types PRIMARY KEY (id),
    CONSTRAINT uq_claim_types_code UNIQUE (code)
);

CREATE TRIGGER trg_claim_types_updated_at
    BEFORE UPDATE ON ins_claims.claim_types
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

-- =============================================================================
-- claims
-- Core claims table. One row per claim submission.
-- is_high_value: set TRUE when claimedAmount > 100000 (₹1 lakh threshold).
-- policy_snapshot_id: frozen snapshot of policy at claim time.
-- =============================================================================
CREATE TABLE ins_claims.claims (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    claim_reference         VARCHAR(30)     NOT NULL,
                            -- Format: CLMYYMMDDHHmmssNNN (webapp: CLM125240520044)
    policy_id               UUID            NOT NULL,
    policy_number           VARCHAR(30)     NOT NULL,
    policy_snapshot_id      UUID            NOT NULL,
    customer_id             UUID            NOT NULL,
    claim_type_id           UUID            NOT NULL,
    claim_type_code         VARCHAR(80)     NOT NULL,
    status                  VARCHAR(40)     NOT NULL DEFAULT 'SUBMITTED',
                            -- SUBMITTED | DOCUMENT_REVIEW | DOCUMENT_PENDING
                            -- UNDER_REVIEW | INVESTIGATION_ASSIGNED
                            -- INVESTIGATION_COMPLETE | DECISION_PENDING
                            -- AUTO_APPROVED | AUTO_DECLINED
                            -- APPROVED | PARTIALLY_APPROVED | DECLINED
                            -- PAYMENT_PENDING | SETTLED | CLOSED
    incident_date           DATE            NOT NULL,
    incident_description    TEXT            NULL,
    claimed_amount          NUMERIC(12,2)   NOT NULL,
    approved_amount         NUMERIC(12,2)   NULL,
    assigned_officer_id     UUID            NULL,
    sla_due_at              TIMESTAMPTZ     NULL,
    sla_breached            BOOLEAN         NOT NULL DEFAULT FALSE,
    decision_reason         TEXT            NULL,
    decided_at              TIMESTAMPTZ     NULL,
    decided_by              UUID            NULL,
    decided_by_name         VARCHAR(100)    NULL,
    is_high_value           BOOLEAN         NOT NULL DEFAULT FALSE,
                            -- TRUE when claimed_amount > 100000
    field_investigation_required BOOLEAN   NOT NULL DEFAULT FALSE,
    priority                VARCHAR(10)     NOT NULL DEFAULT 'MEDIUM',
                            -- LOW | MEDIUM | HIGH | CRITICAL
    metadata                JSONB           NULL,
                            -- Extensible: payment method from policy, destination, etc.
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    version                 BIGINT          NOT NULL DEFAULT 0,

    CONSTRAINT pk_claims PRIMARY KEY (id),
    CONSTRAINT uq_claims_reference UNIQUE (claim_reference),
    CONSTRAINT fk_claims_claim_type FOREIGN KEY (claim_type_id)
        REFERENCES ins_claims.claim_types(id),
    CONSTRAINT chk_claims_status CHECK (status IN (
        'SUBMITTED','DOCUMENT_REVIEW','DOCUMENT_PENDING','UNDER_REVIEW',
        'INVESTIGATION_ASSIGNED','INVESTIGATION_COMPLETE','DECISION_PENDING',
        'AUTO_APPROVED','AUTO_DECLINED','APPROVED','PARTIALLY_APPROVED',
        'DECLINED','PAYMENT_PENDING','SETTLED','CLOSED'
    )),
    CONSTRAINT chk_claims_priority CHECK (priority IN ('LOW','MEDIUM','HIGH','CRITICAL')),
    CONSTRAINT chk_claims_amounts CHECK (
        claimed_amount > 0 AND (approved_amount IS NULL OR approved_amount >= 0)
    )
);

CREATE INDEX idx_claims_policy_id       ON ins_claims.claims (policy_id);
CREATE INDEX idx_claims_customer_id     ON ins_claims.claims (customer_id);
CREATE INDEX idx_claims_status          ON ins_claims.claims (status);
CREATE INDEX idx_claims_officer         ON ins_claims.claims (assigned_officer_id) WHERE assigned_officer_id IS NOT NULL;
CREATE INDEX idx_claims_created_at      ON ins_claims.claims (created_at DESC);
CREATE INDEX idx_claims_high_value      ON ins_claims.claims (is_high_value) WHERE is_high_value = TRUE;
CREATE INDEX idx_claims_sla_due         ON ins_claims.claims (sla_due_at) WHERE status NOT IN ('SETTLED','CLOSED','DECLINED','AUTO_DECLINED');

CREATE TRIGGER trg_claims_updated_at
    BEFORE UPDATE ON ins_claims.claims
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

-- =============================================================================
-- claim_travelers
-- Travelers involved in the claim (subset of policy travelers)
-- =============================================================================
CREATE TABLE ins_claims.claim_travelers (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    claim_id            UUID            NOT NULL,
    traveler_name       VARCHAR(100)    NOT NULL,
    age_group           VARCHAR(10)     NOT NULL,
                        -- child | adult | senior
    is_primary_claimant BOOLEAN         NOT NULL DEFAULT FALSE,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_claim_travelers PRIMARY KEY (id),
    CONSTRAINT fk_claim_travelers_claim FOREIGN KEY (claim_id)
        REFERENCES ins_claims.claims(id) ON DELETE CASCADE
);

CREATE INDEX idx_claim_travelers_claim ON ins_claims.claim_travelers (claim_id);

-- =============================================================================
-- claim_documents
-- Documents uploaded against a claim (hospital bills, receipts, ID proofs, etc.)
-- =============================================================================
CREATE TABLE ins_claims.claim_documents (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    claim_id            UUID            NOT NULL,
    document_type_code  VARCHAR(60)     NOT NULL,
    document_name       VARCHAR(200)    NOT NULL,
    storage_key         VARCHAR(500)    NOT NULL,
                        -- S3/blob storage key
    file_size_bytes     BIGINT          NULL,
    mime_type           VARCHAR(100)    NULL,
    uploaded_by         UUID            NOT NULL,
                        -- customer or claims officer
    is_verified         BOOLEAN         NOT NULL DEFAULT FALSE,
    verified_by         UUID            NULL,
    verified_at         TIMESTAMPTZ     NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_claim_documents PRIMARY KEY (id),
    CONSTRAINT fk_claim_documents_claim FOREIGN KEY (claim_id)
        REFERENCES ins_claims.claims(id) ON DELETE CASCADE
);

CREATE INDEX idx_claim_documents_claim ON ins_claims.claim_documents (claim_id);

-- =============================================================================
-- claim_doc_checklist_config
-- Defines required document checklist per claim type
-- =============================================================================
CREATE TABLE ins_claims.claim_doc_checklist_config (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    claim_type_id       UUID            NOT NULL,
    document_type_code  VARCHAR(60)     NOT NULL,
    document_label      VARCHAR(120)    NOT NULL,
    is_mandatory        BOOLEAN         NOT NULL DEFAULT TRUE,
    display_order       SMALLINT        NOT NULL DEFAULT 0,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_claim_doc_checklist PRIMARY KEY (id),
    CONSTRAINT uq_claim_doc_checklist UNIQUE (claim_type_id, document_type_code),
    CONSTRAINT fk_claim_doc_checklist_type FOREIGN KEY (claim_type_id)
        REFERENCES ins_claims.claim_types(id)
);

CREATE TRIGGER trg_claim_doc_checklist_updated_at
    BEFORE UPDATE ON ins_claims.claim_doc_checklist_config
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

-- =============================================================================
-- claim_checklist_status
-- Per-claim document checklist completion status
-- =============================================================================
CREATE TABLE ins_claims.claim_checklist_status (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    claim_id            UUID            NOT NULL,
    document_type_code  VARCHAR(60)     NOT NULL,
    is_received         BOOLEAN         NOT NULL DEFAULT FALSE,
    received_at         TIMESTAMPTZ     NULL,
    notes               TEXT            NULL,
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_claim_checklist_status PRIMARY KEY (id),
    CONSTRAINT uq_claim_checklist_item UNIQUE (claim_id, document_type_code),
    CONSTRAINT fk_claim_checklist_claim FOREIGN KEY (claim_id)
        REFERENCES ins_claims.claims(id) ON DELETE CASCADE
);

CREATE INDEX idx_claim_checklist_claim ON ins_claims.claim_checklist_status (claim_id);

-- =============================================================================
-- claim_workflow_history
-- Immutable status transition log for each claim
-- =============================================================================
CREATE TABLE ins_claims.claim_workflow_history (
    id                  BIGINT          GENERATED ALWAYS AS IDENTITY,
    claim_id            UUID            NOT NULL,
    from_status         VARCHAR(40)     NULL,
                        -- NULL on first transition
    to_status           VARCHAR(40)     NOT NULL,
    action_code         VARCHAR(60)     NOT NULL,
                        -- SUBMIT | DOCUMENT_REQUEST | DOCUMENT_RECEIVED
                        -- ASSIGN_OFFICER | FIELD_ASSIGN | FIELD_COMPLETE
                        -- APPROVE | PARTIAL_APPROVE | DECLINE | SETTLE | CLOSE
    performed_by        UUID            NOT NULL,
    performed_by_name   VARCHAR(100)    NULL,
    performed_by_role   VARCHAR(60)     NULL,
    notes               TEXT            NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_claim_workflow_history PRIMARY KEY (id),
    CONSTRAINT fk_claim_workflow_claim FOREIGN KEY (claim_id)
        REFERENCES ins_claims.claims(id)
);

CREATE INDEX idx_claim_wf_history_claim ON ins_claims.claim_workflow_history (claim_id);

-- =============================================================================
-- claim_decisions
-- One decision record per claim resolution attempt.
-- A claim may have multiple decision records if reopened.
-- partial_amount: set when decision is PARTIALLY_APPROVED.
-- =============================================================================
CREATE TABLE ins_claims.claim_decisions (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    claim_id            UUID            NOT NULL,
    decision            VARCHAR(30)     NOT NULL,
                        -- APPROVE_FULL | APPROVE_PARTIAL | DECLINE | REOPEN
    partial_amount      NUMERIC(12,2)   NULL,
                        -- Set when decision = APPROVE_PARTIAL
    decision_reason     TEXT            NOT NULL,
    decided_by          UUID            NOT NULL,
    decided_by_name     VARCHAR(100)    NULL,
    decided_by_role     VARCHAR(60)     NULL,
    decided_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_claim_decisions PRIMARY KEY (id),
    CONSTRAINT fk_claim_decisions_claim FOREIGN KEY (claim_id)
        REFERENCES ins_claims.claims(id),
    CONSTRAINT chk_claim_decision_type CHECK (decision IN (
        'APPROVE_FULL','APPROVE_PARTIAL','DECLINE','REOPEN'
    ))
);

CREATE INDEX idx_claim_decisions_claim ON ins_claims.claim_decisions (claim_id);

-- =============================================================================
-- claim_adjuster_notes
-- NEW: Internal notes by claims officers during review.
-- Not visible to the customer. Used for investigation tracking.
-- =============================================================================
CREATE TABLE ins_claims.claim_adjuster_notes (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    claim_id            UUID            NOT NULL,
    note_text           TEXT            NOT NULL,
    is_internal         BOOLEAN         NOT NULL DEFAULT TRUE,
    created_by          UUID            NOT NULL,
    created_by_name     VARCHAR(100)    NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_claim_adjuster_notes PRIMARY KEY (id),
    CONSTRAINT fk_claim_notes_claim FOREIGN KEY (claim_id)
        REFERENCES ins_claims.claims(id) ON DELETE CASCADE
);

CREATE INDEX idx_claim_notes_claim ON ins_claims.claim_adjuster_notes (claim_id);

CREATE TRIGGER trg_claim_notes_updated_at
    BEFORE UPDATE ON ins_claims.claim_adjuster_notes
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

-- =============================================================================
-- claim_payments
-- Payout records once a claim is approved and payment is processed by Finance.
-- payment_reference: TXN/PAY reference from payment gateway.
-- =============================================================================
CREATE TABLE ins_claims.claim_payments (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    claim_id                UUID            NOT NULL,
    payment_amount          NUMERIC(12,2)   NOT NULL,
    payment_reference       VARCHAR(60)     NULL,
                            -- e.g. PAY20250520001
    payment_method          VARCHAR(30)     NULL,
                            -- BANK_TRANSFER | CHEQUE | UPI
    bank_account_masked     VARCHAR(20)     NULL,
                            -- Last 4 digits: **** 5678
    processed_by            UUID            NOT NULL,
    processed_by_name       VARCHAR(100)    NULL,
    processed_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    notes                   TEXT            NULL,

    CONSTRAINT pk_claim_payments PRIMARY KEY (id),
    CONSTRAINT fk_claim_payments_claim FOREIGN KEY (claim_id)
        REFERENCES ins_claims.claims(id),
    CONSTRAINT chk_claim_payment_amount CHECK (payment_amount > 0)
);

CREATE INDEX idx_claim_payments_claim ON ins_claims.claim_payments (claim_id);
CREATE INDEX idx_claim_payments_ref ON ins_claims.claim_payments (payment_reference) WHERE payment_reference IS NOT NULL;

-- =============================================================================
-- claim_snapshots
-- Point-in-time snapshot of claim state for audit and dispute purposes.
-- =============================================================================
CREATE TABLE ins_claims.claim_snapshots (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    claim_id            UUID            NOT NULL,
    snapshot_type       VARCHAR(30)     NOT NULL,
                        -- SUBMISSION | DECISION | PAYMENT | CLOSURE
    snapshot_data       JSONB           NOT NULL,
    created_by          UUID            NOT NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_claim_snapshots PRIMARY KEY (id),
    CONSTRAINT fk_claim_snapshots_claim FOREIGN KEY (claim_id)
        REFERENCES ins_claims.claims(id)
);

CREATE INDEX idx_claim_snapshots_claim ON ins_claims.claim_snapshots (claim_id);

-- =============================================================================
-- claim_sla_config
-- Configurable SLA targets per claim type and priority.
-- =============================================================================
CREATE TABLE ins_claims.claim_sla_config (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    claim_type_id       UUID            NULL,
                        -- NULL = applies to all claim types
    priority            VARCHAR(10)     NOT NULL,
                        -- LOW | MEDIUM | HIGH | CRITICAL
    resolution_hours    INT             NOT NULL,
    escalation_hours    INT             NOT NULL,
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_claim_sla_config PRIMARY KEY (id),
    CONSTRAINT fk_claim_sla_type FOREIGN KEY (claim_type_id)
        REFERENCES ins_claims.claim_types(id),
    CONSTRAINT chk_claim_sla_priority CHECK (priority IN ('LOW','MEDIUM','HIGH','CRITICAL'))
);

CREATE TRIGGER trg_claim_sla_updated_at
    BEFORE UPDATE ON ins_claims.claim_sla_config
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();
