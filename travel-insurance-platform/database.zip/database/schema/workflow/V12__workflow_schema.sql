-- =============================================================================
-- V12__workflow_schema.sql
-- Schema: ins_workflow
-- Service: workflow-service / shared infrastructure
-- Description: Workflow state machine definitions, platform-wide configuration,
--              and risk routing configuration tables.
--
-- NEW vs MySQL:
--   + risk_routing_config — NEW: configurable score thresholds for risk routing
--     (replaces hardcoded 0-30/31-50/51-70/71+ thresholds from webapp)
--   + coverage_limit_risk_multipliers — NEW: configurable slider max multipliers
--     per risk band (LOW=1.5×, MEDIUM=1.25×, HIGH=1.1×, VERY_HIGH=1.0×)
--   + All TINYINT(1) → BOOLEAN, DATETIME → TIMESTAMPTZ
--   + JSON → JSONB
-- =============================================================================

SET search_path = ins_workflow, public;

-- =============================================================================
-- workflow_definitions
-- Named workflows (POLICY_ISSUANCE, CLAIMS_PROCESSING, UNDERWRITING, etc.)
-- Each workflow has a set of states and allowed transitions.
-- =============================================================================
CREATE TABLE ins_workflow.workflow_definitions (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    workflow_code       VARCHAR(60)     NOT NULL,
    workflow_name       VARCHAR(100)    NOT NULL,
    domain              VARCHAR(30)     NOT NULL,
                        -- POLICY | UNDERWRITING | CLAIMS | FIELD
    description         TEXT            NULL,
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    version             INT             NOT NULL DEFAULT 1,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_workflow_definitions PRIMARY KEY (id),
    CONSTRAINT uq_workflow_code UNIQUE (workflow_code)
);

CREATE TRIGGER trg_workflow_defs_updated_at
    BEFORE UPDATE ON ins_workflow.workflow_definitions
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

-- =============================================================================
-- workflow_states
-- States within each workflow definition
-- =============================================================================
CREATE TABLE ins_workflow.workflow_states (
    id                  UUID            NOT NULL DEFAULT gen_random_uuid(),
    workflow_id         UUID            NOT NULL,
    state_code          VARCHAR(40)     NOT NULL,
    state_name          VARCHAR(80)     NOT NULL,
    state_type          VARCHAR(10)     NOT NULL,
                        -- INITIAL | INTERMEDIATE | TERMINAL
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    display_order       SMALLINT        NOT NULL DEFAULT 0,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_workflow_states PRIMARY KEY (id),
    CONSTRAINT uq_workflow_state UNIQUE (workflow_id, state_code),
    CONSTRAINT fk_workflow_states_def FOREIGN KEY (workflow_id)
        REFERENCES ins_workflow.workflow_definitions(id),
    CONSTRAINT chk_workflow_state_type CHECK (state_type IN ('INITIAL','INTERMEDIATE','TERMINAL'))
);

CREATE INDEX idx_workflow_states_workflow ON ins_workflow.workflow_states (workflow_id);

-- =============================================================================
-- workflow_transitions
-- Allowed transitions between states.
-- required_role: which platform role can trigger this transition.
-- =============================================================================
CREATE TABLE ins_workflow.workflow_transitions (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    workflow_id             UUID            NOT NULL,
    from_state_id           UUID            NOT NULL,
    to_state_id             UUID            NOT NULL,
    transition_code         VARCHAR(60)     NOT NULL,
    transition_name         VARCHAR(100)    NOT NULL,
    required_role           VARCHAR(60)     NULL,
                            -- ROLE_CLAIMS_OFFICER | ROLE_UNDERWRITER_L1 | etc.
    required_permission     VARCHAR(80)     NULL,
                            -- CLAIM_DECIDE | UW_APPROVE | UW_REFER | etc.
    condition_expression    TEXT            NULL,
                            -- Optional: SpEL condition e.g. "riskScore > 70"
    is_active               BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_workflow_transitions PRIMARY KEY (id),
    CONSTRAINT uq_workflow_transition UNIQUE (workflow_id, from_state_id, transition_code),
    CONSTRAINT fk_workflow_trans_def FOREIGN KEY (workflow_id)
        REFERENCES ins_workflow.workflow_definitions(id),
    CONSTRAINT fk_workflow_trans_from FOREIGN KEY (from_state_id)
        REFERENCES ins_workflow.workflow_states(id),
    CONSTRAINT fk_workflow_trans_to FOREIGN KEY (to_state_id)
        REFERENCES ins_workflow.workflow_states(id)
);

CREATE INDEX idx_workflow_transitions_wf ON ins_workflow.workflow_transitions (workflow_id);

-- =============================================================================
-- risk_routing_config
-- NEW: Configurable score thresholds for risk-based policy routing.
-- Maps directly to the hardcoded thresholds in webapp processPayment():
--   0-30  → AUTO_ISSUE (Active)
--   31-50 → CO_REVIEW  (Pending CO Review → notify ROLE_CLAIMS_OFFICER)
--   51-70 → UW_L1      (Pending UW Review → notify ROLE_UNDERWRITER_L1)
--   71+   → UW_L2      (Pending L2 Review → notify ROLE_UNDERWRITER_L2 + ROLE_FIELD_OFFICER)
-- Changing the thresholds here changes platform behavior without code deployment.
-- =============================================================================
CREATE TABLE ins_workflow.risk_routing_config (
    id                      UUID            NOT NULL DEFAULT gen_random_uuid(),
    routing_band            VARCHAR(20)     NOT NULL,
                            -- AUTO_ISSUE | CO_REVIEW | UW_L1 | UW_L2
    score_min               INT             NOT NULL,
    score_max               INT             NOT NULL,
                            -- score_max = 999 for the highest band (open-ended)
    target_status           VARCHAR(40)     NOT NULL,
                            -- Policy status to assign: ACTIVE | PENDING_CO_REVIEW
                            -- PENDING_UW_REVIEW | PENDING_L2_REVIEW
    notify_roles            TEXT[]          NOT NULL DEFAULT '{}',
                            -- PostgreSQL array: {ROLE_UNDERWRITER_L1, ...}
    description             VARCHAR(200)    NULL,
    is_active               BOOLEAN         NOT NULL DEFAULT TRUE,
    effective_from          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    effective_to            TIMESTAMPTZ     NULL,
                            -- NULL = currently active
    created_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_risk_routing_config PRIMARY KEY (id),
    CONSTRAINT uq_risk_routing_band UNIQUE (routing_band)
                            -- PARTIAL where is_active = TRUE
);

CREATE INDEX idx_risk_routing_active ON ins_workflow.risk_routing_config (score_min, score_max) WHERE is_active = TRUE;

CREATE TRIGGER trg_risk_routing_updated_at
    BEFORE UPDATE ON ins_workflow.risk_routing_config
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

-- =============================================================================
-- coverage_limit_risk_multipliers
-- NEW: Configurable slider max multipliers per risk band.
-- Webapp uses: LOW=1.5×, MEDIUM=1.25×, HIGH=1.1×, VERY_HIGH=1.0×
-- Stored here so they can be changed without redeployment.
-- =============================================================================
CREATE TABLE ins_workflow.coverage_limit_risk_multipliers (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    risk_level      VARCHAR(12)     NOT NULL,
                    -- LOW | MEDIUM | HIGH | VERY_HIGH
    multiplier      NUMERIC(4,2)    NOT NULL,
                    -- 1.50, 1.25, 1.10, 1.00
    description     VARCHAR(200)    NULL,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_coverage_multipliers PRIMARY KEY (id),
    CONSTRAINT uq_coverage_multiplier_level UNIQUE (risk_level),
    CONSTRAINT chk_coverage_risk_level CHECK (risk_level IN ('LOW','MEDIUM','HIGH','VERY_HIGH')),
    CONSTRAINT chk_coverage_multiplier CHECK (multiplier > 0)
);

CREATE TRIGGER trg_coverage_mult_updated_at
    BEFORE UPDATE ON ins_workflow.coverage_limit_risk_multipliers
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();

-- =============================================================================
-- platform_configurations
-- Global key-value configuration store.
-- Used for: GST rate (18%), online discount (5%), agent commission rates,
-- SLA defaults, and other platform-wide settings.
-- =============================================================================
CREATE TABLE ins_workflow.platform_configurations (
    id              UUID            NOT NULL DEFAULT gen_random_uuid(),
    config_key      VARCHAR(100)    NOT NULL,
    config_value    TEXT            NOT NULL,
    value_type      VARCHAR(10)     NOT NULL DEFAULT 'STRING',
                    -- STRING | NUMBER | BOOLEAN | JSON
    description     VARCHAR(300)    NULL,
    group_name      VARCHAR(60)     NULL,
                    -- PRICING | COMMISSION | SLA | NOTIFICATIONS | GENERAL
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT pk_platform_config PRIMARY KEY (id),
    CONSTRAINT uq_platform_config_key UNIQUE (config_key),
    CONSTRAINT chk_platform_config_type CHECK (value_type IN ('STRING','NUMBER','BOOLEAN','JSON'))
);

CREATE TRIGGER trg_platform_config_updated_at
    BEFORE UPDATE ON ins_workflow.platform_configurations
    FOR EACH ROW EXECUTE FUNCTION ins_common.set_updated_at();
