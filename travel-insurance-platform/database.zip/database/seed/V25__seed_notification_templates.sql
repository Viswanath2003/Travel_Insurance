-- =============================================================================
-- V25__seed_notification_templates.sql
-- Schema: ins_notification
-- Description: Seed notification templates for all platform events.
--              Templates derived from addNotification() calls in webapp.
--              Uses {{variable}} placeholder syntax for runtime substitution.
-- =============================================================================

SET search_path = ins_notification, public;

INSERT INTO ins_notification.notification_templates
    (id, event_code, title_template, body_template, target_role, channel, is_active)
VALUES

-- ============================================================
-- POLICY EVENTS
-- ============================================================
('h1i2j3k4-0001-0000-0000-000000000001',
 'POLICY_ACTIVE',
 'Policy Active!',
 '{{planName}} ({{policyNumber}}) is now active. Your travel is covered.',
 'ROLE_CUSTOMER', 'IN_APP', TRUE),

('h1i2j3k4-0002-0000-0000-000000000002',
 'POLICY_SUBMITTED_REVIEW',
 'Policy Submitted for Review',
 '{{planName}} ({{policyNumber}}) is pending review. {{statusLabel}}',
 'ROLE_CUSTOMER', 'IN_APP', TRUE),

('h1i2j3k4-0003-0000-0000-000000000003',
 'POLICY_APPROVED',
 'Policy Approved!',
 'Your policy {{policyNumber}} has been approved and is now active. {{remarks}}',
 'ROLE_CUSTOMER', 'IN_APP', TRUE),

('h1i2j3k4-0004-0000-0000-000000000004',
 'POLICY_APPROVED_CONDITIONAL',
 'Policy Approved with Conditions',
 'Policy {{policyNumber}} approved. Conditions: {{remarks}}',
 'ROLE_CUSTOMER', 'IN_APP', TRUE),

('h1i2j3k4-0005-0000-0000-000000000005',
 'POLICY_REJECTED',
 'Policy Application Rejected',
 'We regret to inform that policy {{policyNumber}} could not be approved. Reason: {{remarks}}',
 'ROLE_CUSTOMER', 'IN_APP', TRUE),

('h1i2j3k4-0006-0000-0000-000000000006',
 'POLICY_UNDER_SENIOR_REVIEW',
 'Application Under Senior Review',
 'Policy {{policyNumber}} has been referred to our Senior Underwriter. You will hear back shortly.',
 'ROLE_CUSTOMER', 'IN_APP', TRUE),

-- ============================================================
-- UNDERWRITING EVENTS
-- ============================================================
('h1i2j3k4-0101-0000-0000-000000000101',
 'UW_CASE_CREATED_L1',
 'New Policy in Queue',
 '{{policyNumber}} · {{planName}} · Risk: {{riskLevel}} (Score: {{riskScore}}) · {{customerName}}',
 'ROLE_UNDERWRITER_L1', 'IN_APP', TRUE),

('h1i2j3k4-0102-0000-0000-000000000102',
 'UW_CASE_ESCALATED_L2',
 '⚠ Escalated by L1 — Needs L2 Decision',
 '{{policyNumber}} · Risk: {{riskLevel}} · Escalated by {{escalatedBy}}: {{remarks}}',
 'ROLE_UNDERWRITER_L2', 'IN_APP', TRUE),

('h1i2j3k4-0103-0000-0000-000000000103',
 'UW_VERY_HIGH_RISK_L2',
 '⚠ Very High Risk — Review Required',
 '{{policyNumber}} · Risk Score: {{riskScore}} · {{customerName}} — Field assessment may be needed.',
 'ROLE_UNDERWRITER_L2', 'IN_APP', TRUE),

-- ============================================================
-- CLAIMS EVENTS
-- ============================================================
('h1i2j3k4-0201-0000-0000-000000000201',
 'CLAIM_SUBMITTED',
 'Claim Submitted',
 'Your claim {{claimReference}} for ₹{{claimedAmount}} has been submitted successfully.',
 'ROLE_CUSTOMER', 'IN_APP', TRUE),

('h1i2j3k4-0202-0000-0000-000000000202',
 'CLAIM_NEW_CO_REVIEW',
 'New Claim Submitted',
 '{{claimReference}} · {{claimType}} · ₹{{claimedAmount}} · Customer: {{customerName}}',
 'ROLE_CLAIMS_OFFICER', 'IN_APP', TRUE),

('h1i2j3k4-0203-0000-0000-000000000203',
 'CLAIM_APPROVED',
 'Claim Approved',
 'Your claim {{claimReference}} has been approved. Settlement amount: ₹{{approvedAmount}}.',
 'ROLE_CUSTOMER', 'IN_APP', TRUE),

('h1i2j3k4-0204-0000-0000-000000000204',
 'CLAIM_PARTIALLY_APPROVED',
 'Claim Partially Approved',
 'Your claim {{claimReference}} has been partially approved for ₹{{approvedAmount}}. {{remarks}}',
 'ROLE_CUSTOMER', 'IN_APP', TRUE),

('h1i2j3k4-0205-0000-0000-000000000205',
 'CLAIM_DECLINED',
 'Claim Declined',
 'We regret that your claim {{claimReference}} has been declined. Reason: {{remarks}}',
 'ROLE_CUSTOMER', 'IN_APP', TRUE),

('h1i2j3k4-0206-0000-0000-000000000206',
 'CLAIM_SETTLED',
 'Claim Settled — Payment Processed',
 'Your claim {{claimReference}} has been settled. ₹{{settledAmount}} has been transferred to your account.',
 'ROLE_CUSTOMER', 'IN_APP', TRUE),

-- ============================================================
-- FIELD OFFICER EVENTS
-- ============================================================
('h1i2j3k4-0301-0000-0000-000000000301',
 'FIELD_ASSIGNMENT_CREATED',
 'New Field Investigation Assigned',
 'Claim {{claimReference}} · {{investigationType}} · Location: {{location}} · Due: {{dueAt}}',
 'ROLE_FIELD_OFFICER', 'IN_APP', TRUE),

('h1i2j3k4-0302-0000-0000-000000000302',
 'POLICY_FIELD_ALERT',
 'Potential Field Visit Required',
 'Policy {{policyNumber}} has Very High risk (Score: {{riskScore}}). Await UW L2 decision.',
 'ROLE_FIELD_OFFICER', 'IN_APP', TRUE),

-- ============================================================
-- FINANCE EVENTS
-- ============================================================
('h1i2j3k4-0401-0000-0000-000000000401',
 'PREMIUM_RECEIVED',
 'Premium Received',
 '₹{{premiumAmount}} collected for policy {{policyNumber}} ({{planName}})',
 'ROLE_FINANCE', 'IN_APP', TRUE),

('h1i2j3k4-0402-0000-0000-000000000402',
 'PAYOUT_PENDING',
 'Claim Payout Pending',
 'Claim {{claimReference}} approved for ₹{{approvedAmount}}. Payout pending processing.',
 'ROLE_FINANCE', 'IN_APP', TRUE),

-- ============================================================
-- AGENT / RM EVENTS
-- ============================================================
('h1i2j3k4-0501-0000-0000-000000000501',
 'NEW_POLICY_AGENT',
 'New Policy Sold',
 '{{customerName}} purchased {{planName}} — ₹{{premiumAmount}}',
 'ROLE_AGENT', 'IN_APP', TRUE),

('h1i2j3k4-0502-0000-0000-000000000502',
 'NEW_POLICY_RM',
 'New Policy Sold',
 '{{customerName}} purchased {{planName}} — ₹{{premiumAmount}}',
 'ROLE_RELATIONSHIP_MANAGER', 'IN_APP', TRUE),

('h1i2j3k4-0503-0000-0000-000000000503',
 'RENEWAL_REMINDER',
 'Policy Renewal Reminder',
 '{{policyNumber}} ({{planName}}) for {{customerName}} expires in {{daysLeft}} days.',
 'ROLE_RELATIONSHIP_MANAGER', 'IN_APP', TRUE),

-- ============================================================
-- PROFILE / ADMIN EVENTS
-- ============================================================
('h1i2j3k4-0601-0000-0000-000000000601',
 'PROFILE_UPDATE_REQUEST',
 'Profile Update Request',
 'Customer {{customerName}} ({{customerEmail}}) has submitted a profile update request.',
 'ROLE_ADMIN', 'IN_APP', TRUE),

('h1i2j3k4-0602-0000-0000-000000000602',
 'PROFILE_UPDATE_APPROVED',
 'Profile Update Approved',
 'Your profile update request has been reviewed and approved by admin.',
 'ROLE_CUSTOMER', 'IN_APP', TRUE),

('h1i2j3k4-0603-0000-0000-000000000603',
 'POLICY_REQUIRES_REVIEW',
 'Policy Requires Review',
 '{{policyNumber}} · {{planName}} · Risk: {{riskLevel}} (Score: {{riskScore}}) · Customer: {{customerName}}',
 'ROLE_CLAIMS_OFFICER', 'IN_APP', TRUE)

ON CONFLICT (event_code, channel) DO NOTHING;
