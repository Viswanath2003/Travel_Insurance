-- =============================================================================
-- V21__seed_product_catalog.sql
-- Schema: ins_product
-- Description: Seed product types, insurance products, plans (6 plans matching
--              webapp PLANS object), coverage types, add-ons, destination zones,
--              and zone-country mappings.
--
-- Source of truth: webapp/portals/customer/app.js — PLANS, ADDONS, DESTINATIONS
-- Plan daily rates, coverage limits, and multipliers exactly match the webapp.
-- =============================================================================

SET search_path = ins_product, public;

-- =============================================================================
-- Product Type
-- =============================================================================
INSERT INTO ins_product.product_types (id, type_code, type_name, description, is_active)
VALUES
('c1d2e3f4-0001-0000-0000-000000000001', 'TRAVEL', 'Travel Insurance', 'Comprehensive travel insurance products for domestic and international travel', TRUE)
ON CONFLICT (type_code) DO NOTHING;

-- =============================================================================
-- Insurance Product
-- =============================================================================
INSERT INTO ins_product.insurance_products (id, product_type_id, product_code, product_name, description, is_active)
VALUES
('c1d2e3f4-0100-0000-0000-000000000100',
 'c1d2e3f4-0001-0000-0000-000000000001',
 'TRAVEL_INSURE',
 'TravelInsure',
 'Multi-tier travel insurance platform covering Medical, Trip Cancellation, Baggage, and more',
 TRUE)
ON CONFLICT (product_code) DO NOTHING;

-- =============================================================================
-- Plans
-- Matches webapp PLANS object exactly (id: basic, plus, pro, family, senior, corporate)
-- daily_rate_paise: stored in paise (₹ × 100) for precision; displayed as ₹/day
-- =============================================================================
INSERT INTO ins_product.plans (id, product_id, plan_code, plan_name, description,
    base_premium_amount, currency_code, is_active)
VALUES
('c1d2e3f4-1001-0000-0000-000000000001',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'BASIC',
 'TravelInsure Basic',
 'Essential travel coverage — budget-friendly protection for short trips. Daily rate ₹150/traveler.',
 15000, 'INR', TRUE),

('c1d2e3f4-1002-0000-0000-000000000002',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'PLUS',
 'TravelInsure Plus',
 'Popular all-round coverage with higher limits and pre-existing conditions cover. Daily rate ₹300/traveler.',
 30000, 'INR', TRUE),

('c1d2e3f4-1003-0000-0000-000000000003',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'PRO',
 'TravelInsure Pro',
 'Premium coverage with 2 Crore medical limit and adventure sports cover. Daily rate ₹550/traveler.',
 55000, 'INR', TRUE),

('c1d2e3f4-1004-0000-0000-000000000004',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'FAMILY',
 'TravelInsure Family',
 'Comprehensive family coverage for groups traveling together. Daily rate ₹400/day.',
 40000, 'INR', TRUE),

('c1d2e3f4-1005-0000-0000-000000000005',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'SENIOR',
 'TravelInsure Senior',
 'Tailored coverage for senior travelers (61+) with enhanced medical benefits. Daily rate ₹480/day.',
 48000, 'INR', TRUE),

('c1d2e3f4-1006-0000-0000-000000000006',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'CORPORATE',
 'Corporate Group',
 'Group travel insurance for corporate teams and business travelers. Daily rate ₹220/traveler.',
 22000, 'INR', TRUE)
ON CONFLICT (plan_code) DO NOTHING;

-- =============================================================================
-- Coverage Types (from webapp plan.limits objects)
-- =============================================================================
INSERT INTO ins_product.coverage_types (id, coverage_code, coverage_name, description, is_active)
VALUES
('c1d2e3f4-2001-0000-0000-000000000001', 'EMERGENCY_MEDICAL',     'Emergency Medical Treatment',     'In-patient and emergency medical treatment abroad',                    TRUE),
('c1d2e3f4-2002-0000-0000-000000000002', 'TRIP_CANCELLATION',     'Trip Cancellation',               'Reimbursement for non-refundable expenses due to cancellation',        TRUE),
('c1d2e3f4-2003-0000-0000-000000000003', 'BAGGAGE_LOSS',          'Baggage & Personal Effects',      'Loss, damage, or theft of checked baggage and personal effects',       TRUE),
('c1d2e3f4-2004-0000-0000-000000000004', 'PREEXISTING_CONDITIONS','Pre-existing Medical Conditions', 'Coverage for declared pre-existing medical conditions',                TRUE),
('c1d2e3f4-2005-0000-0000-000000000005', 'ADVENTURE_SPORTS',      'Adventure Sports Cover',          'Accidental injury during specified adventure/extreme sports activities',TRUE),
('c1d2e3f4-2006-0000-0000-000000000006', 'EVACUATION',            'Emergency Evacuation',            'Medical evacuation and repatriation costs',                           TRUE),
('c1d2e3f4-2007-0000-0000-000000000007', 'FLIGHT_DELAY',          'Flight Delay',                    'Compensation for delays exceeding the threshold hours',               TRUE),
('c1d2e3f4-2008-0000-0000-000000000008', 'PERSONAL_LIABILITY',    'Personal Liability',              'Third-party bodily injury or property damage liability',              TRUE),
('c1d2e3f4-2009-0000-0000-000000000009', 'ACCIDENTAL_DEATH',      'Accidental Death & Disablement',  'Lump sum on accidental death or permanent total disablement',          TRUE),
('c1d2e3f4-2010-0000-0000-000000000010', 'DENTAL',                'Emergency Dental',                'Emergency dental treatment abroad',                                   TRUE),
('c1d2e3f4-2011-0000-0000-000000000011', 'PASSPORT_LOSS',         'Loss of Passport',                'Expenses for emergency passport replacement abroad',                  TRUE),
('c1d2e3f4-2012-0000-0000-000000000012', 'TRIP_INTERRUPTION',     'Trip Interruption',               'Additional costs for cutting a trip short due to emergency',           TRUE),
('c1d2e3f4-2013-0000-0000-000000000013', 'HOME_BURGLARY',         'Home Burglary While Travelling',  'Cover for home burglary occurring while policyholder is abroad',       TRUE),
('c1d2e3f4-2014-0000-0000-000000000014', 'GADGET_COVER',          'Gadget Cover',                    'Loss/damage to laptops, phones, and electronic devices',              TRUE),
('c1d2e3f4-2015-0000-0000-000000000015', 'CONCIERGE',             'Travel Concierge Services',       '24/7 travel assistance and concierge services',                       TRUE)
ON CONFLICT (coverage_code) DO NOTHING;

-- =============================================================================
-- Plan Coverage Details (limits per plan)
-- Base limits from webapp PLANS[x].limits — stored as JSONB in plan_coverages
-- =============================================================================
-- TravelInsure Basic
INSERT INTO ins_product.plan_coverages (id, plan_id, coverage_type_id, sum_insured, deductible_amount,
    coverage_details, is_included, is_active)
VALUES
(gen_random_uuid(), 'c1d2e3f4-1001-0000-0000-000000000001', 'c1d2e3f4-2001-0000-0000-000000000001',
    2500000.00, 0.00, '{"display":"₹25 Lakh","slider_base":2500000}', TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1001-0000-0000-000000000001', 'c1d2e3f4-2002-0000-0000-000000000002',
    50000.00,  0.00, '{"display":"₹50,000","slider_base":50000}',      TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1001-0000-0000-000000000001', 'c1d2e3f4-2003-0000-0000-000000000003',
    25000.00,  500.00,'{"display":"₹25,000","slider_base":25000}',     TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1001-0000-0000-000000000001', 'c1d2e3f4-2006-0000-0000-000000000006',
    500000.00, 0.00, '{"display":"₹5 Lakh"}',                          TRUE, TRUE);

-- TravelInsure Plus
INSERT INTO ins_product.plan_coverages (id, plan_id, coverage_type_id, sum_insured, deductible_amount,
    coverage_details, is_included, is_active)
VALUES
(gen_random_uuid(), 'c1d2e3f4-1002-0000-0000-000000000002', 'c1d2e3f4-2001-0000-0000-000000000001',
    7500000.00, 0.00, '{"display":"₹75 Lakh","slider_base":7500000}',  TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1002-0000-0000-000000000002', 'c1d2e3f4-2002-0000-0000-000000000002',
    150000.00,  0.00, '{"display":"₹1.5 Lakh","slider_base":150000}',  TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1002-0000-0000-000000000002', 'c1d2e3f4-2003-0000-0000-000000000003',
    75000.00,   500.00,'{"display":"₹75,000","slider_base":75000}',     TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1002-0000-0000-000000000002', 'c1d2e3f4-2004-0000-0000-000000000004',
    1000000.00, 0.00, '{"display":"₹10 Lakh","slider_base":1000000}',  TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1002-0000-0000-000000000002', 'c1d2e3f4-2006-0000-0000-000000000006',
    1500000.00, 0.00, '{"display":"₹15 Lakh"}',                        TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1002-0000-0000-000000000002', 'c1d2e3f4-2007-0000-0000-000000000007',
    5000.00,    0.00, '{"display":"₹5,000","threshold_hours":6}',       TRUE, TRUE);

-- TravelInsure Pro
INSERT INTO ins_product.plan_coverages (id, plan_id, coverage_type_id, sum_insured, deductible_amount,
    coverage_details, is_included, is_active)
VALUES
(gen_random_uuid(), 'c1d2e3f4-1003-0000-0000-000000000003', 'c1d2e3f4-2001-0000-0000-000000000001',
    20000000.00, 0.00, '{"display":"₹2 Crore","slider_base":20000000}', TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1003-0000-0000-000000000003', 'c1d2e3f4-2002-0000-0000-000000000002',
    300000.00,   0.00, '{"display":"₹3 Lakh","slider_base":300000}',    TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1003-0000-0000-000000000003', 'c1d2e3f4-2003-0000-0000-000000000003',
    200000.00,   500.00,'{"display":"₹2 Lakh","slider_base":200000}',   TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1003-0000-0000-000000000003', 'c1d2e3f4-2004-0000-0000-000000000004',
    3000000.00,  0.00, '{"display":"₹30 Lakh","slider_base":3000000}',  TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1003-0000-0000-000000000003', 'c1d2e3f4-2005-0000-0000-000000000005',
    5000000.00,  0.00, '{"display":"₹50 Lakh","slider_base":5000000}',  TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1003-0000-0000-000000000003', 'c1d2e3f4-2006-0000-0000-000000000006',
    5000000.00,  0.00, '{"display":"₹50 Lakh"}',                        TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1003-0000-0000-000000000003', 'c1d2e3f4-2007-0000-0000-000000000007',
    10000.00,    0.00, '{"display":"₹10,000","threshold_hours":4}',     TRUE, TRUE),
(gen_random_uuid(), 'c1d2e3f4-1003-0000-0000-000000000003', 'c1d2e3f4-2015-0000-0000-000000000015',
    NULL,        0.00, '{"display":"Included"}',                        TRUE, TRUE);

-- =============================================================================
-- Add-ons (from webapp ADDONS array)
-- =============================================================================
INSERT INTO ins_product.addons (id, product_id, addon_code, addon_name, description,
    base_price, currency_code, is_active)
VALUES
('c1d2e3f4-3001-0000-0000-000000000001',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'CANCEL_FOR_ANY_REASON',
 'Cancel For Any Reason',
 'Full refund of trip costs for any reason whatsoever, no documentation required',
 49900, 'INR', TRUE),

('c1d2e3f4-3002-0000-0000-000000000002',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'ADVENTURE_SPORTS',
 'Adventure Sports Cover',
 'Skiing, scuba diving, paragliding, bungee jumping and 40+ extreme sports',
 39900, 'INR', TRUE),

('c1d2e3f4-3003-0000-0000-000000000003',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'GADGET_COVER',
 'Gadget Cover',
 'Laptop, phone, camera and electronics — loss, theft and accidental damage',
 29900, 'INR', TRUE),

('c1d2e3f4-3004-0000-0000-000000000004',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'RENTAL_CAR',
 'Rental Car Protection',
 'Collision damage waiver for rental vehicles, including 3rd-party liability',
 24900, 'INR', TRUE),

('c1d2e3f4-3005-0000-0000-000000000005',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'HOME_BURGLARY',
 'Home Burglary While Travelling',
 'Cover for home break-in and theft of household contents while you are away',
 19900, 'INR', TRUE),

('c1d2e3f4-3006-0000-0000-000000000006',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'GOLF_COVER',
 'Golf Equipment Cover',
 'Loss, damage, or theft of golf clubs and equipment during travel',
 14900, 'INR', TRUE),

('c1d2e3f4-3007-0000-0000-000000000007',
 'c1d2e3f4-0100-0000-0000-000000000100',
 'PET_CARE',
 'Pet Care Cover',
 'Additional kennel/boarding costs if your return is delayed',
 9900, 'INR', TRUE)
ON CONFLICT (addon_code) DO NOTHING;

-- =============================================================================
-- Destination Zones
-- Multipliers from webapp DESTINATIONS array
-- =============================================================================
INSERT INTO ins_product.destination_zones (id, zone_code, zone_name, premium_multiplier, is_active)
VALUES
('c1d2e3f4-4001-0000-0000-000000000001', 'DOMESTIC',      'Domestic (India)',          0.50, TRUE),
('c1d2e3f4-4002-0000-0000-000000000002', 'SAARC',         'SAARC Countries',           0.80, TRUE),
('c1d2e3f4-4003-0000-0000-000000000003', 'SE_ASIA',       'South / South-East Asia',   1.00, TRUE),
('c1d2e3f4-4004-0000-0000-000000000004', 'ME_AFRICA',     'Middle East / Africa',      1.30, TRUE),
('c1d2e3f4-4005-0000-0000-000000000005', 'EUROPE',        'Europe',                    1.50, TRUE),
('c1d2e3f4-4006-0000-0000-000000000006', 'AUS_NZ',        'Australia / New Zealand',   1.80, TRUE),
('c1d2e3f4-4007-0000-0000-000000000007', 'USA_CANADA',    'USA / Canada',              2.00, TRUE),
('c1d2e3f4-4008-0000-0000-000000000008', 'WORLDWIDE',     'Worldwide',                 2.50, TRUE)
ON CONFLICT (zone_code) DO NOTHING;

-- =============================================================================
-- Zone Countries (key representatives per zone)
-- =============================================================================
INSERT INTO ins_product.zone_countries (id, zone_id, country_code, country_name)
VALUES
-- SE_ASIA
(gen_random_uuid(), 'c1d2e3f4-4003-0000-0000-000000000003', 'SG', 'Singapore'),
(gen_random_uuid(), 'c1d2e3f4-4003-0000-0000-000000000003', 'TH', 'Thailand'),
(gen_random_uuid(), 'c1d2e3f4-4003-0000-0000-000000000003', 'MY', 'Malaysia'),
(gen_random_uuid(), 'c1d2e3f4-4003-0000-0000-000000000003', 'ID', 'Indonesia'),
(gen_random_uuid(), 'c1d2e3f4-4003-0000-0000-000000000003', 'PH', 'Philippines'),
(gen_random_uuid(), 'c1d2e3f4-4003-0000-0000-000000000003', 'VN', 'Vietnam'),
(gen_random_uuid(), 'c1d2e3f4-4003-0000-0000-000000000003', 'LK', 'Sri Lanka'),
-- ME_AFRICA
(gen_random_uuid(), 'c1d2e3f4-4004-0000-0000-000000000004', 'AE', 'United Arab Emirates'),
(gen_random_uuid(), 'c1d2e3f4-4004-0000-0000-000000000004', 'SA', 'Saudi Arabia'),
(gen_random_uuid(), 'c1d2e3f4-4004-0000-0000-000000000004', 'ZA', 'South Africa'),
(gen_random_uuid(), 'c1d2e3f4-4004-0000-0000-000000000004', 'EG', 'Egypt'),
-- EUROPE
(gen_random_uuid(), 'c1d2e3f4-4005-0000-0000-000000000005', 'GB', 'United Kingdom'),
(gen_random_uuid(), 'c1d2e3f4-4005-0000-0000-000000000005', 'DE', 'Germany'),
(gen_random_uuid(), 'c1d2e3f4-4005-0000-0000-000000000005', 'FR', 'France'),
(gen_random_uuid(), 'c1d2e3f4-4005-0000-0000-000000000005', 'IT', 'Italy'),
(gen_random_uuid(), 'c1d2e3f4-4005-0000-0000-000000000005', 'CH', 'Switzerland'),
-- AUS_NZ
(gen_random_uuid(), 'c1d2e3f4-4006-0000-0000-000000000006', 'AU', 'Australia'),
(gen_random_uuid(), 'c1d2e3f4-4006-0000-0000-000000000006', 'NZ', 'New Zealand'),
-- USA_CANADA
(gen_random_uuid(), 'c1d2e3f4-4007-0000-0000-000000000007', 'US', 'United States'),
(gen_random_uuid(), 'c1d2e3f4-4007-0000-0000-000000000007', 'CA', 'Canada')
ON CONFLICT DO NOTHING;
