-- =============================================================================
-- V22__seed_rules.sql
-- Schema: ins_rule
-- Description: Seed default rule definitions matching the DEFAULT_RULES array
--              in webapp/portals/admin/app.js.
--              These are the 7 rules visible and editable in the Admin portal.
--
-- Rule categories: RISK_SCORING | PREMIUM_LOADING | ELIGIBILITY | ROUTING |
--                  CLAIMS_AUTO_DECISION
-- =============================================================================

SET search_path = ins_rule, public;

-- Rule definitions
INSERT INTO ins_rule.rule_definitions
    (id, rule_code, rule_name, category, description, priority, is_active,
     stop_on_match, effective_from, effective_to, current_version)
VALUES
-- 1. Senior Traveler Risk Uplift (RISK_SCORING)
('d1e2f3a4-0001-0000-0000-000000000001',
 'RULE_RISK_SENIOR_TRAVELER',
 'Senior Traveler Risk Uplift',
 'RISK_SCORING',
 'Adds 25 risk score points when any traveler is in the senior (61+) age group.',
 10,
 TRUE, FALSE,
 NOW(), NULL, 1),

-- 2. High-Risk Destination Loading (RISK_SCORING)
('d1e2f3a4-0002-0000-0000-000000000002',
 'RULE_RISK_HIGH_DEST',
 'High-Risk Destination Loading',
 'RISK_SCORING',
 'Adds 20 risk score points for USA/Canada, Australia/NZ, or Worldwide destinations.',
 20,
 TRUE, FALSE,
 NOW(), NULL, 1),

-- 3. Long-Trip Duration Risk (RISK_SCORING)
('d1e2f3a4-0003-0000-0000-000000000003',
 'RULE_RISK_LONG_TRIP',
 'Long-Trip Duration Risk',
 'RISK_SCORING',
 'Adds 15 points for trips exceeding 30 days; adds 7 points for trips 15–30 days.',
 30,
 TRUE, FALSE,
 NOW(), NULL, 1),

-- 4. Adventure Sports Premium Loading (PREMIUM_LOADING)
('d1e2f3a4-0004-0000-0000-000000000004',
 'RULE_LOAD_ADVENTURE',
 'Adventure Sports Premium Loading',
 'PREMIUM_LOADING',
 'Applies +10 risk score points when adventure/sports add-on is selected. Used in base premium calculation.',
 40,
 TRUE, FALSE,
 NOW(), NULL, 1),

-- 5. Medical Tourism Risk Uplift (RISK_SCORING)
('d1e2f3a4-0005-0000-0000-000000000005',
 'RULE_RISK_MEDICAL_TOURISM',
 'Medical Tourism Risk Uplift',
 'RISK_SCORING',
 'Adds 15 risk score points when trip purpose is Medical Tourism.',
 50,
 TRUE, FALSE,
 NOW(), NULL, 1),

-- 6. Auto-Approve Low-Risk Claims (CLAIMS_AUTO_DECISION)
('d1e2f3a4-0006-0000-0000-000000000006',
 'RULE_AUTO_APPROVE_LOW_CLAIM',
 'Auto-Approve Low-Risk Claims',
 'CLAIMS_AUTO_DECISION',
 'Automatically approves claims where claimed amount ≤ ₹5,000 and claim type is Flight Delay or Baggage.',
 60,
 TRUE, FALSE,
 NOW(), NULL, 1),

-- 7. VHR Eligibility Gate (ELIGIBILITY)
('d1e2f3a4-0007-0000-0000-000000000007',
 'RULE_ELIG_VHR_GATE',
 'Very High Risk Eligibility Gate',
 'ELIGIBILITY',
 'Flags policies with risk score ≥ 71 for mandatory L2 underwriter review before issuance.',
 70,
 TRUE, TRUE,
 NOW(), NULL, 1)

ON CONFLICT (rule_code) DO NOTHING;

-- =============================================================================
-- Rule Condition Groups (one per rule for simplicity)
-- =============================================================================
INSERT INTO ins_rule.rule_condition_groups
    (id, rule_id, group_name, logical_operator, display_order)
VALUES
('d1e2f3a4-1001-0000-0000-000000001001', 'd1e2f3a4-0001-0000-0000-000000000001', 'Main', 'AND', 1),
('d1e2f3a4-1002-0000-0000-000000001002', 'd1e2f3a4-0002-0000-0000-000000000002', 'Main', 'OR',  1),
('d1e2f3a4-1003-0000-0000-000000001003', 'd1e2f3a4-0003-0000-0000-000000000003', 'Main', 'OR',  1),
('d1e2f3a4-1004-0000-0000-000000001004', 'd1e2f3a4-0004-0000-0000-000000000004', 'Main', 'AND', 1),
('d1e2f3a4-1005-0000-0000-000000001005', 'd1e2f3a4-0005-0000-0000-000000000005', 'Main', 'AND', 1),
('d1e2f3a4-1006-0000-0000-000000001006', 'd1e2f3a4-0006-0000-0000-000000000006', 'Main', 'AND', 1),
('d1e2f3a4-1007-0000-0000-000000001007', 'd1e2f3a4-0007-0000-0000-000000000007', 'Main', 'AND', 1)
ON CONFLICT DO NOTHING;

-- =============================================================================
-- Rule Conditions
-- =============================================================================
INSERT INTO ins_rule.rule_conditions
    (id, group_id, field_path, operator, comparison_value, data_type, display_order)
VALUES
-- Rule 1: age_groups CONTAINS senior
('d1e2f3a4-2001-0000-0000-000000002001',
 'd1e2f3a4-1001-0000-0000-000000001001',
 'quote.ageGroups', 'CONTAINS', 'senior', 'STRING', 1),

-- Rule 2: destination IN (usa_canada, aus_nz, worldwide)
('d1e2f3a4-2002-0000-0000-000000002002',
 'd1e2f3a4-1002-0000-0000-000000001002',
 'quote.destination', 'IN', 'usa_canada,aus_nz,worldwide', 'STRING', 1),

-- Rule 3a: trip days > 30
('d1e2f3a4-2003-0000-0000-000000002003',
 'd1e2f3a4-1003-0000-0000-000000001003',
 'quote.tripDays', 'GREATER_THAN', '30', 'NUMBER', 1),
-- Rule 3b: trip days BETWEEN 15 AND 30
('d1e2f3a4-2004-0000-0000-000000002004',
 'd1e2f3a4-1003-0000-0000-000000001003',
 'quote.tripDays', 'BETWEEN', '15,30', 'NUMBER', 2),

-- Rule 4: selectedAddons CONTAINS adventure
('d1e2f3a4-2005-0000-0000-000000002005',
 'd1e2f3a4-1004-0000-0000-000000001004',
 'quote.selectedAddons', 'CONTAINS', 'adventure', 'STRING', 1),

-- Rule 5: purpose = Medical Tourism
('d1e2f3a4-2006-0000-0000-000000002006',
 'd1e2f3a4-1005-0000-0000-000000001005',
 'quote.tripPurpose', 'EQUALS', 'Medical Tourism', 'STRING', 1),

-- Rule 6a: claimedAmount <= 5000
('d1e2f3a4-2007-0000-0000-000000002007',
 'd1e2f3a4-1006-0000-0000-000000001006',
 'claim.claimedAmount', 'LESS_THAN_OR_EQUAL', '5000', 'NUMBER', 1),
-- Rule 6b: claimTypeCode IN (FLIGHT_DELAY, BAGGAGE_LOSS)
('d1e2f3a4-2008-0000-0000-000000002008',
 'd1e2f3a4-1006-0000-0000-000000001006',
 'claim.claimTypeCode', 'IN', 'FLIGHT_DELAY,BAGGAGE_LOSS', 'STRING', 2),

-- Rule 7: riskScore >= 71
('d1e2f3a4-2009-0000-0000-000000002009',
 'd1e2f3a4-1007-0000-0000-000000001007',
 'quote.riskScore', 'GREATER_THAN_OR_EQUAL', '71', 'NUMBER', 1)

ON CONFLICT DO NOTHING;

-- =============================================================================
-- Rule Actions
-- =============================================================================
INSERT INTO ins_rule.rule_actions
    (id, rule_id, action_type, action_target, action_value, display_order)
VALUES
-- Rule 1: ADD_SCORE 25
('d1e2f3a4-3001-0000-0000-000000003001',
 'd1e2f3a4-0001-0000-0000-000000000001',
 'ADD_SCORE', 'riskScore', '25', 1),

-- Rule 2: ADD_SCORE 20
('d1e2f3a4-3002-0000-0000-000000003002',
 'd1e2f3a4-0002-0000-0000-000000000002',
 'ADD_SCORE', 'riskScore', '20', 1),

-- Rule 3a: ADD_SCORE 15 (>30 days)
('d1e2f3a4-3003-0000-0000-000000003003',
 'd1e2f3a4-0003-0000-0000-000000000003',
 'ADD_SCORE', 'riskScore', '15', 1),

-- Rule 4: ADD_SCORE 10 (adventure addon)
('d1e2f3a4-3004-0000-0000-000000003004',
 'd1e2f3a4-0004-0000-0000-000000000004',
 'ADD_SCORE', 'riskScore', '10', 1),

-- Rule 5: ADD_SCORE 15 (medical tourism)
('d1e2f3a4-3005-0000-0000-000000003005',
 'd1e2f3a4-0005-0000-0000-000000000005',
 'ADD_SCORE', 'riskScore', '15', 1),

-- Rule 6: SET_STATUS AUTO_APPROVED
('d1e2f3a4-3006-0000-0000-000000003006',
 'd1e2f3a4-0006-0000-0000-000000000006',
 'SET_STATUS', 'claim.status', 'AUTO_APPROVED', 1),

-- Rule 7: SET_ROUTING UW_L2
('d1e2f3a4-3007-0000-0000-000000003007',
 'd1e2f3a4-0007-0000-0000-000000000007',
 'SET_ROUTING', 'policy.reviewRoute', 'UW_L2', 1)

ON CONFLICT DO NOTHING;

-- =============================================================================
-- Risk Routing Configuration (workflow schema)
-- =============================================================================
SET search_path = ins_workflow, public;

INSERT INTO ins_workflow.risk_routing_config
    (id, routing_band, score_min, score_max, target_status, notify_roles, description, is_active)
VALUES
('e1f2a3b4-0001-0000-0000-000000000001',
 'AUTO_ISSUE', 0, 30,
 'ACTIVE',
 ARRAY['ROLE_CUSTOMER','ROLE_FINANCE','ROLE_AGENT','ROLE_RELATIONSHIP_MANAGER'],
 'Low risk — policy auto-issued immediately after payment', TRUE),

('e1f2a3b4-0002-0000-0000-000000000002',
 'CO_REVIEW', 31, 50,
 'PENDING_CO_REVIEW',
 ARRAY['ROLE_CLAIMS_OFFICER','ROLE_CUSTOMER'],
 'Medium risk — Claims Officer review within 1 business day', TRUE),

('e1f2a3b4-0003-0000-0000-000000000003',
 'UW_L1', 51, 70,
 'PENDING_UW_REVIEW',
 ARRAY['ROLE_UNDERWRITER_L1','ROLE_CUSTOMER'],
 'High risk — Underwriter L1 review within 2-3 business days', TRUE),

('e1f2a3b4-0004-0000-0000-000000000004',
 'UW_L2', 71, 999,
 'PENDING_L2_REVIEW',
 ARRAY['ROLE_UNDERWRITER_L2','ROLE_FIELD_OFFICER','ROLE_CUSTOMER'],
 'Very High risk — Senior Underwriter L2 review, field assessment may apply', TRUE)
ON CONFLICT (routing_band) DO NOTHING;

-- =============================================================================
-- Coverage Limit Risk Multipliers (workflow schema)
-- Source: webapp getRiskMultiplier() function
-- =============================================================================
INSERT INTO ins_workflow.coverage_limit_risk_multipliers
    (id, risk_level, multiplier, description, is_active)
VALUES
('e1f2a3b4-1001-0000-0000-000000001001', 'LOW',       1.50, 'Low risk: slider max = base × 1.5',       TRUE),
('e1f2a3b4-1002-0000-0000-000000001002', 'MEDIUM',    1.25, 'Medium risk: slider max = base × 1.25',   TRUE),
('e1f2a3b4-1003-0000-0000-000000001003', 'HIGH',      1.10, 'High risk: slider max = base × 1.1',      TRUE),
('e1f2a3b4-1004-0000-0000-000000001004', 'VERY_HIGH', 1.00, 'Very High risk: slider locked at base',   TRUE)
ON CONFLICT (risk_level) DO NOTHING;

-- =============================================================================
-- Platform Configurations (workflow schema)
-- Pricing constants from webapp calcPremiumBreakdown()
-- =============================================================================
INSERT INTO ins_workflow.platform_configurations
    (id, config_key, config_value, value_type, description, group_name, is_active)
VALUES
('e1f2a3b4-2001-0000-0000-000000002001', 'pricing.gst_rate',                   '0.18', 'NUMBER', 'GST rate applied to all premiums (18%)',              'PRICING',    TRUE),
('e1f2a3b4-2002-0000-0000-000000002002', 'pricing.online_discount_rate',        '0.05', 'NUMBER', 'Online purchase discount (5% off subtotal)',           'PRICING',    TRUE),
('e1f2a3b4-2003-0000-0000-000000002003', 'pricing.traveler_mult_base',          '1.00', 'NUMBER', 'Multiplier for first traveler',                        'PRICING',    TRUE),
('e1f2a3b4-2004-0000-0000-000000002004', 'pricing.traveler_mult_2to4_step',     '0.60', 'NUMBER', 'Each additional traveler (2–4): add 0.6 to multiplier','PRICING',    TRUE),
('e1f2a3b4-2005-0000-0000-000000002005', 'pricing.traveler_mult_5plus_step',    '0.40', 'NUMBER', 'Each additional traveler (5+): add 0.4 to multiplier', 'PRICING',    TRUE),
('e1f2a3b4-2006-0000-0000-000000002006', 'commission.rate_basic',               '0.10', 'NUMBER', 'Agent commission rate for Basic plan (10%)',           'COMMISSION', TRUE),
('e1f2a3b4-2007-0000-0000-000000002007', 'commission.rate_plus',                '0.12', 'NUMBER', 'Agent commission rate for Plus plan (12%)',            'COMMISSION', TRUE),
('e1f2a3b4-2008-0000-0000-000000002008', 'commission.rate_pro',                 '0.15', 'NUMBER', 'Agent commission rate for Pro plan (15%)',             'COMMISSION', TRUE),
('e1f2a3b4-2009-0000-0000-000000002009', 'claims.high_value_threshold',         '100000', 'NUMBER','Claims above this amount (₹1L) flagged as high-value','CLAIMS',     TRUE),
('e1f2a3b4-2010-0000-0000-000000002010', 'claims.auto_approve_max_amount',      '5000', 'NUMBER', 'Claims ≤ this amount may be auto-approved if low-risk','CLAIMS',     TRUE),
('e1f2a3b4-2011-0000-0000-000000002011', 'notifications.max_per_role',          '50',   'NUMBER', 'Maximum in-app notifications retained per role',       'NOTIFICATIONS', TRUE),
('e1f2a3b4-2012-0000-0000-000000002012', 'sla.uw_l1_hours',                     '48',   'NUMBER', 'SLA hours for Underwriter L1 decisions',               'SLA',        TRUE),
('e1f2a3b4-2013-0000-0000-000000002013', 'sla.uw_l2_hours',                     '72',   'NUMBER', 'SLA hours for Underwriter L2 decisions',               'SLA',        TRUE),
('e1f2a3b4-2014-0000-0000-000000002014', 'sla.claims_default_hours',            '48',   'NUMBER', 'Default SLA hours for claims processing',              'SLA',        TRUE)
ON CONFLICT (config_key) DO NOTHING;
