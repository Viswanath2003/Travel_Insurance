-- =============================================================================
-- V23__seed_workflow_definitions.sql
-- Schema: ins_workflow
-- Description: Seed workflow definitions, states, and transitions for the
--              three main domain workflows: Policy Issuance, Underwriting,
--              and Claims Processing.
-- =============================================================================

SET search_path = ins_workflow, public;

-- =============================================================================
-- Workflow Definitions
-- =============================================================================
INSERT INTO ins_workflow.workflow_definitions
    (id, workflow_code, workflow_name, domain, description, is_active, version)
VALUES
('f1a2b3c4-0001-0000-0000-000000000001',
 'POLICY_ISSUANCE',
 'Policy Issuance Workflow',
 'POLICY',
 'Handles policy quote → payment → risk routing → underwriting → issuance lifecycle',
 TRUE, 1),

('f1a2b3c4-0002-0000-0000-000000000002',
 'UNDERWRITING',
 'Underwriting Workflow',
 'UNDERWRITING',
 'L1/L2 underwriting review: assignment → review → decision (approve/conditional/reject/escalate)',
 TRUE, 1),

('f1a2b3c4-0003-0000-0000-000000000003',
 'CLAIMS_PROCESSING',
 'Claims Processing Workflow',
 'CLAIMS',
 'Full claims lifecycle: submission → document review → investigation → decision → payment → settlement',
 TRUE, 1)

ON CONFLICT (workflow_code) DO NOTHING;

-- =============================================================================
-- Policy Issuance States
-- =============================================================================
INSERT INTO ins_workflow.workflow_states
    (id, workflow_id, state_code, state_name, state_type, display_order)
VALUES
('f1a2b3c4-1001-0000-0000-000000001001', 'f1a2b3c4-0001-0000-0000-000000000001', 'QUOTE_CREATED',       'Quote Created',          'INITIAL',       1),
('f1a2b3c4-1002-0000-0000-000000001002', 'f1a2b3c4-0001-0000-0000-000000000001', 'PAYMENT_PENDING',     'Payment Pending',        'INTERMEDIATE',  2),
('f1a2b3c4-1003-0000-0000-000000001003', 'f1a2b3c4-0001-0000-0000-000000000001', 'PAYMENT_CONFIRMED',   'Payment Confirmed',      'INTERMEDIATE',  3),
('f1a2b3c4-1004-0000-0000-000000001004', 'f1a2b3c4-0001-0000-0000-000000000001', 'ACTIVE',              'Active',                 'TERMINAL',      4),
('f1a2b3c4-1005-0000-0000-000000001005', 'f1a2b3c4-0001-0000-0000-000000000001', 'PENDING_CO_REVIEW',   'Pending CO Review',      'INTERMEDIATE',  5),
('f1a2b3c4-1006-0000-0000-000000001006', 'f1a2b3c4-0001-0000-0000-000000000001', 'PENDING_UW_REVIEW',   'Pending UW Review',      'INTERMEDIATE',  6),
('f1a2b3c4-1007-0000-0000-000000001007', 'f1a2b3c4-0001-0000-0000-000000000001', 'PENDING_L2_REVIEW',   'Pending L2 Review',      'INTERMEDIATE',  7),
('f1a2b3c4-1008-0000-0000-000000001008', 'f1a2b3c4-0001-0000-0000-000000000001', 'ESCALATED_TO_L2',     'Escalated to L2',        'INTERMEDIATE',  8),
('f1a2b3c4-1009-0000-0000-000000001009', 'f1a2b3c4-0001-0000-0000-000000000001', 'REJECTED',            'Rejected',               'TERMINAL',      9),
('f1a2b3c4-1010-0000-0000-000000001010', 'f1a2b3c4-0001-0000-0000-000000000001', 'CANCELLED',           'Cancelled',              'TERMINAL',      10),
('f1a2b3c4-1011-0000-0000-000000001011', 'f1a2b3c4-0001-0000-0000-000000000001', 'EXPIRED',             'Expired',                'TERMINAL',      11)
ON CONFLICT (workflow_id, state_code) DO NOTHING;

-- =============================================================================
-- Underwriting Workflow States
-- =============================================================================
INSERT INTO ins_workflow.workflow_states
    (id, workflow_id, state_code, state_name, state_type, display_order)
VALUES
('f1a2b3c4-2001-0000-0000-000000002001', 'f1a2b3c4-0002-0000-0000-000000000002', 'NEW',                      'New',                         'INITIAL',      1),
('f1a2b3c4-2002-0000-0000-000000002002', 'f1a2b3c4-0002-0000-0000-000000000002', 'ASSIGNED',                 'Assigned',                    'INTERMEDIATE', 2),
('f1a2b3c4-2003-0000-0000-000000002003', 'f1a2b3c4-0002-0000-0000-000000000002', 'UNDER_REVIEW',             'Under Review',                'INTERMEDIATE', 3),
('f1a2b3c4-2004-0000-0000-000000002004', 'f1a2b3c4-0002-0000-0000-000000000002', 'INFO_REQUESTED',           'Information Requested',       'INTERMEDIATE', 4),
('f1a2b3c4-2005-0000-0000-000000002005', 'f1a2b3c4-0002-0000-0000-000000000002', 'INFO_RECEIVED',            'Information Received',        'INTERMEDIATE', 5),
('f1a2b3c4-2006-0000-0000-000000002006', 'f1a2b3c4-0002-0000-0000-000000000002', 'APPROVED',                 'Approved',                    'TERMINAL',     6),
('f1a2b3c4-2007-0000-0000-000000002007', 'f1a2b3c4-0002-0000-0000-000000000002', 'APPROVED_WITH_CONDITIONS', 'Approved with Conditions',    'TERMINAL',     7),
('f1a2b3c4-2008-0000-0000-000000002008', 'f1a2b3c4-0002-0000-0000-000000000002', 'REJECTED',                 'Rejected',                    'TERMINAL',     8),
('f1a2b3c4-2009-0000-0000-000000002009', 'f1a2b3c4-0002-0000-0000-000000000002', 'REFERRED_TO_L2',           'Referred to L2',              'INTERMEDIATE', 9),
('f1a2b3c4-2010-0000-0000-000000002010', 'f1a2b3c4-0002-0000-0000-000000000002', 'L2_UNDER_REVIEW',          'L2 Under Review',             'INTERMEDIATE', 10),
('f1a2b3c4-2011-0000-0000-000000002011', 'f1a2b3c4-0002-0000-0000-000000000002', 'CLOSED',                   'Closed',                      'TERMINAL',     11)
ON CONFLICT (workflow_id, state_code) DO NOTHING;

-- =============================================================================
-- Claims Workflow States
-- Aligned with Claim.ClaimStatus enum in backend entity
-- =============================================================================
INSERT INTO ins_workflow.workflow_states
    (id, workflow_id, state_code, state_name, state_type, display_order)
VALUES
('f1a2b3c4-3001-0000-0000-000000003001', 'f1a2b3c4-0003-0000-0000-000000000003', 'SUBMITTED',               'Submitted',                'INITIAL',       1),
('f1a2b3c4-3002-0000-0000-000000003002', 'f1a2b3c4-0003-0000-0000-000000000003', 'DOCUMENT_REVIEW',         'Document Review',          'INTERMEDIATE',  2),
('f1a2b3c4-3003-0000-0000-000000003003', 'f1a2b3c4-0003-0000-0000-000000000003', 'DOCUMENT_PENDING',        'Document Pending',         'INTERMEDIATE',  3),
('f1a2b3c4-3004-0000-0000-000000003004', 'f1a2b3c4-0003-0000-0000-000000000003', 'UNDER_REVIEW',            'Under Review',             'INTERMEDIATE',  4),
('f1a2b3c4-3005-0000-0000-000000003005', 'f1a2b3c4-0003-0000-0000-000000000003', 'INVESTIGATION_ASSIGNED',  'Investigation Assigned',   'INTERMEDIATE',  5),
('f1a2b3c4-3006-0000-0000-000000003006', 'f1a2b3c4-0003-0000-0000-000000000003', 'INVESTIGATION_COMPLETE',  'Investigation Complete',   'INTERMEDIATE',  6),
('f1a2b3c4-3007-0000-0000-000000003007', 'f1a2b3c4-0003-0000-0000-000000000003', 'DECISION_PENDING',        'Decision Pending',         'INTERMEDIATE',  7),
('f1a2b3c4-3008-0000-0000-000000003008', 'f1a2b3c4-0003-0000-0000-000000000003', 'AUTO_APPROVED',           'Auto Approved',            'INTERMEDIATE',  8),
('f1a2b3c4-3009-0000-0000-000000003009', 'f1a2b3c4-0003-0000-0000-000000000003', 'AUTO_DECLINED',           'Auto Declined',            'TERMINAL',      9),
('f1a2b3c4-3010-0000-0000-000000003010', 'f1a2b3c4-0003-0000-0000-000000000003', 'APPROVED',                'Approved',                 'INTERMEDIATE',  10),
('f1a2b3c4-3011-0000-0000-000000003011', 'f1a2b3c4-0003-0000-0000-000000000003', 'PARTIALLY_APPROVED',      'Partially Approved',       'INTERMEDIATE',  11),
('f1a2b3c4-3012-0000-0000-000000003012', 'f1a2b3c4-0003-0000-0000-000000000003', 'DECLINED',                'Declined',                 'TERMINAL',      12),
('f1a2b3c4-3013-0000-0000-000000003013', 'f1a2b3c4-0003-0000-0000-000000000003', 'PAYMENT_PENDING',         'Payment Pending',          'INTERMEDIATE',  13),
('f1a2b3c4-3014-0000-0000-000000003014', 'f1a2b3c4-0003-0000-0000-000000000003', 'SETTLED',                 'Settled',                  'TERMINAL',      14),
('f1a2b3c4-3015-0000-0000-000000003015', 'f1a2b3c4-0003-0000-0000-000000000003', 'CLOSED',                  'Closed',                   'TERMINAL',      15)
ON CONFLICT (workflow_id, state_code) DO NOTHING;

-- =============================================================================
-- Underwriting Transitions (key ones)
-- =============================================================================
INSERT INTO ins_workflow.workflow_transitions
    (id, workflow_id, from_state_id, to_state_id, transition_code, transition_name,
     required_role, required_permission, is_active)
VALUES
-- L1: NEW → ASSIGNED
('f1a2b3c4-4001-0000-0000-000000004001',
 'f1a2b3c4-0002-0000-0000-000000000002',
 'f1a2b3c4-2001-0000-0000-000000002001', 'f1a2b3c4-2002-0000-0000-000000002002',
 'ASSIGN', 'Assign to Underwriter', 'ROLE_UNDERWRITER_L1', 'UW_VIEW', TRUE),

-- L1: UNDER_REVIEW → APPROVED
('f1a2b3c4-4002-0000-0000-000000004002',
 'f1a2b3c4-0002-0000-0000-000000000002',
 'f1a2b3c4-2003-0000-0000-000000002003', 'f1a2b3c4-2006-0000-0000-000000002006',
 'APPROVE', 'Approve Policy', 'ROLE_UNDERWRITER_L1', 'UW_APPROVE', TRUE),

-- L1: UNDER_REVIEW → APPROVED_WITH_CONDITIONS
('f1a2b3c4-4003-0000-0000-000000004003',
 'f1a2b3c4-0002-0000-0000-000000000002',
 'f1a2b3c4-2003-0000-0000-000000002003', 'f1a2b3c4-2007-0000-0000-000000002007',
 'APPROVE_CONDITIONAL', 'Approve with Conditions', 'ROLE_UNDERWRITER_L1', 'UW_APPROVE', TRUE),

-- L1: UNDER_REVIEW → REJECTED
('f1a2b3c4-4004-0000-0000-000000004004',
 'f1a2b3c4-0002-0000-0000-000000000002',
 'f1a2b3c4-2003-0000-0000-000000002003', 'f1a2b3c4-2008-0000-0000-000000002008',
 'REJECT', 'Reject Policy', 'ROLE_UNDERWRITER_L1', 'UW_DECLINE', TRUE),

-- L1: UNDER_REVIEW → REFERRED_TO_L2 (Escalate)
('f1a2b3c4-4005-0000-0000-000000004005',
 'f1a2b3c4-0002-0000-0000-000000000002',
 'f1a2b3c4-2003-0000-0000-000000002003', 'f1a2b3c4-2009-0000-0000-000000002009',
 'ESCALATE_TO_L2', 'Escalate to Senior Underwriter', 'ROLE_UNDERWRITER_L1', 'UW_REFER', TRUE),

-- L2: REFERRED_TO_L2 → L2_UNDER_REVIEW
('f1a2b3c4-4006-0000-0000-000000004006',
 'f1a2b3c4-0002-0000-0000-000000000002',
 'f1a2b3c4-2009-0000-0000-000000002009', 'f1a2b3c4-2010-0000-0000-000000002010',
 'L2_ASSIGN', 'Assign to L2 Underwriter', 'ROLE_UNDERWRITER_L2', 'UW_VIEW', TRUE),

-- L2: L2_UNDER_REVIEW → APPROVED
('f1a2b3c4-4007-0000-0000-000000004007',
 'f1a2b3c4-0002-0000-0000-000000000002',
 'f1a2b3c4-2010-0000-0000-000000002010', 'f1a2b3c4-2006-0000-0000-000000002006',
 'L2_APPROVE', 'L2 Approve Policy', 'ROLE_UNDERWRITER_L2', 'UW_ESCALATE_RESOLVE', TRUE),

-- L2: L2_UNDER_REVIEW → REJECTED
('f1a2b3c4-4008-0000-0000-000000004008',
 'f1a2b3c4-0002-0000-0000-000000000002',
 'f1a2b3c4-2010-0000-0000-000000002010', 'f1a2b3c4-2008-0000-0000-000000002008',
 'L2_REJECT', 'L2 Reject Policy', 'ROLE_UNDERWRITER_L2', 'UW_ESCALATE_RESOLVE', TRUE)

ON CONFLICT (workflow_id, from_state_id, transition_code) DO NOTHING;

-- =============================================================================
-- Claims Transitions (key ones)
-- =============================================================================
INSERT INTO ins_workflow.workflow_transitions
    (id, workflow_id, from_state_id, to_state_id, transition_code, transition_name,
     required_role, required_permission, is_active)
VALUES
-- Customer: SUBMITTED → DOCUMENT_REVIEW (auto on submission)
('f1a2b3c4-5001-0000-0000-000000005001',
 'f1a2b3c4-0003-0000-0000-000000000003',
 'f1a2b3c4-3001-0000-0000-000000003001', 'f1a2b3c4-3002-0000-0000-000000003002',
 'BEGIN_REVIEW', 'Begin Document Review', 'ROLE_CLAIMS_OFFICER', 'CLAIM_DECIDE', TRUE),

-- Claims Officer: UNDER_REVIEW → INVESTIGATION_ASSIGNED
('f1a2b3c4-5002-0000-0000-000000005002',
 'f1a2b3c4-0003-0000-0000-000000000003',
 'f1a2b3c4-3004-0000-0000-000000003004', 'f1a2b3c4-3005-0000-0000-000000003005',
 'ASSIGN_FIELD', 'Assign Field Investigation', 'ROLE_CLAIMS_OFFICER', 'CLAIM_ASSIGN_FIELD', TRUE),

-- Field Officer: INVESTIGATION_ASSIGNED → INVESTIGATION_COMPLETE
('f1a2b3c4-5003-0000-0000-000000005003',
 'f1a2b3c4-0003-0000-0000-000000000003',
 'f1a2b3c4-3005-0000-0000-000000003005', 'f1a2b3c4-3006-0000-0000-000000003006',
 'SUBMIT_REPORT', 'Submit Field Report', 'ROLE_FIELD_OFFICER', 'FIELD_REPORT_SUBMIT', TRUE),

-- Claims Officer: DECISION_PENDING → APPROVED
('f1a2b3c4-5004-0000-0000-000000005004',
 'f1a2b3c4-0003-0000-0000-000000000003',
 'f1a2b3c4-3007-0000-0000-000000003007', 'f1a2b3c4-3010-0000-0000-000000003010',
 'APPROVE', 'Approve Claim', 'ROLE_CLAIMS_OFFICER', 'CLAIM_DECIDE', TRUE),

-- Claims Officer: DECISION_PENDING → PARTIALLY_APPROVED
('f1a2b3c4-5005-0000-0000-000000005005',
 'f1a2b3c4-0003-0000-0000-000000000003',
 'f1a2b3c4-3007-0000-0000-000000003007', 'f1a2b3c4-3011-0000-0000-000000003011',
 'PARTIAL_APPROVE', 'Partially Approve Claim', 'ROLE_CLAIMS_OFFICER', 'CLAIM_DECIDE', TRUE),

-- Claims Officer: DECISION_PENDING → DECLINED
('f1a2b3c4-5006-0000-0000-000000005006',
 'f1a2b3c4-0003-0000-0000-000000000003',
 'f1a2b3c4-3007-0000-0000-000000003007', 'f1a2b3c4-3012-0000-0000-000000003012',
 'DECLINE', 'Decline Claim', 'ROLE_CLAIMS_OFFICER', 'CLAIM_DECIDE', TRUE),

-- Finance: APPROVED → PAYMENT_PENDING
('f1a2b3c4-5007-0000-0000-000000005007',
 'f1a2b3c4-0003-0000-0000-000000000003',
 'f1a2b3c4-3010-0000-0000-000000003010', 'f1a2b3c4-3013-0000-0000-000000003013',
 'INITIATE_PAYMENT', 'Initiate Payment', 'ROLE_FINANCE', 'PAYMENT_PROCESS', TRUE),

-- Finance: PAYMENT_PENDING → SETTLED
('f1a2b3c4-5008-0000-0000-000000005008',
 'f1a2b3c4-0003-0000-0000-000000000003',
 'f1a2b3c4-3013-0000-0000-000000003013', 'f1a2b3c4-3014-0000-0000-000000003014',
 'SETTLE', 'Process Payout & Settle', 'ROLE_FINANCE', 'PAYMENT_PROCESS', TRUE)

ON CONFLICT (workflow_id, from_state_id, transition_code) DO NOTHING;
