-- =============================================================================
-- V20__seed_roles_permissions.sql
-- Schema: ins_auth
-- Description: Seed core roles, all platform permissions, and role-permission
--              mappings. PostgreSQL version — uses gen_random_uuid() for
--              role_permissions junction IDs.
-- =============================================================================

SET search_path = ins_auth, public;

-- =============================================================================
-- Roles
-- =============================================================================
INSERT INTO ins_auth.roles (id, role_code, role_name, description, is_system_role, is_active)
VALUES
('a1b2c3d4-0001-0000-0000-000000000001', 'ROLE_CUSTOMER',             'Customer',                   'Policyholder — buy policies, submit claims',                            TRUE, TRUE),
('a1b2c3d4-0002-0000-0000-000000000002', 'ROLE_AGENT',                 'Agent / Broker',             'Insurance agent — quote and bind policies for customers',               TRUE, TRUE),
('a1b2c3d4-0003-0000-0000-000000000003', 'ROLE_UNDERWRITER_L1',        'Underwriter L1',             'Level 1 underwriter — review HIGH risk policies',                       TRUE, TRUE),
('a1b2c3d4-0004-0000-0000-000000000004', 'ROLE_UNDERWRITER_L2',        'Underwriter L2',             'Level 2 underwriter — review VERY_HIGH and escalated cases',            TRUE, TRUE),
('a1b2c3d4-0005-0000-0000-000000000005', 'ROLE_CLAIMS_OFFICER',        'Claims Officer',             'Process and decide on insurance claims',                                TRUE, TRUE),
('a1b2c3d4-0006-0000-0000-000000000006', 'ROLE_FIELD_OFFICER',         'Field Officer',              'Conduct field investigations and submit reports',                       TRUE, TRUE),
('a1b2c3d4-0007-0000-0000-000000000007', 'ROLE_FINANCE',               'Finance Officer',            'Process payments and manage financial reports',                         TRUE, TRUE),
('a1b2c3d4-0008-0000-0000-000000000008', 'ROLE_ADMIN',                 'Administrator',              'Full configuration access — plans, rules, RBAC, reports',               TRUE, TRUE),
('a1b2c3d4-0009-0000-0000-000000000009', 'ROLE_RELATIONSHIP_MANAGER',  'Relationship Manager',       'Manages customer portfolio — onboard clients, track their policies and claims', TRUE, TRUE)
ON CONFLICT (role_code) DO NOTHING;

-- =============================================================================
-- Permissions
-- =============================================================================
INSERT INTO ins_auth.permissions (id, permission_code, permission_name, domain)
VALUES
-- POLICY domain
('b1c2d3e4-0101-0000-0000-000000000101', 'POLICY_READ',           'View own policies',              'POLICY'),
('b1c2d3e4-0102-0000-0000-000000000102', 'POLICY_VIEW_ALL',       'View all policies',              'POLICY'),
('b1c2d3e4-0103-0000-0000-000000000103', 'POLICY_WRITE',          'Create / modify policies',       'POLICY'),
('b1c2d3e4-0104-0000-0000-000000000104', 'POLICY_CANCEL',         'Request policy cancellation',    'POLICY'),
('b1c2d3e4-0105-0000-0000-000000000105', 'POLICY_RENEW',          'Renew a policy',                 'POLICY'),

-- QUOTE domain
('b1c2d3e4-0201-0000-0000-000000000201', 'QUOTE_CREATE',          'Create quotes',                  'POLICY'),
('b1c2d3e4-0202-0000-0000-000000000202', 'QUOTE_VIEW',            'View quotes',                    'POLICY'),

-- UNDERWRITING domain
('b1c2d3e4-0301-0000-0000-000000000301', 'UW_VIEW',               'View underwriting queue',        'UNDERWRITING'),
('b1c2d3e4-0302-0000-0000-000000000302', 'UW_APPROVE',            'Approve underwriting cases',     'UNDERWRITING'),
('b1c2d3e4-0303-0000-0000-000000000303', 'UW_DECLINE',            'Decline underwriting cases',     'UNDERWRITING'),
('b1c2d3e4-0304-0000-0000-000000000304', 'UW_REFER',              'Refer case to L2',               'UNDERWRITING'),
('b1c2d3e4-0305-0000-0000-000000000305', 'UW_REQUEST_INFO',       'Request more info from customer','UNDERWRITING'),
('b1c2d3e4-0306-0000-0000-000000000306', 'UW_ESCALATE_RESOLVE',   'Resolve escalated cases',        'UNDERWRITING'),

-- CLAIMS domain
('b1c2d3e4-0401-0000-0000-000000000401', 'CLAIM_SUBMIT',          'Submit a claim',                 'CLAIMS'),
('b1c2d3e4-0402-0000-0000-000000000402', 'CLAIM_TRACK',           'Track own claim status',         'CLAIMS'),
('b1c2d3e4-0403-0000-0000-000000000403', 'CLAIM_VIEW_ALL',        'View all claims',                'CLAIMS'),
('b1c2d3e4-0404-0000-0000-000000000404', 'CLAIM_DECIDE',          'Approve / decline claims',       'CLAIMS'),
('b1c2d3e4-0405-0000-0000-000000000405', 'CLAIM_ASSIGN_FIELD',    'Assign field investigation',     'CLAIMS'),

-- FIELD domain
('b1c2d3e4-0501-0000-0000-000000000501', 'FIELD_VIEW_OWN',        'View own field assignments',     'FIELD'),
('b1c2d3e4-0502-0000-0000-000000000502', 'FIELD_REPORT_SUBMIT',   'Submit field investigation report','FIELD'),
('b1c2d3e4-0503-0000-0000-000000000503', 'FIELD_ASSIGN',          'Assign field officers',          'FIELD'),

-- FINANCE domain
('b1c2d3e4-0601-0000-0000-000000000601', 'FINANCE_VIEW',          'View finance dashboards',        'FINANCE'),
('b1c2d3e4-0602-0000-0000-000000000602', 'PAYMENT_PROCESS',       'Process claim payments',         'FINANCE'),

-- DOCUMENT domain
('b1c2d3e4-0701-0000-0000-000000000701', 'DOCUMENT_VIEW',         'View generated documents',       'DOCUMENT'),
('b1c2d3e4-0702-0000-0000-000000000702', 'DOCUMENT_DOWNLOAD',     'Download generated documents',   'DOCUMENT'),

-- ADMIN — Products & Plans
('b1c2d3e4-0801-0000-0000-000000000801', 'PLAN_READ',             'View plan configurations',       'ADMIN'),
('b1c2d3e4-0802-0000-0000-000000000802', 'PLAN_WRITE',            'Create / modify plans',          'ADMIN'),
('b1c2d3e4-0803-0000-0000-000000000803', 'PLAN_PUBLISH',          'Publish plan configurations',    'ADMIN'),
('b1c2d3e4-0804-0000-0000-000000000804', 'ADDON_READ',            'View add-on configurations',     'ADMIN'),
('b1c2d3e4-0805-0000-0000-000000000805', 'ADDON_WRITE',           'Create / modify add-ons',        'ADMIN'),

-- ADMIN — Rules
('b1c2d3e4-0901-0000-0000-000000000901', 'RULE_READ',             'View rule configurations',       'ADMIN'),
('b1c2d3e4-0902-0000-0000-000000000902', 'RULE_WRITE',            'Create / modify rules',          'ADMIN'),
('b1c2d3e4-0903-0000-0000-000000000903', 'RULE_PUBLISH',          'Publish rules to production',    'ADMIN'),

-- ADMIN — Users & RBAC
('b1c2d3e4-1001-0000-0000-000000001001', 'USER_READ',             'View user accounts',             'ADMIN'),
('b1c2d3e4-1002-0000-0000-000000001002', 'USER_WRITE',            'Create / modify user accounts',  'ADMIN'),
('b1c2d3e4-1003-0000-0000-000000001003', 'USER_DEACTIVATE',       'Deactivate user accounts',       'ADMIN'),
('b1c2d3e4-1004-0000-0000-000000001004', 'RBAC_MANAGE',           'Manage role-permission matrix',  'ADMIN'),

-- REPORTING
('b1c2d3e4-1101-0000-0000-000000001101', 'REPORT_VIEW',           'View reports and dashboards',    'REPORTING'),
('b1c2d3e4-1102-0000-0000-000000001102', 'AUDIT_VIEW',            'View audit logs',                'REPORTING'),

-- NOTIFICATIONS
('b1c2d3e4-1201-0000-0000-000000001201', 'NOTIFICATION_VIEW_OWN', 'View own notifications',         'NOTIFICATIONS'),

-- RELATIONSHIP MANAGER
('b1c2d3e4-1301-0000-0000-000000001301', 'RM_MANAGE_CLIENTS',     'Manage own client portfolio',    'RM')

ON CONFLICT (permission_code) DO NOTHING;

-- =============================================================================
-- Role-Permission Mappings
-- Using gen_random_uuid() for junction table IDs (no business key needed)
-- =============================================================================

-- ROLE_CUSTOMER
INSERT INTO ins_auth.role_permissions (id, role_id, permission_id, granted_by) VALUES
(gen_random_uuid(), 'a1b2c3d4-0001-0000-0000-000000000001', 'b1c2d3e4-0101-0000-0000-000000000101', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0001-0000-0000-000000000001', 'b1c2d3e4-0104-0000-0000-000000000104', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0001-0000-0000-000000000001', 'b1c2d3e4-0105-0000-0000-000000000105', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0001-0000-0000-000000000001', 'b1c2d3e4-0201-0000-0000-000000000201', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0001-0000-0000-000000000001', 'b1c2d3e4-0202-0000-0000-000000000202', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0001-0000-0000-000000000001', 'b1c2d3e4-0401-0000-0000-000000000401', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0001-0000-0000-000000000001', 'b1c2d3e4-0402-0000-0000-000000000402', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0001-0000-0000-000000000001', 'b1c2d3e4-0701-0000-0000-000000000701', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0001-0000-0000-000000000001', 'b1c2d3e4-0702-0000-0000-000000000702', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0001-0000-0000-000000000001', 'b1c2d3e4-1201-0000-0000-000000001201', 'system');

-- ROLE_AGENT
INSERT INTO ins_auth.role_permissions (id, role_id, permission_id, granted_by) VALUES
(gen_random_uuid(), 'a1b2c3d4-0002-0000-0000-000000000002', 'b1c2d3e4-0101-0000-0000-000000000101', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0002-0000-0000-000000000002', 'b1c2d3e4-0102-0000-0000-000000000102', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0002-0000-0000-000000000002', 'b1c2d3e4-0103-0000-0000-000000000103', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0002-0000-0000-000000000002', 'b1c2d3e4-0104-0000-0000-000000000104', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0002-0000-0000-000000000002', 'b1c2d3e4-0105-0000-0000-000000000105', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0002-0000-0000-000000000002', 'b1c2d3e4-0201-0000-0000-000000000201', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0002-0000-0000-000000000002', 'b1c2d3e4-0202-0000-0000-000000000202', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0002-0000-0000-000000000002', 'b1c2d3e4-0701-0000-0000-000000000701', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0002-0000-0000-000000000002', 'b1c2d3e4-0702-0000-0000-000000000702', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0002-0000-0000-000000000002', 'b1c2d3e4-1201-0000-0000-000000001201', 'system');

-- ROLE_UNDERWRITER_L1
INSERT INTO ins_auth.role_permissions (id, role_id, permission_id, granted_by) VALUES
(gen_random_uuid(), 'a1b2c3d4-0003-0000-0000-000000000003', 'b1c2d3e4-0301-0000-0000-000000000301', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0003-0000-0000-000000000003', 'b1c2d3e4-0302-0000-0000-000000000302', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0003-0000-0000-000000000003', 'b1c2d3e4-0303-0000-0000-000000000303', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0003-0000-0000-000000000003', 'b1c2d3e4-0304-0000-0000-000000000304', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0003-0000-0000-000000000003', 'b1c2d3e4-0305-0000-0000-000000000305', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0003-0000-0000-000000000003', 'b1c2d3e4-0102-0000-0000-000000000102', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0003-0000-0000-000000000003', 'b1c2d3e4-0701-0000-0000-000000000701', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0003-0000-0000-000000000003', 'b1c2d3e4-0702-0000-0000-000000000702', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0003-0000-0000-000000000003', 'b1c2d3e4-1201-0000-0000-000000001201', 'system');

-- ROLE_UNDERWRITER_L2
INSERT INTO ins_auth.role_permissions (id, role_id, permission_id, granted_by) VALUES
(gen_random_uuid(), 'a1b2c3d4-0004-0000-0000-000000000004', 'b1c2d3e4-0301-0000-0000-000000000301', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0004-0000-0000-000000000004', 'b1c2d3e4-0302-0000-0000-000000000302', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0004-0000-0000-000000000004', 'b1c2d3e4-0303-0000-0000-000000000303', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0004-0000-0000-000000000004', 'b1c2d3e4-0306-0000-0000-000000000306', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0004-0000-0000-000000000004', 'b1c2d3e4-0102-0000-0000-000000000102', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0004-0000-0000-000000000004', 'b1c2d3e4-0701-0000-0000-000000000701', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0004-0000-0000-000000000004', 'b1c2d3e4-0702-0000-0000-000000000702', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0004-0000-0000-000000000004', 'b1c2d3e4-1201-0000-0000-000000001201', 'system');

-- ROLE_CLAIMS_OFFICER
INSERT INTO ins_auth.role_permissions (id, role_id, permission_id, granted_by) VALUES
(gen_random_uuid(), 'a1b2c3d4-0005-0000-0000-000000000005', 'b1c2d3e4-0403-0000-0000-000000000403', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0005-0000-0000-000000000005', 'b1c2d3e4-0404-0000-0000-000000000404', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0005-0000-0000-000000000005', 'b1c2d3e4-0405-0000-0000-000000000405', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0005-0000-0000-000000000005', 'b1c2d3e4-0102-0000-0000-000000000102', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0005-0000-0000-000000000005', 'b1c2d3e4-0503-0000-0000-000000000503', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0005-0000-0000-000000000005', 'b1c2d3e4-0701-0000-0000-000000000701', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0005-0000-0000-000000000005', 'b1c2d3e4-0702-0000-0000-000000000702', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0005-0000-0000-000000000005', 'b1c2d3e4-1201-0000-0000-000000001201', 'system');

-- ROLE_FIELD_OFFICER
INSERT INTO ins_auth.role_permissions (id, role_id, permission_id, granted_by) VALUES
(gen_random_uuid(), 'a1b2c3d4-0006-0000-0000-000000000006', 'b1c2d3e4-0501-0000-0000-000000000501', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0006-0000-0000-000000000006', 'b1c2d3e4-0502-0000-0000-000000000502', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0006-0000-0000-000000000006', 'b1c2d3e4-0701-0000-0000-000000000701', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0006-0000-0000-000000000006', 'b1c2d3e4-1201-0000-0000-000000001201', 'system');

-- ROLE_FINANCE
INSERT INTO ins_auth.role_permissions (id, role_id, permission_id, granted_by) VALUES
(gen_random_uuid(), 'a1b2c3d4-0007-0000-0000-000000000007', 'b1c2d3e4-0601-0000-0000-000000000601', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0007-0000-0000-000000000007', 'b1c2d3e4-0602-0000-0000-000000000602', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0007-0000-0000-000000000007', 'b1c2d3e4-0403-0000-0000-000000000403', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0007-0000-0000-000000000007', 'b1c2d3e4-0102-0000-0000-000000000102', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0007-0000-0000-000000000007', 'b1c2d3e4-1101-0000-0000-000000001101', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0007-0000-0000-000000000007', 'b1c2d3e4-0701-0000-0000-000000000701', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0007-0000-0000-000000000007', 'b1c2d3e4-0702-0000-0000-000000000702', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0007-0000-0000-000000000007', 'b1c2d3e4-1201-0000-0000-000000001201', 'system');

-- ROLE_ADMIN
INSERT INTO ins_auth.role_permissions (id, role_id, permission_id, granted_by) VALUES
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0102-0000-0000-000000000102', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0103-0000-0000-000000000103', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0801-0000-0000-000000000801', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0802-0000-0000-000000000802', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0803-0000-0000-000000000803', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0804-0000-0000-000000000804', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0805-0000-0000-000000000805', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0901-0000-0000-000000000901', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0902-0000-0000-000000000902', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0903-0000-0000-000000000903', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-1001-0000-0000-000000001001', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-1002-0000-0000-000000001002', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-1003-0000-0000-000000001003', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-1004-0000-0000-000000001004', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0403-0000-0000-000000000403', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0503-0000-0000-000000000503', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0601-0000-0000-000000000601', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-1101-0000-0000-000000001101', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-1102-0000-0000-000000001102', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0701-0000-0000-000000000701', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0702-0000-0000-000000000702', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-1201-0000-0000-000000001201', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0008-0000-0000-000000000008', 'b1c2d3e4-0301-0000-0000-000000000301', 'system');

-- ROLE_RELATIONSHIP_MANAGER
INSERT INTO ins_auth.role_permissions (id, role_id, permission_id, granted_by) VALUES
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-1301-0000-0000-000000001301', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-0101-0000-0000-000000000101', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-0102-0000-0000-000000000102', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-0103-0000-0000-000000000103', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-0105-0000-0000-000000000105', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-0201-0000-0000-000000000201', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-0202-0000-0000-000000000202', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-0403-0000-0000-000000000403', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-0402-0000-0000-000000000402', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-1101-0000-0000-000000001101', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-0701-0000-0000-000000000701', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-0702-0000-0000-000000000702', 'system'),
(gen_random_uuid(), 'a1b2c3d4-0009-0000-0000-000000000009', 'b1c2d3e4-1201-0000-0000-000000001201', 'system');
