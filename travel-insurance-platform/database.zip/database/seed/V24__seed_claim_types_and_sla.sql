-- =============================================================================
-- V24__seed_claim_types_and_sla.sql
-- Schema: ins_claims
-- Description: Seed claim types (Medical, Baggage, Trip Cancellation, etc.)
--              matching webapp claim type options, required document checklists,
--              and SLA configurations per claim type/priority.
-- =============================================================================

SET search_path = ins_claims, public;

-- =============================================================================
-- Claim Types
-- Source: webapp portals/claims-officer/app.js and portals/customer/app.js
-- =============================================================================
INSERT INTO ins_claims.claim_types
    (id, code, name, description, required_docs, default_sla_hours, is_active)
VALUES
('g1h2i3j4-0001-0000-0000-000000000001',
 'MEDICAL_EMERGENCY',
 'Medical Emergency',
 'In-patient treatment, surgery, hospitalization abroad due to sudden illness or accident',
 '["HOSPITAL_BILL","DISCHARGE_SUMMARY","PRESCRIPTION","PAYMENT_RECEIPT","PASSPORT_COPY"]'::JSONB,
 48, TRUE),

('g1h2i3j4-0002-0000-0000-000000000002',
 'BAGGAGE_LOSS',
 'Baggage & Personal Effects Loss',
 'Loss, theft, or damage to checked baggage and personal belongings during travel',
 '["AIRLINE_PROPERTY_IRREGULARITY_REPORT","POLICE_REPORT","PURCHASE_RECEIPTS","PASSPORT_COPY"]'::JSONB,
 24, TRUE),

('g1h2i3j4-0003-0000-0000-000000000003',
 'TRIP_CANCELLATION',
 'Trip Cancellation',
 'Non-refundable pre-paid expenses due to unavoidable trip cancellation before departure',
 '["CANCELLATION_PROOF","AIRLINE_REFUND_DENIAL","BOOKING_CONFIRMATION","REASON_DOCUMENT"]'::JSONB,
 48, TRUE),

('g1h2i3j4-0004-0000-0000-000000000004',
 'TRIP_INTERRUPTION',
 'Trip Interruption',
 'Additional costs incurred when cutting a trip short due to covered emergency',
 '["RETURN_TICKET","REASON_DOCUMENT","ORIGINAL_BOOKING_PROOF","ADDITIONAL_EXPENSE_RECEIPTS"]'::JSONB,
 48, TRUE),

('g1h2i3j4-0005-0000-0000-000000000005',
 'FLIGHT_DELAY',
 'Flight Delay',
 'Compensation for expenses incurred due to airline delays exceeding the threshold',
 '["AIRLINE_DELAY_CERTIFICATE","EXPENSE_RECEIPTS","BOARDING_PASS"]'::JSONB,
 12, TRUE),

('g1h2i3j4-0006-0000-0000-000000000006',
 'PROPERTY_DAMAGE',
 'Property Damage / Personal Liability',
 'Accidental damage to third-party property or personal liability claims abroad',
 '["INCIDENT_REPORT","THIRD_PARTY_CLAIM","POLICE_REPORT","RECEIPTS"]'::JSONB,
 72, TRUE),

('g1h2i3j4-0007-0000-0000-000000000007',
 'ACCIDENT_DISABILITY',
 'Accidental Death & Disablement',
 'Lump sum claim for accidental death or permanent total/partial disablement',
 '["DEATH_CERTIFICATE","AUTOPSY_REPORT","POLICE_FIR","DISABILITY_CERTIFICATE","ID_PROOF"]'::JSONB,
 96, TRUE),

('g1h2i3j4-0008-0000-0000-000000000008',
 'DENTAL_EMERGENCY',
 'Emergency Dental',
 'Emergency dental treatment required due to sudden pain or accident abroad',
 '["DENTAL_BILL","DENTIST_REPORT","PAYMENT_RECEIPT","PASSPORT_COPY"]'::JSONB,
 24, TRUE),

('g1h2i3j4-0009-0000-0000-000000000009',
 'ADVENTURE_SPORTS',
 'Adventure Sports Injury',
 'Accidental injury sustained during covered adventure or extreme sports activity',
 '["HOSPITAL_BILL","ACTIVITY_BOOKING_PROOF","DISCHARGE_SUMMARY","PAYMENT_RECEIPT"]'::JSONB,
 48, TRUE)

ON CONFLICT (code) DO NOTHING;

-- =============================================================================
-- Document Checklist Configuration per Claim Type
-- =============================================================================

-- Medical Emergency
INSERT INTO ins_claims.claim_doc_checklist_config
    (id, claim_type_id, document_type_code, document_label, is_mandatory, display_order)
VALUES
(gen_random_uuid(), 'g1h2i3j4-0001-0000-0000-000000000001', 'HOSPITAL_BILL',       'Original Hospital Bill',           TRUE,  1),
(gen_random_uuid(), 'g1h2i3j4-0001-0000-0000-000000000001', 'DISCHARGE_SUMMARY',   'Discharge Summary',                TRUE,  2),
(gen_random_uuid(), 'g1h2i3j4-0001-0000-0000-000000000001', 'PRESCRIPTION',        'Doctor Prescription',              FALSE, 3),
(gen_random_uuid(), 'g1h2i3j4-0001-0000-0000-000000000001', 'PAYMENT_RECEIPT',     'Proof of Payment',                 TRUE,  4),
(gen_random_uuid(), 'g1h2i3j4-0001-0000-0000-000000000001', 'PASSPORT_COPY',       'Passport Copy (photo + stamp page)',TRUE,  5);

-- Baggage Loss
INSERT INTO ins_claims.claim_doc_checklist_config
    (id, claim_type_id, document_type_code, document_label, is_mandatory, display_order)
VALUES
(gen_random_uuid(), 'g1h2i3j4-0002-0000-0000-000000000002', 'AIRLINE_PIR',         'Airline Property Irregularity Report (PIR)', TRUE, 1),
(gen_random_uuid(), 'g1h2i3j4-0002-0000-0000-000000000002', 'POLICE_REPORT',       'Police Report (for theft)',          FALSE, 2),
(gen_random_uuid(), 'g1h2i3j4-0002-0000-0000-000000000002', 'PURCHASE_RECEIPTS',   'Purchase Receipts for Lost Items',   FALSE, 3),
(gen_random_uuid(), 'g1h2i3j4-0002-0000-0000-000000000002', 'PASSPORT_COPY',       'Passport Copy',                     TRUE,  4);

-- Flight Delay
INSERT INTO ins_claims.claim_doc_checklist_config
    (id, claim_type_id, document_type_code, document_label, is_mandatory, display_order)
VALUES
(gen_random_uuid(), 'g1h2i3j4-0005-0000-0000-000000000005', 'DELAY_CERTIFICATE',   'Airline Delay Certificate',         TRUE,  1),
(gen_random_uuid(), 'g1h2i3j4-0005-0000-0000-000000000005', 'EXPENSE_RECEIPTS',    'Expense Receipts (meals, hotel)',   FALSE, 2),
(gen_random_uuid(), 'g1h2i3j4-0005-0000-0000-000000000005', 'BOARDING_PASS',       'Boarding Pass',                     TRUE,  3);

-- =============================================================================
-- SLA Configurations
-- =============================================================================
INSERT INTO ins_claims.claim_sla_config
    (id, claim_type_id, priority, resolution_hours, escalation_hours, is_active)
VALUES
-- Generic (all types) by priority
(gen_random_uuid(), NULL, 'CRITICAL', 8,  4,  TRUE),
(gen_random_uuid(), NULL, 'HIGH',     24, 12, TRUE),
(gen_random_uuid(), NULL, 'MEDIUM',   48, 24, TRUE),
(gen_random_uuid(), NULL, 'LOW',      72, 48, TRUE),

-- Medical Emergency: tighter SLA
(gen_random_uuid(), 'g1h2i3j4-0001-0000-0000-000000000001', 'HIGH',     12, 6,  TRUE),
(gen_random_uuid(), 'g1h2i3j4-0001-0000-0000-000000000001', 'MEDIUM',   24, 12, TRUE),

-- Accidental Death: special handling
(gen_random_uuid(), 'g1h2i3j4-0007-0000-0000-000000000007', 'HIGH',     48, 24, TRUE),
(gen_random_uuid(), 'g1h2i3j4-0007-0000-0000-000000000007', 'MEDIUM',   72, 48, TRUE)

ON CONFLICT DO NOTHING;
