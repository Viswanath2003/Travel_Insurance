package com.insurance.service;

import com.insurance.dao.impl.PolicyDaoImpl;
import com.insurance.dto.PolicyDto;
import com.insurance.entity.Policy;
import com.insurance.service.impl.PolicyServiceImpl;
import org.junit.jupiter.api.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for PolicyServiceImpl.
 *
 * DESIGN PRINCIPLES:
 * - Every test creates its own policy via service, asserts, then deletes.
 * - No shared mutable state between tests - no @Order cross-dependencies.
 * - Seed data used only for immutable customer/plan IDs.
 * - @BeforeAll cleans any stale test data.
 * - Each test is fully independent and repeatable.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class PolicyServiceTest {

    private static final PolicyService    service   = new PolicyServiceImpl();
    private static final PolicyDaoImpl    policyDao = new PolicyDaoImpl();

    private static final String CUSTOMER_1   = "a1000000-0000-0000-0000-000000000001";
    private static final String CUSTOMER_2   = "a1000000-0000-0000-0000-000000000002";
    private static final String PLAN_BASIC   = "e1000000-0000-0000-0000-000000000001";
    private static final String PLAN_PLUS    = "e1000000-0000-0000-0000-000000000002";
    private static final String PLAN_PRO     = "e1000000-0000-0000-0000-000000000003";

    // ?? Helpers ???????????????????????????????????????????????????????????????

    /** Creates a PolicyDto and submits via service, returns the created Policy. */
    private Policy createAndGet(String custId, String planId, String dest,
                                int days, int travelers, List<Integer> ages,
                                String purpose) {
        LocalDate start = LocalDate.now().plusDays(7);
        LocalDate end   = start.plusDays(days);
        PolicyDto dto = new PolicyDto(custId, planId, dest, start, end,
                travelers, ages, purpose, "INR", new ArrayList<>());
        return service.createPolicy(dto);
    }

    private void safeDelete(String id) {
        if (id != null) try { policyDao.delete(id); } catch (Exception ignored) {}
    }

    // ?? findAll / findByPolicyNumber ??????????????????????????????????????????

    @Test @Order(1)
    @DisplayName("findAll: at least 3 seed policies exist")
    void findAll_atLeastThree() {
        List<Policy> list = service.findAll();
        assertTrue(list.size() >= 3);
        list.forEach(p -> {
            assertNotNull(p.getId());
            assertNotNull(p.getPolicyNumber());
        });
    }

    @Test @Order(2)
    @DisplayName("findByPolicyNumber: POL-2026-000001 returns correct record")
    void findByPolicyNumber_seed() {
        Policy p = service.findByPolicyNumber("POL-2026-000001");
        assertNotNull(p);
        assertEquals("POL-2026-000001", p.getPolicyNumber());
        assertEquals(CUSTOMER_1,         p.getCustomerId());
    }

    // ?? createPolicy: risk scoring ????????????????????????????????????????????

    @Test @Order(3)
    @DisplayName("createPolicy: India/LEISURE/5days = LOW risk -> QUOTED, premium positive")
    void createPolicy_lowRisk_quoted() {
        List<Integer> ages = List.of(30);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "IN", 5, 1, ages, "LEISURE");
        try {
            assertNotNull(p);
            assertTrue(p.getPolicyNumber().startsWith("POL-"));
            assertEquals("QUOTED", p.getStatus());
            assertEquals("LOW",    p.getRiskLevel());
            assertNull(p.getIssueDate());
            assertTrue(p.getTotalPremium().compareTo(BigDecimal.ZERO) > 0);
            assertTrue(p.getRiskScore().doubleValue() >= 1.0);
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(4)
    @DisplayName("createPolicy: FR/LEISURE/8days = MEDIUM risk (3.0-5.9) -> QUOTED")
    void createPolicy_mediumRisk_quoted() {
        // FR(+3.0) + 8days(+0.5) = 3.5 MEDIUM
        List<Integer> ages = List.of(40);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "FR", 8, 1, ages, "LEISURE");
        try {
            assertEquals("QUOTED",  p.getStatus());
            assertEquals("MEDIUM",  p.getRiskLevel());
            assertTrue(p.getRiskScore().doubleValue() >= 3.0);
            assertTrue(p.getRiskScore().doubleValue() < 6.0);
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(5)
    @DisplayName("createPolicy: US/BUSINESS/10days = HIGH risk (>=6.0) -> PENDING_UW")
    void createPolicy_highRisk_pendingUw() {
        // US(+4.0) + BUSINESS(+1.5) + 10days(+0.5) = 6.0 HIGH
        List<Integer> ages = List.of(35);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "US", 10, 1, ages, "BUSINESS");
        try {
            assertEquals("PENDING_UW", p.getStatus());
            assertEquals("HIGH",       p.getRiskLevel());
            assertTrue(p.getRiskScore().doubleValue() >= 6.0);
            assertNull(p.getIssueDate());
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(6)
    @DisplayName("createPolicy: senior traveler age 65 adds +1.0 to risk")
    void createPolicy_age65_addsOnePoint() {
        // IN(+1.0) + age65(+1.0) = 2.0 LOW
        List<Integer> ages = List.of(65);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "IN", 5, 1, ages, "LEISURE");
        try {
            assertTrue(p.getRiskScore().doubleValue() >= 2.0,
                    "age 65 must add 1.0. Score=" + p.getRiskScore());
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(7)
    @DisplayName("createPolicy: very senior age 75 adds +1.5 -> US+age75 = 5.5 MEDIUM")
    void createPolicy_age75_addsOnePointFive() {
        // US(+4.0) + age75(+1.5) = 5.5 MEDIUM
        List<Integer> ages = List.of(75);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "US", 5, 1, ages, "LEISURE");
        try {
            assertEquals("MEDIUM", p.getRiskLevel(),
                    "US+age75=5.5 must be MEDIUM. Score=" + p.getRiskScore());
            assertTrue(p.getRiskScore().doubleValue() >= 5.0);
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(8)
    @DisplayName("createPolicy: infant age 3 adds +0.5 -> IN+age3 = 1.5 LOW")
    void createPolicy_age3_addsHalfPoint() {
        // IN(+1.0) + age3(+0.5) = 1.5 LOW
        List<Integer> ages = List.of(3);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "IN", 5, 1, ages, "LEISURE");
        try {
            assertTrue(p.getRiskScore().doubleValue() >= 1.5,
                    "age 3 must add 0.5. Score=" + p.getRiskScore());
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(9)
    @DisplayName("createPolicy: multiple seniors, age loading capped at +2.0")
    void createPolicy_multipleSeniors_ageLoadingCapped() {
        // IN(+1.0) + age72(+1.5) + age68(+1.0) => age cap = +2.0 => total ~3.5
        List<Integer> ages = List.of(72, 68);
        Policy p = createAndGet(CUSTOMER_1, PLAN_PLUS, "IN", 5, 2, ages, "LEISURE");
        try {
            // Age loading must NOT exceed 2.0
            assertTrue(p.getRiskScore().doubleValue() <= 6.0,
                    "Age loading capped. Score=" + p.getRiskScore());
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(10)
    @DisplayName("createPolicy: BUSINESS purpose adds +1.5")
    void createPolicy_businessPurpose_addsRisk() {
        // IN(+1.0) + BUSINESS(+1.5) = 2.5
        List<Integer> ages = List.of(35);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "IN", 5, 1, ages, "BUSINESS");
        try {
            assertTrue(p.getRiskScore().doubleValue() >= 2.5,
                    "BUSINESS must add 1.5. Score=" + p.getRiskScore());
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(11)
    @DisplayName("createPolicy: >30 days adds +2.0 duration risk")
    void createPolicy_over30Days_addsTwoRisk() {
        // IN(+1.0) + 35days(+2.0) = 3.0 MEDIUM
        List<Integer> ages = List.of(30);
        Policy p = createAndGet(CUSTOMER_1, PLAN_PLUS, "IN", 35, 1, ages, "LEISURE");
        try {
            assertTrue(p.getRiskScore().doubleValue() >= 3.0,
                    ">30 days must add 2.0. Score=" + p.getRiskScore());
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(12)
    @DisplayName("createPolicy: 5+ travelers adds +1.0 group risk")
    void createPolicy_fiveTravelers_addsGroupRisk() {
        // IN(+1.0) + 5 travelers(+1.0) = 2.0
        List<Integer> ages = List.of(30, 31, 32, 33, 34);
        Policy p = createAndGet(CUSTOMER_1, PLAN_PLUS, "IN", 5, 5, ages, "LEISURE");
        try {
            assertTrue(p.getRiskScore().doubleValue() >= 2.0,
                    "5 travelers must add 1.0. Score=" + p.getRiskScore());
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(13)
    @DisplayName("createPolicy: AU destination adds +3.5 -> MEDIUM risk")
    void createPolicy_australia_mediumRisk() {
        List<Integer> ages = List.of(30);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "AU", 5, 1, ages, "LEISURE");
        try {
            assertEquals("MEDIUM", p.getRiskLevel());
            assertTrue(p.getRiskScore().doubleValue() >= 3.5);
        } finally { safeDelete(p.getId()); }
    }

    // ?? activatePolicy ????????????????????????????????????????????????????????

    @Test @Order(14)
    @DisplayName("activatePolicy: QUOTED -> ACTIVE, issueDate stamped")
    void activatePolicy_quotedToActive() {
        List<Integer> ages = List.of(30);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "IN", 5, 1, ages, "LEISURE");
        try {
            service.activatePolicy(p.getId());
            Policy updated = policyDao.findById(p.getId());
            assertEquals("ACTIVE", updated.getStatus());
            assertNotNull(updated.getIssueDate());
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(15)
    @DisplayName("activatePolicy: PENDING_UW -> ACTIVE (UW approval)")
    void activatePolicy_pendingUwToActive() {
        // US+BUSINESS+10days = HIGH -> PENDING_UW
        List<Integer> ages = List.of(40);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "US", 10, 1, ages, "BUSINESS");
        try {
            assertEquals("PENDING_UW", p.getStatus());
            service.activatePolicy(p.getId());
            assertEquals("ACTIVE", policyDao.findById(p.getId()).getStatus());
            assertNotNull(policyDao.findById(p.getId()).getIssueDate());
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(16)
    @DisplayName("activatePolicy: already ACTIVE throws IllegalStateException")
    void activatePolicy_alreadyActive_throws() {
        List<Integer> ages = List.of(30);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "IN", 5, 1, ages, "LEISURE");
        try {
            service.activatePolicy(p.getId());
            assertThrows(IllegalStateException.class, () -> service.activatePolicy(p.getId()));
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(17)
    @DisplayName("activatePolicy: non-existent ID throws")
    void activatePolicy_nonExistent_throws() {
        assertThrows(Exception.class,
                () -> service.activatePolicy("00000000-0000-0000-0000-000000000000"));
    }

    // ?? cancelPolicy ?????????????????????????????????????????????????????????

    @Test @Order(18)
    @DisplayName("cancelPolicy: QUOTED -> CANCELLED")
    void cancelPolicy_quotedToCancelled() {
        List<Integer> ages = List.of(30);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "IN", 5, 1, ages, "LEISURE");
        try {
            service.cancelPolicy(p.getId());
            assertEquals("CANCELLED", policyDao.findById(p.getId()).getStatus());
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(19)
    @DisplayName("cancelPolicy: with reason stores cancellationReason")
    void cancelPolicy_withReason() {
        List<Integer> ages = List.of(25);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "IN", 5, 1, ages, "LEISURE");
        try {
            service.cancelPolicy(p.getId(), "Medical reason - unable to travel");
            Policy updated = policyDao.findById(p.getId());
            assertEquals("CANCELLED",                       updated.getStatus());
            assertEquals("Medical reason - unable to travel", updated.getCancellationReason());
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(20)
    @DisplayName("cancelPolicy: ACTIVE -> CANCELLED")
    void cancelPolicy_activeToCancelled() {
        List<Integer> ages = List.of(30);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "IN", 5, 1, ages, "LEISURE");
        try {
            service.activatePolicy(p.getId());
            service.cancelPolicy(p.getId());
            assertEquals("CANCELLED", policyDao.findById(p.getId()).getStatus());
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(21)
    @DisplayName("cancelPolicy: already CANCELLED throws IllegalStateException")
    void cancelPolicy_alreadyCancelled_throws() {
        List<Integer> ages = List.of(30);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "IN", 5, 1, ages, "LEISURE");
        try {
            service.cancelPolicy(p.getId());
            assertThrows(IllegalStateException.class, () -> service.cancelPolicy(p.getId()));
        } finally { safeDelete(p.getId()); }
    }

    // ?? saveAsQuote ???????????????????????????????????????????????????????????

    @Test @Order(22)
    @DisplayName("saveAsQuote: policy stays QUOTED")
    void saveAsQuote_remainsQuoted() {
        List<Integer> ages = List.of(30);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "IN", 5, 1, ages, "LEISURE");
        try {
            service.saveAsQuote(p.getId());
            assertEquals("QUOTED", policyDao.findById(p.getId()).getStatus());
        } finally { safeDelete(p.getId()); }
    }

    // ?? findByCustomerId / findByStatus ???????????????????????????????????????

    @Test @Order(23)
    @DisplayName("findByCustomerId: Shankar's policies all belong to him")
    void findByCustomerId_shankar() {
        List<Policy> list = service.findByCustomerId(CUSTOMER_1);
        assertFalse(list.isEmpty());
        list.forEach(p -> assertEquals(CUSTOMER_1, p.getCustomerId()));
    }

    @Test @Order(24)
    @DisplayName("findByStatus: PENDING_UW policies all correct status")
    void findByStatus_pendingUw() {
        List<Integer> ages = List.of(35);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "US", 10, 1, ages, "BUSINESS");
        try {
            List<Policy> list = service.findByStatus("PENDING_UW");
            assertFalse(list.isEmpty());
            list.forEach(pl -> assertEquals("PENDING_UW", pl.getStatus()));
        } finally { safeDelete(p.getId()); }
    }

    // ?? PP_PLUS and PP_PRO plans ??????????????????????????????????????????????

    @Test @Order(25)
    @DisplayName("createPolicy: PP_PLUS plan, JP destination -> premium higher than BASIC")
    void createPolicy_ppPlus_jpDestination() {
        List<Integer> ages = List.of(30);
        Policy p = createAndGet(CUSTOMER_2, PLAN_PLUS, "JP", 10, 1, ages, "LEISURE");
        try {
            assertNotNull(p);
            assertEquals(PLAN_PLUS, p.getPlanId());
            // PP_PLUS(999 base, 300/day): 999 + 300*10 = 3999 + loading
            assertTrue(p.getTotalPremium().compareTo(new BigDecimal("3000")) > 0);
        } finally { safeDelete(p.getId()); }
    }

    @Test @Order(26)
    @DisplayName("createPolicy: PP_PRO plan persisted correctly")
    void createPolicy_ppPro_persisted() {
        List<Integer> ages = List.of(35);
        Policy p = createAndGet(CUSTOMER_2, PLAN_PRO, "AE", 7, 1, ages, "BUSINESS");
        try {
            assertNotNull(p);
            assertEquals(PLAN_PRO, p.getPlanId());
            assertTrue(p.getTotalPremium().compareTo(BigDecimal.ZERO) > 0);
        } finally { safeDelete(p.getId()); }
    }

    // ?? Validation / negative tests ???????????????????????????????????????????

    @Test @Order(27)
    @DisplayName("createPolicy: end date before start date throws IllegalArgumentException")
    void createPolicy_endBeforeStart_throws() {
        PolicyDto dto = new PolicyDto(CUSTOMER_1, PLAN_BASIC, "US",
                LocalDate.now().plusDays(10), LocalDate.now().plusDays(5),
                1, "BUSINESS", "INR", new ArrayList<>());
        assertThrows(IllegalArgumentException.class, () -> service.createPolicy(dto));
    }

    @Test @Order(28)
    @DisplayName("createPolicy: past start date throws IllegalArgumentException")
    void createPolicy_pastStart_throws() {
        PolicyDto dto = new PolicyDto(CUSTOMER_1, PLAN_BASIC, "US",
                LocalDate.now().minusDays(1), LocalDate.now().plusDays(5),
                1, "LEISURE", "INR", new ArrayList<>());
        assertThrows(IllegalArgumentException.class, () -> service.createPolicy(dto));
    }

    @Test @Order(29)
    @DisplayName("createPolicy: zero travelers throws IllegalArgumentException")
    void createPolicy_zeroTravelers_throws() {
        PolicyDto dto = new PolicyDto(CUSTOMER_1, PLAN_BASIC, "IN",
                LocalDate.now().plusDays(5), LocalDate.now().plusDays(10),
                0, "LEISURE", "INR", new ArrayList<>());
        assertThrows(IllegalArgumentException.class, () -> service.createPolicy(dto));
    }

    @Test @Order(30)
    @DisplayName("createPolicy: null customerId throws")
    void createPolicy_nullCustomer_throws() {
        PolicyDto dto = new PolicyDto(null, PLAN_BASIC, "US",
                LocalDate.now().plusDays(5), LocalDate.now().plusDays(10),
                1, "LEISURE", "INR", new ArrayList<>());
        assertThrows(Exception.class, () -> service.createPolicy(dto));
    }

    // ?? premium calculation ???????????????????????????????????????????????????

    @Test @Order(31)
    @DisplayName("createPolicy: premium = BASE + DAILY*DAYS*TRAVELERS * (1 + risk%)")
    void createPolicy_premiumCalculation_inRange() {
        // PP_BASIC(499 base, 150/day) + 5 days + 1 traveler + IN(1.0 risk)
        // Base = 499 + 150*5*1 = 1249; loading = 1249 * (1.0*2/100) = 24.98 => ~1274
        List<Integer> ages = List.of(30);
        Policy p = createAndGet(CUSTOMER_1, PLAN_BASIC, "IN", 5, 1, ages, "LEISURE");
        try {
            assertTrue(p.getTotalPremium().compareTo(new BigDecimal("1200")) > 0);
            assertTrue(p.getTotalPremium().compareTo(new BigDecimal("1400")) < 0);
        } finally { safeDelete(p.getId()); }
    }

    // ?? today start date ?????????????????????????????????????????????????????

    @Test @Order(32)
    @DisplayName("createPolicy: start date = today succeeds")
    void createPolicy_startToday_succeeds() {
        PolicyDto dto = new PolicyDto(CUSTOMER_1, PLAN_BASIC, "IT",
                LocalDate.now(), LocalDate.now().plusDays(5),
                1, "LEISURE", "INR", new ArrayList<>());
        Policy p = service.createPolicy(dto);
        try {
            assertNotNull(p);
            assertEquals("QUOTED", p.getStatus());
        } finally { safeDelete(p.getId()); }
    }
}
