package com.insurance.service;

import com.insurance.dao.impl.UserDaoImpl;
import com.insurance.dto.UserDto;
import com.insurance.entity.User;
import com.insurance.service.impl.UserServiceImpl;
import org.junit.jupiter.api.*;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for UserServiceImpl.
 *
 * DESIGN PRINCIPLES:
 * - Every test that creates a user deletes it in try/finally.
 * - Seed data used only for READ-ONLY assertions on immutable fields.
 * - @BeforeAll removes stale test emails from prior crashed runs.
 * - No @Order cross-dependencies.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class UserServiceTest {

    private static final UserService service = new UserServiceImpl();
    private static final UserDaoImpl dao     = new UserDaoImpl();

    private static final String SEED_ID    = "a1000000-0000-0000-0000-000000000001";
    private static final String SEED_EMAIL = "shannu@gmail.com";

    // Test emails - cleaned in @BeforeAll
    private static final String[] TEST_EMAILS = {
        "us.t1@test.invalid", "us.t2@test.invalid", "us.t3@test.invalid",
        "us.t4@test.invalid", "us.t5@test.invalid", "us.t6@test.invalid",
        "us.t7@test.invalid", "us.t8@test.invalid"
    };

    @BeforeAll
    static void cleanStaleTestUsers() {
        for (String email : TEST_EMAILS) {
            User u = new UserDaoImpl().findByEmail(email);
            if (u != null) try { new UserDaoImpl().delete(u.getId()); } catch (Exception ig) {}
        }
    }

    // ?? Helper ????????????????????????????????????????????????????????????????

    private UserDto dto(String username, String email, String role, int age, boolean defPwd) {
        return new UserDto(username, email, "9800000001", "Test " + username,
                "TestHash@123!", role, age, defPwd);
    }

    private void deleteByEmail(String email) {
        User u = dao.findByEmail(email);
        if (u != null) try { dao.delete(u.getId()); } catch (Exception ig) {}
    }

    // ?? findAll / findById / findByEmail ??????????????????????????????????????

    @Test @Order(1)
    @DisplayName("findAll: at least 10 seed users")
    void findAll_atLeastTen() {
        List<User> list = service.findAll();
        assertTrue(list.size() >= 10);
    }

    @Test @Order(2)
    @DisplayName("findByEmail: Shankar Rajan found with correct role")
    void findByEmail_shankar() {
        User u = service.findByEmail(SEED_EMAIL);
        assertNotNull(u);
        assertEquals(SEED_ID,    u.getId());
        assertEquals("CUSTOMER", u.getRole());
    }

    @Test @Order(3)
    @DisplayName("findById: Shankar Rajan found with correct email")
    void findById_shankar() {
        User u = service.findById(SEED_ID);
        assertNotNull(u);
        assertEquals(SEED_EMAIL, u.getEmail());
        assertEquals(33,         u.getAge());
    }

    @Test @Order(4)
    @DisplayName("findByEmail: non-existent returns null")
    void findByEmail_nonExistent_null() {
        assertNull(service.findByEmail("nobody@nowhere.invalid"));
    }

    @Test @Order(5)
    @DisplayName("findById: non-existent returns null")
    void findById_nonExistent_null() {
        assertNull(service.findById("00000000-0000-0000-0000-000000000000"));
    }

    // ?? registerUser: happy paths ?????????????????????????????????????????????

    @Test @Order(6)
    @DisplayName("registerUser: CUSTOMER with all fields -> ACTIVE, id assigned")
    void registerUser_customer_allFields() {
        User u = service.registerUser(dto("us_t1", TEST_EMAILS[0], "CUSTOMER", 28, false));
        try {
            assertNotNull(u);
            assertNotNull(u.getId());
            assertEquals(TEST_EMAILS[0], u.getEmail());
            assertEquals("CUSTOMER",     u.getRole());
            assertEquals("ACTIVE",       u.getStatus());
            assertEquals(28,             u.getAge());
            assertFalse(u.isDefaultPassword());
            assertNotNull(u.getCreatedAt());
        } finally { deleteByEmail(TEST_EMAILS[0]); }
    }

    @Test @Order(7)
    @DisplayName("registerUser: isDefaultPassword=true persisted")
    void registerUser_defaultPassword_true() {
        User u = service.registerUser(dto("us_t2", TEST_EMAILS[1], "CUSTOMER", 22, true));
        try {
            assertTrue(u.isDefaultPassword());
        } finally { deleteByEmail(TEST_EMAILS[1]); }
    }

    @Test @Order(8)
    @DisplayName("registerUser: null role defaults to CUSTOMER")
    void registerUser_nullRole_defaultsCustomer() {
        UserDto d = new UserDto("us_t3", TEST_EMAILS[2], "9800000002",
                "Test NullRole", "Hash@1", null, 25, false);
        User u = service.registerUser(d);
        try {
            assertEquals("CUSTOMER", u.getRole());
        } finally { deleteByEmail(TEST_EMAILS[2]); }
    }

    @Test @Order(9)
    @DisplayName("registerUser: staff role FIELD_OFFICER with age=0 persisted")
    void registerUser_staffAgeZero() {
        User u = service.registerUser(dto("us_t4", TEST_EMAILS[3], "FIELD_OFFICER", 0, false));
        try {
            assertEquals("FIELD_OFFICER", u.getRole());
            assertEquals(0,               u.getAge());
        } finally { deleteByEmail(TEST_EMAILS[3]); }
    }

    @Test @Order(10)
    @DisplayName("registerUser: newly created user findable by email and by id")
    void registerUser_findableByEmailAndId() {
        User u = service.registerUser(dto("us_t5", TEST_EMAILS[4], "CUSTOMER", 30, false));
        try {
            assertNotNull(service.findByEmail(TEST_EMAILS[4]));
            assertNotNull(service.findById(u.getId()));
            assertEquals(u.getId(), service.findByEmail(TEST_EMAILS[4]).getId());
        } finally { deleteByEmail(TEST_EMAILS[4]); }
    }

    // ?? registerUser: validation failures ????????????????????????????????????

    @Test @Order(11)
    @DisplayName("registerUser: duplicate email throws IllegalStateException")
    void registerUser_duplicateEmail_throws() {
        UserDto d = dto("us_dup", SEED_EMAIL, "CUSTOMER", 30, false);
        assertThrows(IllegalStateException.class, () -> service.registerUser(d));
    }

    @Test @Order(12)
    @DisplayName("registerUser: null email throws IllegalArgumentException")
    void registerUser_nullEmail_throws() {
        UserDto d = new UserDto("us_noemail", null, "9800000003",
                "No Email", "Hash@1", "CUSTOMER", 30, false);
        assertThrows(IllegalArgumentException.class, () -> service.registerUser(d));
    }

    @Test @Order(13)
    @DisplayName("registerUser: blank email throws IllegalArgumentException")
    void registerUser_blankEmail_throws() {
        UserDto d = new UserDto("us_blank", "  ", "9800000004",
                "Blank Email", "Hash@1", "CUSTOMER", 30, false);
        assertThrows(IllegalArgumentException.class, () -> service.registerUser(d));
    }

    @Test @Order(14)
    @DisplayName("registerUser: null username throws IllegalArgumentException")
    void registerUser_nullUsername_throws() {
        UserDto d = new UserDto(null, "us.t6@test.invalid", "9800000005",
                "Null User", "Hash@1", "CUSTOMER", 30, false);
        assertThrows(IllegalArgumentException.class, () -> service.registerUser(d));
    }

    // ?? updateStatus ?????????????????????????????????????????????????????????

    @Test @Order(15)
    @DisplayName("updateStatus: ACTIVE -> INACTIVE -> ACTIVE round-trip")
    void updateStatus_inactiveAndBack() {
        User u = service.registerUser(dto("us_t7", TEST_EMAILS[6], "CUSTOMER", 25, false));
        try {
            service.updateStatus(u.getId(), "INACTIVE");
            assertEquals("INACTIVE", service.findById(u.getId()).getStatus());
            service.updateStatus(u.getId(), "ACTIVE");
            assertEquals("ACTIVE", service.findById(u.getId()).getStatus());
        } finally { deleteByEmail(TEST_EMAILS[6]); }
    }

    @Test @Order(16)
    @DisplayName("updateStatus: SUSPENDED and LOCKED statuses accepted")
    void updateStatus_suspendedAndLocked() {
        User u = service.registerUser(dto("us_t8", TEST_EMAILS[7], "CUSTOMER", 25, false));
        try {
            service.updateStatus(u.getId(), "SUSPENDED");
            assertEquals("SUSPENDED", service.findById(u.getId()).getStatus());
            service.updateStatus(u.getId(), "LOCKED");
            assertEquals("LOCKED", service.findById(u.getId()).getStatus());
        } finally { deleteByEmail(TEST_EMAILS[7]); }
    }

    @Test @Order(17)
    @DisplayName("updateStatus: invalid status throws IllegalArgumentException")
    void updateStatus_invalid_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> service.updateStatus(SEED_ID, "INVALID_STATUS_XYZ"));
    }

    @Test @Order(18)
    @DisplayName("updateStatus: non-existent user throws")
    void updateStatus_nonExistent_throws() {
        assertThrows(Exception.class,
                () -> service.updateStatus("00000000-0000-0000-0000-000000000000", "ACTIVE"));
    }

    @AfterAll
    static void finalCleanup() {
        for (String email : TEST_EMAILS) {
            User u = new UserDaoImpl().findByEmail(email);
            if (u != null) try { new UserDaoImpl().delete(u.getId()); } catch (Exception ig) {}
        }
    }
}
