package com.insurance.service;

import com.insurance.dao.impl.PaymentDaoImpl;
import com.insurance.entity.Payment;
import com.insurance.service.impl.PaymentServiceImpl;
import org.junit.jupiter.api.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for PaymentServiceImpl.
 *
 * DESIGN PRINCIPLES:
 * - Every test creates its OWN payments and deletes them inline via try/finally.
 * - Seed payment IDs used only for READ-ONLY assertions (immutable fields).
 * - No shared state between tests.
 * - Tests that create payments always delete them regardless of assertion result.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class PaymentServiceTest {

    private static final PaymentService svc        = new PaymentServiceImpl();
    private static final PaymentDaoImpl paymentDao = new PaymentDaoImpl();

    // ?? Stable seed references ????????????????????????????????????????????????
    private static final String POLICY_1     = "ab000000-0000-0000-0000-000000000001";
    private static final String POLICY_2     = "ab000000-0000-0000-0000-000000000002";
    private static final String CLAIM_1      = "ba000000-0000-0000-0000-000000000001";
    private static final String SEED_PAY_ID  = "ad000000-0000-0000-0000-000000000001";
    private static final String SEED_PAY_REF = "PAY-2026-000001";

    // ?? findAll / findById ????????????????????????????????????????????????????

    @Test @Order(1)
    @DisplayName("findAll: at least 2 seed payments, all have id and amount")
    void findAll_atLeastTwo() {
        List<Payment> list = svc.findAll();
        assertTrue(list.size() >= 2);
        list.forEach(p -> {
            assertNotNull(p.getId());
            assertNotNull(p.getAmount());
        });
    }

    @Test @Order(2)
    @DisplayName("findById: seed PAY-2026-000001 immutable fields correct")
    void findById_seedPayment_immutable() {
        Payment p = svc.findById(SEED_PAY_ID);
        assertNotNull(p);
        assertEquals(POLICY_1,            p.getPolicyId());
        assertEquals(SEED_PAY_REF,        p.getPaymentReference());
        assertEquals("PREMIUM_RECEIVED",  p.getPaymentType());
        assertEquals("COMPLETED",         p.getStatus());
        assertTrue(p.getAmount().compareTo(BigDecimal.ZERO) > 0);
        assertNotNull(p.getPaidAt());
    }

    // ?? processPayment ????????????????????????????????????????????????????????

    @Test @Order(3)
    @DisplayName("processPayment: creates PENDING PREMIUM_RECEIVED payment")
    void processPayment_createsPending() {
        Payment p = svc.processPayment(POLICY_1, new BigDecimal("5000.00"), "INR");
        try {
            assertNotNull(p);
            assertNotNull(p.getId());
            assertTrue(p.getPaymentReference().startsWith("PAY-"));
            assertEquals("PREMIUM_RECEIVED", p.getPaymentType());
            assertEquals("PENDING",          p.getStatus());
            assertEquals(POLICY_1,           p.getPolicyId());
            assertEquals(0, new BigDecimal("5000.00").compareTo(p.getAmount()));
            assertEquals("INR",              p.getCurrency());
            assertNull(p.getPaidAt());
            assertNull(p.getClaimId());
        } finally { paymentDao.delete(p.getId()); }
    }

    @Test @Order(4)
    @DisplayName("processPayment: null currency defaults to INR")
    void processPayment_nullCurrency_defaultsINR() {
        Payment p = svc.processPayment(POLICY_1, new BigDecimal("1000.00"), null);
        try {
            assertEquals("INR", p.getCurrency());
        } finally { paymentDao.delete(p.getId()); }
    }

    @Test @Order(5)
    @DisplayName("processPayment: null policyId throws IllegalArgumentException")
    void processPayment_nullPolicyId_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> svc.processPayment(null, new BigDecimal("500.00"), "INR"));
    }

    @Test @Order(6)
    @DisplayName("processPayment: zero amount throws IllegalArgumentException")
    void processPayment_zeroAmount_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> svc.processPayment(POLICY_1, BigDecimal.ZERO, "INR"));
    }

    @Test @Order(7)
    @DisplayName("processPayment: negative amount throws IllegalArgumentException")
    void processPayment_negativeAmount_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> svc.processPayment(POLICY_1, new BigDecimal("-100.00"), "INR"));
    }

    // ?? completePayment ???????????????????????????????????????????????????????

    @Test @Order(8)
    @DisplayName("completePayment: PENDING -> COMPLETED, paidAt stamped")
    void completePayment_pendingToCompleted() {
        Payment p = svc.processPayment(POLICY_1, new BigDecimal("3000.00"), "INR");
        try {
            svc.completePayment(p.getId());
            Payment updated = svc.findById(p.getId());
            assertEquals("COMPLETED", updated.getStatus());
            assertNotNull(updated.getPaidAt());
        } finally { paymentDao.delete(p.getId()); }
    }

    @Test @Order(9)
    @DisplayName("completePayment: already COMPLETED throws IllegalStateException")
    void completePayment_alreadyCompleted_throws() {
        // Seed payment is already COMPLETED
        assertThrows(IllegalStateException.class, () -> svc.completePayment(SEED_PAY_ID));
    }

    @Test @Order(10)
    @DisplayName("completePayment: non-existent ID throws")
    void completePayment_nonExistent_throws() {
        assertThrows(Exception.class,
                () -> svc.completePayment("00000000-0000-0000-0000-000000000000"));
    }

    // ?? processClaimPayout ????????????????????????????????????????????????????

    @Test @Order(11)
    @DisplayName("processClaimPayout: creates PENDING CLAIM_PAYOUT linked to claim")
    void processClaimPayout_createsPending() {
        Payment p = svc.processClaimPayout(POLICY_1, CLAIM_1, new BigDecimal("9500.00"), "INR");
        try {
            assertNotNull(p);
            assertTrue(p.getPaymentReference().startsWith("PAYOUT-"));
            assertEquals("CLAIM_PAYOUT", p.getPaymentType());
            assertEquals("PENDING",      p.getStatus());
            assertEquals(POLICY_1,       p.getPolicyId());
            assertEquals(CLAIM_1,        p.getClaimId());
            assertEquals(0, new BigDecimal("9500.00").compareTo(p.getAmount()));
            assertNull(p.getPaidAt());
        } finally { paymentDao.delete(p.getId()); }
    }

    @Test @Order(12)
    @DisplayName("processClaimPayout: null policyId throws")
    void processClaimPayout_nullPolicyId_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> svc.processClaimPayout(null, CLAIM_1, new BigDecimal("100.00"), "INR"));
    }

    @Test @Order(13)
    @DisplayName("processClaimPayout: null claimId throws")
    void processClaimPayout_nullClaimId_throws() {
        assertThrows(IllegalArgumentException.class,
                () -> svc.processClaimPayout(POLICY_1, null, new BigDecimal("100.00"), "INR"));
    }

    @Test @Order(14)
    @DisplayName("processClaimPayout: null currency defaults to INR")
    void processClaimPayout_nullCurrency_defaultsINR() {
        Payment p = svc.processClaimPayout(POLICY_2, CLAIM_1, new BigDecimal("500.00"), null);
        try {
            assertEquals("INR", p.getCurrency());
        } finally { paymentDao.delete(p.getId()); }
    }

    // ?? completeClaimPayout ???????????????????????????????????????????????????

    @Test @Order(15)
    @DisplayName("completeClaimPayout: PENDING -> COMPLETED, paidAt stamped")
    void completeClaimPayout_pendingToCompleted() {
        Payment p = svc.processClaimPayout(POLICY_1, CLAIM_1, new BigDecimal("8000.00"), "INR");
        try {
            svc.completeClaimPayout(p.getId());
            Payment updated = svc.findById(p.getId());
            assertEquals("COMPLETED",    updated.getStatus());
            assertEquals("CLAIM_PAYOUT", updated.getPaymentType());
            assertNotNull(updated.getPaidAt());
        } finally { paymentDao.delete(p.getId()); }
    }

    @Test @Order(16)
    @DisplayName("completeClaimPayout: non-existent throws")
    void completeClaimPayout_nonExistent_throws() {
        assertThrows(Exception.class,
                () -> svc.completeClaimPayout("00000000-0000-0000-0000-000000000000"));
    }

    @Test @Order(17)
    @DisplayName("completeClaimPayout: already COMPLETED throws IllegalStateException")
    void completeClaimPayout_alreadyCompleted_throws() {
        Payment p = svc.processClaimPayout(POLICY_1, CLAIM_1, new BigDecimal("1000.00"), "INR");
        try {
            svc.completeClaimPayout(p.getId());
            assertThrows(IllegalStateException.class, () -> svc.completeClaimPayout(p.getId()));
        } finally { paymentDao.delete(p.getId()); }
    }

    @Test @Order(18)
    @DisplayName("completeClaimPayout: PREMIUM_RECEIVED payment throws IllegalStateException")
    void completeClaimPayout_wrongType_throws() {
        Payment p = svc.processPayment(POLICY_1, new BigDecimal("100.00"), "INR");
        try {
            assertThrows(IllegalStateException.class, () -> svc.completeClaimPayout(p.getId()));
        } finally { paymentDao.delete(p.getId()); }
    }

    // ?? autoCreateClaimPayout ?????????????????????????????????????????????????

    @Test @Order(19)
    @DisplayName("autoCreateClaimPayout: creates PENDING payout, idempotent on second call")
    void autoCreateClaimPayout_idempotent() {
        Payment p1 = svc.autoCreateClaimPayout(POLICY_1, CLAIM_1, new BigDecimal("500.00"), "INR");
        try {
            assertNotNull(p1);
            assertEquals("CLAIM_PAYOUT", p1.getPaymentType());
            assertEquals("PENDING",      p1.getStatus());
            assertEquals(CLAIM_1,        p1.getClaimId());

            // Second call must return existing (idempotent)
            Payment p2 = svc.autoCreateClaimPayout(POLICY_1, CLAIM_1, new BigDecimal("500.00"), "INR");
            assertNotNull(p2);
            assertEquals(p1.getClaimId(), p2.getClaimId());

            if (!p1.getId().equals(p2.getId())) paymentDao.delete(p2.getId());
        } finally { paymentDao.delete(p1.getId()); }
    }

    // ?? findByPolicyId / findByStatus / findByType ????????????????????????????

    @Test @Order(20)
    @DisplayName("findByPolicyId: seed policy 1 has at least 1 payment")
    void findByPolicyId_policy1_notEmpty() {
        List<Payment> list = svc.findByPolicyId(POLICY_1);
        assertFalse(list.isEmpty());
        list.forEach(p -> assertEquals(POLICY_1, p.getPolicyId()));
    }

    @Test @Order(21)
    @DisplayName("findByPolicyId: unknown policy returns empty list")
    void findByPolicyId_unknown_empty() {
        assertTrue(svc.findByPolicyId("00000000-0000-0000-0000-000000000000").isEmpty());
    }

    @Test @Order(22)
    @DisplayName("findByStatus: COMPLETED returns only COMPLETED payments")
    void findByStatus_completed() {
        List<Payment> list = svc.findByStatus("COMPLETED");
        assertFalse(list.isEmpty());
        list.forEach(p -> assertEquals("COMPLETED", p.getStatus()));
    }

    @Test @Order(23)
    @DisplayName("findByStatus: PENDING includes freshly created payment")
    void findByStatus_pending_includesNew() {
        Payment p = svc.processPayment(POLICY_1, new BigDecimal("200.00"), "INR");
        try {
            List<Payment> pending = svc.findByStatus("PENDING");
            assertTrue(pending.stream().anyMatch(x -> x.getId().equals(p.getId())));
        } finally { paymentDao.delete(p.getId()); }
    }

    @Test @Order(24)
    @DisplayName("findByStatus: unknown status returns empty list")
    void findByStatus_unknown_empty() {
        assertTrue(svc.findByStatus("NOT_A_STATUS_XYZ").isEmpty());
    }

    @Test @Order(25)
    @DisplayName("findByType: PREMIUM_RECEIVED returns only premiums")
    void findByType_premiumReceived() {
        List<Payment> list = svc.findByType("PREMIUM_RECEIVED");
        assertFalse(list.isEmpty());
        list.forEach(p -> assertEquals("PREMIUM_RECEIVED", p.getPaymentType()));
    }

    @Test @Order(26)
    @DisplayName("findByType: CLAIM_PAYOUT includes freshly created payout")
    void findByType_claimPayout_includesNew() {
        Payment p = svc.processClaimPayout(POLICY_1, CLAIM_1, new BigDecimal("300.00"), "INR");
        try {
            List<Payment> payouts = svc.findByType("CLAIM_PAYOUT");
            assertTrue(payouts.stream().anyMatch(x -> x.getId().equals(p.getId())));
            payouts.forEach(pp -> assertEquals("CLAIM_PAYOUT", pp.getPaymentType()));
        } finally { paymentDao.delete(p.getId()); }
    }

    @Test @Order(27)
    @DisplayName("findByType: unknown type returns empty list")
    void findByType_unknown_empty() {
        assertTrue(svc.findByType("UNKNOWN_TYPE_XYZ").isEmpty());
    }

    // ?? findByClaimId ?????????????????????????????????????????????????????????

    @Test @Order(28)
    @DisplayName("findByClaimId: returns payout linked to claim")
    void findByClaimId_returnsPayout() {
        Payment p = svc.processClaimPayout(POLICY_1, CLAIM_1, new BigDecimal("1000.00"), "INR");
        try {
            List<Payment> list = svc.findByClaimId(CLAIM_1);
            assertFalse(list.isEmpty());
            assertTrue(list.stream().anyMatch(x -> x.getId().equals(p.getId())));
            list.forEach(pp -> assertEquals(CLAIM_1, pp.getClaimId()));
        } finally { paymentDao.delete(p.getId()); }
    }

    @Test @Order(29)
    @DisplayName("findByClaimId: unknown claim returns empty list")
    void findByClaimId_unknown_empty() {
        assertTrue(svc.findByClaimId("00000000-0000-0000-0000-000000000000").isEmpty());
    }

    // ?? getFinanceSummary ?????????????????????????????????????????????????????

    @Test @Order(30)
    @DisplayName("getFinanceSummary: all required keys present, totalCredited > 0")
    void getFinanceSummary_keysAndValues() {
        Map<String, BigDecimal> summary = svc.getFinanceSummary();
        assertNotNull(summary);
        assertTrue(summary.containsKey("totalCredited"));
        assertTrue(summary.containsKey("totalSettled"));
        assertTrue(summary.containsKey("netBalance"));
        assertTrue(summary.containsKey("settlementPct"));
        assertTrue(summary.get("totalCredited").compareTo(BigDecimal.ZERO) > 0,
                "Seed has 2 completed premiums so totalCredited must be positive");
        BigDecimal net = summary.get("totalCredited").subtract(summary.get("totalSettled"));
        assertEquals(0, net.compareTo(summary.get("netBalance")));
    }
}
