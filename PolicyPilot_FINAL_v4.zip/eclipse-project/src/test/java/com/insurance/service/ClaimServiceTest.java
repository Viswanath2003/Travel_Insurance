package com.insurance.service;

import com.insurance.dao.impl.ClaimDaoImpl;
import com.insurance.dao.impl.PaymentDaoImpl;
import com.insurance.dto.ClaimDto;
import com.insurance.entity.Claim;
import com.insurance.service.impl.ClaimServiceImpl;
import org.junit.jupiter.api.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for ClaimServiceImpl.
 *
 * DESIGN PRINCIPLES:
 * - Every test creates its OWN claim via service and deletes it inline.
 * - Seed claims are NOT modified by any test here.
 * - No @Order cross-dependencies.
 * - @BeforeAll has no cleanup needed (all tests self-contained via try/finally).
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ClaimServiceTest {

    private static final ClaimService   svc        = new ClaimServiceImpl();
    private static final ClaimDaoImpl   claimDao   = new ClaimDaoImpl();
    private static final PaymentDaoImpl paymentDao = new PaymentDaoImpl();

    // ?? Stable seed references (immutable) ???????????????????????????????????
    private static final String ACTIVE_POLICY   = "ab000000-0000-0000-0000-000000000001";
    private static final String ACTIVE_POLICY_2 = "ab000000-0000-0000-0000-000000000002";
    private static final String PENDING_POLICY  = "ab000000-0000-0000-0000-000000000003";
    private static final String CUSTOMER_1      = "a1000000-0000-0000-0000-000000000001";
    private static final String CUSTOMER_2      = "a1000000-0000-0000-0000-000000000002";
    private static final String TYPE_MED        = "af000000-0000-0000-0000-000000000001";
    private static final String TYPE_BAG        = "af000000-0000-0000-0000-000000000003";
    private static final String OFFICER         = "a1000000-0000-0000-0000-000000000005";
    private static final String FIELD_OFFICER   = "a1000000-0000-0000-0000-000000000009";

    // ?? Helper: create ClaimDto ???????????????????????????????????????????????

    private ClaimDto dto(String polId, String custId, String typeId,
                         LocalDate date, String desc, BigDecimal amount) {
        return new ClaimDto(polId, custId, typeId, date, desc, amount);
    }

    /** Submit a claim and delete its auto-created payment records. */
    private void deleteClaimAndPayments(String claimId) {
        // delete any CLAIM_PAYOUT payments linked to this claim
        try {
            paymentDao.findByClaimId(claimId)
                      .forEach(p -> { try { paymentDao.delete(p.getId()); } catch (Exception ig) {} });
        } catch (Exception ignored) {}
        try { claimDao.delete(claimId); } catch (Exception ignored) {}
    }

    // ?? submitClaim: happy paths ??????????????????????????????????????????????

    @Test @Order(1)
    @DisplayName("submitClaim: ACTIVE policy -> SUBMITTED, ref starts CLM-")
    void submitClaim_active_submitted() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.of(2026, 6, 7), "Fractured wrist during hotel pool incident",
                new BigDecimal("8000.00"));
        Claim c = svc.submitClaim(d);
        try {
            assertNotNull(c);
            assertTrue(c.getClaimReference().startsWith("CLM-"));
            assertEquals("SUBMITTED",  c.getStatus());
            assertEquals(ACTIVE_POLICY, c.getPolicyId());
            assertEquals(CUSTOMER_1,    c.getCustomerId());
            assertEquals(TYPE_MED,      c.getClaimTypeId());
            assertEquals(0, new BigDecimal("8000.00").compareTo(c.getClaimedAmount()));
            assertFalse(c.isHighValue(), "8000 < 100000 must not be high value");
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(2)
    @DisplayName("submitClaim: amount > 100000 flagged as HIGH VALUE")
    void submitClaim_highValue_flagged() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.of(2026, 6, 7), "Emergency surgery with multiple procedures",
                new BigDecimal("150000.00"));
        Claim c = svc.submitClaim(d);
        try {
            assertTrue(c.isHighValue(), "150000 > 100000 must be HIGH VALUE");
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(3)
    @DisplayName("submitClaim: at exactly 100000 is NOT high value (> not >=)")
    void submitClaim_exactlyAtBoundary_notHighValue() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.now().minusDays(1), "Exactly at high value boundary claim test",
                new BigDecimal("100000.00"));
        Claim c = svc.submitClaim(d);
        try {
            assertFalse(c.isHighValue(), "100000 is not > 100000 must NOT be high value");
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(4)
    @DisplayName("submitClaim: at 100001 IS high value")
    void submitClaim_oneAboveBoundary_isHighValue() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.now().minusDays(1), "One above boundary high value claim test",
                new BigDecimal("100001.00"));
        Claim c = svc.submitClaim(d);
        try {
            assertTrue(c.isHighValue(), "100001 > 100000 must be HIGH VALUE");
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(5)
    @DisplayName("submitClaim: BAGGAGE type on ACTIVE policy succeeds")
    void submitClaim_baggageType() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_BAG,
                LocalDate.of(2026, 6, 5), "Checked bag lost by airline on outbound flight",
                new BigDecimal("12000.00"));
        Claim c = svc.submitClaim(d);
        try {
            assertEquals("SUBMITTED", c.getStatus());
            assertEquals(TYPE_BAG,     c.getClaimTypeId());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(6)
    @DisplayName("submitClaim: second customer on second ACTIVE policy succeeds")
    void submitClaim_secondCustomer() {
        ClaimDto d = dto(ACTIVE_POLICY_2, CUSTOMER_2, TYPE_BAG,
                LocalDate.of(2026, 7, 12), "Baggage delayed claim for second customer",
                new BigDecimal("12000.00"));
        Claim c = svc.submitClaim(d);
        try {
            assertNotNull(c);
            assertEquals(CUSTOMER_2, c.getCustomerId());
            assertEquals("SUBMITTED", c.getStatus());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    // ?? updateStatus ?????????????????????????????????????????????????????????

    @Test @Order(7)
    @DisplayName("updateStatus: SUBMITTED -> IN_REVIEW persisted")
    void updateStatus_toInReview() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.of(2026, 6, 7), "Update status to IN_REVIEW integration test",
                new BigDecimal("5000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.updateStatus(c.getId(), "IN_REVIEW");
            assertEquals("IN_REVIEW", svc.findById(c.getId()).getStatus());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(8)
    @DisplayName("updateStatus: SUBMITTED -> PENDING_DOCS persisted")
    void updateStatus_toPendingDocs() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.of(2026, 6, 8), "Update status pending docs integration test",
                new BigDecimal("3000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.updateStatus(c.getId(), "PENDING_DOCS");
            assertEquals("PENDING_DOCS", svc.findById(c.getId()).getStatus());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(9)
    @DisplayName("updateStatus: invalid status throws IllegalArgumentException")
    void updateStatus_invalid_throws() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.of(2026, 6, 7), "Invalid status update test claim description",
                new BigDecimal("1000.00"));
        Claim c = svc.submitClaim(d);
        try {
            assertThrows(IllegalArgumentException.class,
                    () -> svc.updateStatus(c.getId(), "INVALID_STATUS_XYZ"));
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    // ?? rejectClaim ???????????????????????????????????????????????????????????

    @Test @Order(10)
    @DisplayName("rejectClaim: SUBMITTED -> REJECTED with reason and decidedBy")
    void rejectClaim_submitted_rejected() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_BAG,
                LocalDate.of(2026, 6, 6), "Baggage claim insufficient documentation test",
                new BigDecimal("3500.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.rejectClaim(c.getId(), "No baggage receipt or PIR document provided", OFFICER);
            Claim updated = svc.findById(c.getId());
            assertEquals("REJECTED",  updated.getStatus());
            assertEquals(OFFICER,      updated.getDecidedBy());
            assertNotNull(updated.getDecisionReason());
            assertNotNull(updated.getDecidedAt());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(11)
    @DisplayName("rejectClaim: blank reason throws IllegalArgumentException")
    void rejectClaim_blankReason_throws() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.of(2026, 6, 7), "Blank reason rejection test claim description",
                new BigDecimal("200.00"));
        Claim c = svc.submitClaim(d);
        try {
            assertThrows(IllegalArgumentException.class,
                    () -> svc.rejectClaim(c.getId(), "", OFFICER));
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(12)
    @DisplayName("rejectClaim: too-short reason throws IllegalArgumentException")
    void rejectClaim_shortReason_throws() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.of(2026, 6, 7), "Short reason rejection test claim description",
                new BigDecimal("200.00"));
        Claim c = svc.submitClaim(d);
        try {
            assertThrows(IllegalArgumentException.class,
                    () -> svc.rejectClaim(c.getId(), "Short", OFFICER));
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    // ?? approveClaim ??????????????????????????????????????????????????????????

    @Test @Order(13)
    @DisplayName("approveClaim: exact amount approved -> APPROVED, payout auto-created")
    void approveClaim_exactAmount() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.of(2026, 6, 9), "Appendix surgery emergency hospitalisation",
                new BigDecimal("20000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.approveClaim(c.getId(), new BigDecimal("20000.00"), OFFICER);
            Claim updated = svc.findById(c.getId());
            assertEquals("APPROVED",  updated.getStatus());
            assertEquals(0, new BigDecimal("20000.00").compareTo(updated.getApprovedAmount()));
            assertEquals(OFFICER,      updated.getDecidedBy());
            assertNotNull(updated.getDecidedAt());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(14)
    @DisplayName("approveClaim: partial settlement less than claimed")
    void approveClaim_partial() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_BAG,
                LocalDate.of(2026, 6, 10), "Baggage damage partial coverage deductible",
                new BigDecimal("10000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.approveClaim(c.getId(), new BigDecimal("9000.00"), OFFICER);
            assertEquals("APPROVED", svc.findById(c.getId()).getStatus());
            assertEquals(0, new BigDecimal("9000.00")
                    .compareTo(svc.findById(c.getId()).getApprovedAmount()));
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(15)
    @DisplayName("approveClaim: zero settlement is allowed")
    void approveClaim_zeroSettlement_allowed() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_BAG,
                LocalDate.of(2026, 6, 7), "Zero settlement no provable financial loss",
                new BigDecimal("5000.00"));
        Claim c = svc.submitClaim(d);
        try {
            assertDoesNotThrow(() -> svc.approveClaim(c.getId(), BigDecimal.ZERO, OFFICER));
            assertEquals("APPROVED", svc.findById(c.getId()).getStatus());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(16)
    @DisplayName("approveClaim: settlement exceeding claimed amount throws")
    void approveClaim_exceedsClaimed_throws() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.of(2026, 6, 7), "Exceed claimed amount test incident description",
                new BigDecimal("300.00"));
        Claim c = svc.submitClaim(d);
        try {
            assertThrows(IllegalArgumentException.class,
                    () -> svc.approveClaim(c.getId(), new BigDecimal("500.00"), OFFICER));
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(17)
    @DisplayName("approveClaim: negative settlement throws")
    void approveClaim_negative_throws() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.of(2026, 6, 7), "Negative amount approve test incident here",
                new BigDecimal("1000.00"));
        Claim c = svc.submitClaim(d);
        try {
            assertThrows(IllegalArgumentException.class,
                    () -> svc.approveClaim(c.getId(), new BigDecimal("-100.00"), OFFICER));
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    // ?? field officer flow ????????????????????????????????????????????????????

    @Test @Order(18)
    @DisplayName("assignFieldOfficer: -> IN_REVIEW, officer set, fieldInvestigation=true")
    void assignFieldOfficer_setsAllFields() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.now().minusDays(3), "Accident claim requiring field investigation",
                new BigDecimal("45000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.assignFieldOfficer(c.getId(), FIELD_OFFICER);
            Claim updated = svc.findById(c.getId());
            assertEquals("IN_REVIEW",   updated.getStatus());
            assertEquals(FIELD_OFFICER, updated.getAssignedOfficerId());
            assertTrue(updated.isFieldInvestigationRequired());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(19)
    @DisplayName("submitFieldFindings: FIELD_APPROVED status set")
    void submitFieldFindings_fieldApproved() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.now().minusDays(2), "Field approved investigation scenario test",
                new BigDecimal("60000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.assignFieldOfficer(c.getId(), FIELD_OFFICER);
            svc.submitFieldFindings(c.getId(), "FIELD_APPROVED", FIELD_OFFICER);
            assertEquals("FIELD_APPROVED", svc.findById(c.getId()).getStatus());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(20)
    @DisplayName("submitFieldFindings: FIELD_REJECTED status set")
    void submitFieldFindings_fieldRejected() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_BAG,
                LocalDate.now().minusDays(2), "Field rejected investigation scenario test",
                new BigDecimal("25000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.assignFieldOfficer(c.getId(), FIELD_OFFICER);
            svc.submitFieldFindings(c.getId(), "FIELD_REJECTED", FIELD_OFFICER);
            assertEquals("FIELD_REJECTED", svc.findById(c.getId()).getStatus());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(21)
    @DisplayName("approve FIELD_APPROVED claim: officer overrides recommendation -> APPROVED")
    void approve_afterFieldApproved() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.now().minusDays(1), "Final approval after field approved claim",
                new BigDecimal("18000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.assignFieldOfficer(c.getId(), FIELD_OFFICER);
            svc.submitFieldFindings(c.getId(), "FIELD_APPROVED", FIELD_OFFICER);
            svc.approveClaim(c.getId(), new BigDecimal("17000.00"), OFFICER);
            assertEquals("APPROVED", svc.findById(c.getId()).getStatus());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(22)
    @DisplayName("reject FIELD_APPROVED claim: officer overrides recommendation -> REJECTED")
    void reject_afterFieldApproved_overrides() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_BAG,
                LocalDate.now().minusDays(1), "Override field approval with rejection claim",
                new BigDecimal("8000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.assignFieldOfficer(c.getId(), FIELD_OFFICER);
            svc.submitFieldFindings(c.getId(), "FIELD_APPROVED", FIELD_OFFICER);
            svc.rejectClaim(c.getId(), "Policy exclusion applies for this incident type", OFFICER);
            assertEquals("REJECTED", svc.findById(c.getId()).getStatus());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(23)
    @DisplayName("approve FIELD_REJECTED claim: officer overrides -> APPROVED")
    void approve_afterFieldRejected_overrides() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.now().minusDays(1), "Override field rejection with approval claim",
                new BigDecimal("12000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.assignFieldOfficer(c.getId(), FIELD_OFFICER);
            svc.submitFieldFindings(c.getId(), "FIELD_REJECTED", FIELD_OFFICER);
            svc.approveClaim(c.getId(), new BigDecimal("10000.00"), OFFICER);
            assertEquals("APPROVED", svc.findById(c.getId()).getStatus());
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(24)
    @DisplayName("approveClaim: blocked while IN_REVIEW with field officer -> throws")
    void approveClaim_blockedWhileInReview() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.now().minusDays(1), "Block approve test incident description here",
                new BigDecimal("40000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.assignFieldOfficer(c.getId(), FIELD_OFFICER);
            assertThrows(IllegalStateException.class,
                    () -> svc.approveClaim(c.getId(), new BigDecimal("40000.00"), OFFICER));
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(25)
    @DisplayName("submitFieldFindings: wrong officer throws IllegalStateException")
    void submitFieldFindings_wrongOfficer_throws() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.now().minusDays(1), "Wrong officer test incident description here",
                new BigDecimal("20000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.assignFieldOfficer(c.getId(), FIELD_OFFICER);
            assertThrows(IllegalStateException.class,
                    () -> svc.submitFieldFindings(c.getId(), "FIELD_APPROVED", OFFICER));
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    @Test @Order(26)
    @DisplayName("submitFieldFindings: invalid outcome throws IllegalArgumentException")
    void submitFieldFindings_invalidOutcome_throws() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.now().minusDays(1), "Invalid outcome test incident description",
                new BigDecimal("5000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.assignFieldOfficer(c.getId(), FIELD_OFFICER);
            assertThrows(IllegalArgumentException.class,
                    () -> svc.submitFieldFindings(c.getId(), "APPROVED", FIELD_OFFICER));
        } finally { deleteClaimAndPayments(c.getId()); }
    }

    // ?? submitClaim: negative tests ???????????????????????????????????????????

    @Test @Order(27)
    @DisplayName("submitClaim: PENDING_UW policy throws IllegalStateException")
    void submitClaim_pendingUw_throws() {
        ClaimDto d = dto(PENDING_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.of(2026, 8, 10), "Claim on non-active pending UW policy",
                new BigDecimal("5000.00"));
        assertThrows(IllegalStateException.class, () -> svc.submitClaim(d));
    }

    @Test @Order(28)
    @DisplayName("submitClaim: non-existent policy throws")
    void submitClaim_nonExistentPolicy_throws() {
        ClaimDto d = dto("00000000-0000-0000-0000-000000000000", CUSTOMER_1, TYPE_MED,
                LocalDate.of(2026, 6, 7), "Non existent policy claim description here",
                new BigDecimal("100.00"));
        assertThrows(Exception.class, () -> svc.submitClaim(d));
    }

    @Test @Order(29)
    @DisplayName("submitClaim: zero amount throws IllegalArgumentException")
    void submitClaim_zeroAmount_throws() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.now(), "Zero amount claim test description here", BigDecimal.ZERO);
        assertThrows(IllegalArgumentException.class, () -> svc.submitClaim(d));
    }

    // ?? findAll / findByCustomerId / findByStatus ?????????????????????????????

    @Test @Order(30)
    @DisplayName("findAll: returns all claims including seed, all have non-null id")
    void findAll_returnsAllClaims() {
        List<Claim> list = svc.findAll();
        assertFalse(list.isEmpty());
        list.forEach(c -> {
            assertNotNull(c.getId());
            assertNotNull(c.getClaimReference());
        });
    }

    @Test @Order(31)
    @DisplayName("findById: seed CLM-2026-000001 returns correct reference")
    void findById_seedClaim() {
        Claim c = svc.findById("ba000000-0000-0000-0000-000000000001");
        assertNotNull(c);
        assertEquals("CLM-2026-000001", c.getClaimReference());
    }

    @Test @Order(32)
    @DisplayName("findByClaimReference: seed CLM-2026-000001 found")
    void findByClaimReference_seed() {
        Claim c = svc.findByClaimReference("CLM-2026-000001");
        assertNotNull(c);
        assertEquals("ba000000-0000-0000-0000-000000000001", c.getId());
    }

    @Test @Order(33)
    @DisplayName("findByCustomerId: Shankar's claims all belong to him")
    void findByCustomerId_shankar() {
        List<Claim> list = svc.findByCustomerId(CUSTOMER_1);
        assertFalse(list.isEmpty());
        list.forEach(c -> assertEquals(CUSTOMER_1, c.getCustomerId()));
    }

    @Test @Order(34)
    @DisplayName("findByStatus: APPROVED only returns APPROVED claims")
    void findByStatus_approved() {
        List<Claim> list = svc.findByStatus("APPROVED");
        assertFalse(list.isEmpty());
        list.forEach(c -> assertEquals("APPROVED", c.getStatus()));
    }

    @Test @Order(35)
    @DisplayName("findByAssignedOfficerId: returns claims for field officer")
    void findByAssignedOfficerId() {
        ClaimDto d = dto(ACTIVE_POLICY, CUSTOMER_1, TYPE_MED,
                LocalDate.now().minusDays(1), "Assignment query test claim description",
                new BigDecimal("7000.00"));
        Claim c = svc.submitClaim(d);
        try {
            svc.assignFieldOfficer(c.getId(), FIELD_OFFICER);
            List<Claim> list = svc.findByAssignedOfficerId(FIELD_OFFICER);
            assertTrue(list.stream().anyMatch(x -> x.getId().equals(c.getId())));
        } finally { deleteClaimAndPayments(c.getId()); }
    }
}
