package com.insurance.dao;

import com.insurance.dao.impl.UserDaoImpl;
import com.insurance.entity.User;
import org.junit.jupiter.api.*;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for UserDaoImpl.
 *
 * DESIGN PRINCIPLES (per requirements):
 * - Every test creates its own data and deletes it inline or in @AfterEach.
 * - Seed data used only for READ-ONLY assertions on IMMUTABLE fields (id, email, role).
 * - @BeforeAll removes stale data from prior crashed runs.
 * - No @Order dependencies that share mutable state.
 * - Fully repeatable and independent.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class UserDaoTest {

    private static final UserDao dao = new UserDaoImpl();

    // ?? Stable seed IDs (immutable fields only) ???????????????????????????????
    private static final String SEED_SHANKAR_ID    = "a1000000-0000-0000-0000-000000000001";
    private static final String SEED_SHANKAR_EMAIL = "shannu@gmail.com";
    private static final String SEED_PRIYA_EMAIL   = "priya.nair@gmail.com";
    private static final String SEED_UW_ID         = "a1000000-0000-0000-0000-000000000004";

    // ?? Test-owned IDs - never collide with seed ??????????????????????????????
    // Pattern: 99990001-XXXX-XXXX-XXXX-XXXXXXXXXXXX
    private static final String T_ID_1 = "99990001-0000-0000-0000-000000000001";
    private static final String T_ID_2 = "99990001-0000-0000-0000-000000000002";
    private static final String T_ID_3 = "99990001-0000-0000-0000-000000000003";
    private static final String T_ID_4 = "99990001-0000-0000-0000-000000000004";
    private static final String T_ID_5 = "99990001-0000-0000-0000-000000000005";
    private static final String T_ID_6 = "99990001-0000-0000-0000-000000000006";

    @BeforeAll
    static void cleanStaleTestData() {
        for (String id : new String[]{T_ID_1,T_ID_2,T_ID_3,T_ID_4,T_ID_5,T_ID_6}) {
            try { dao.delete(id); } catch (Exception ignored) {}
        }
        // Also clean by email in case UUID changed between runs
        for (String e : new String[]{
                "t1@userdao.test","t2@userdao.test","t3@userdao.test",
                "t4@userdao.test","t5@userdao.test","t6@userdao.test"}) {
            User u = dao.findByEmail(e);
            if (u != null) try { dao.delete(u.getId()); } catch (Exception ignored) {}
        }
    }

    // ?? Helpers ???????????????????????????????????????????????????????????????

    private User make(String id, String email, String role, int age, boolean defPwd) {
        User u = new User();
        u.setId(id);
        u.setUsername(id.substring(0, 12).replace("-","_"));
        u.setEmail(email);
        u.setMobile("9800000001");
        u.setFullName("Test " + email.split("@")[0]);
        u.setPasswordHash("Hash@123Test");
        u.setRole(role);
        u.setStatus("ACTIVE");
        u.setAge(age);
        u.setDefaultPassword(defPwd);
        u.setFailedLoginAttempts(0);
        u.setEmailVerified(false);
        u.setMobileVerified(false);
        u.setCreatedAt(OffsetDateTime.now());
        u.setUpdatedAt(OffsetDateTime.now());
        u.setVersion(1L);
        return u;
    }

    // ?? findAll ???????????????????????????????????????????????????????????????

    @Test @Order(1)
    @DisplayName("findAll: returns at least 10 seed users, all have id and role")
    void findAll_hasAtLeastTenUsers() {
        List<User> list = dao.findAll();
        assertNotNull(list);
        assertTrue(list.size() >= 10);
        list.forEach(u -> {
            assertNotNull(u.getId());
            assertNotNull(u.getRole());
            assertNotNull(u.getEmail());
        });
    }

    // ?? findById ??????????????????????????????????????????????????????????????

    @Test @Order(2)
    @DisplayName("findById: seed user Shankar Rajan - immutable fields correct")
    void findById_shankarImmutableFields() {
        User u = dao.findById(SEED_SHANKAR_ID);
        assertNotNull(u);
        assertEquals(SEED_SHANKAR_EMAIL, u.getEmail());
        assertEquals("CUSTOMER",        u.getRole());
        assertEquals("shankar_rajan",   u.getUsername());
        assertEquals("Shankar Rajan",   u.getFullName());
    }

    @Test @Order(3)
    @DisplayName("findById: non-existent ID returns null")
    void findById_nonExistent_null() {
        assertNull(dao.findById("00000000-0000-0000-0000-000000000000"));
    }

    // ?? findByEmail ???????????????????????????????????????????????????????????

    @Test @Order(4)
    @DisplayName("findByEmail: Shankar Rajan found by email")
    void findByEmail_shankar() {
        User u = dao.findByEmail(SEED_SHANKAR_EMAIL);
        assertNotNull(u);
        assertEquals(SEED_SHANKAR_ID, u.getId());
    }

    @Test @Order(5)
    @DisplayName("findByEmail: non-existent email returns null")
    void findByEmail_nonExistent_null() {
        assertNull(dao.findByEmail("nobody@nowhere.invalid"));
    }

    // ?? findByUsername ????????????????????????????????????????????????????????

    @Test @Order(6)
    @DisplayName("findByUsername: priya_nair found and email matches")
    void findByUsername_priya() {
        User u = dao.findByUsername("priya_nair");
        assertNotNull(u);
        assertEquals(SEED_PRIYA_EMAIL, u.getEmail());
    }

    @Test @Order(7)
    @DisplayName("findByUsername: non-existent username returns null")
    void findByUsername_nonExistent_null() {
        assertNull(dao.findByUsername("ghost_xyz_999"));
    }

    // ?? findByRole ????????????????????????????????????????????????????????????

    @Test @Order(8)
    @DisplayName("findByRole: UW_OFFICER returns Anuj Sharma")
    void findByRole_uwOfficer() {
        List<User> list = dao.findByRole("UW_OFFICER");
        assertFalse(list.isEmpty());
        list.forEach(u -> assertEquals("UW_OFFICER", u.getRole()));
        assertTrue(list.stream().anyMatch(u -> "Anuj Sharma".equals(u.getFullName())));
    }

    @Test @Order(9)
    @DisplayName("findByRole: CLAIMS_OFFICER returns Suheal Khan")
    void findByRole_claimsOfficer() {
        List<User> list = dao.findByRole("CLAIMS_OFFICER");
        assertFalse(list.isEmpty());
        list.forEach(u -> assertEquals("CLAIMS_OFFICER", u.getRole()));
    }

    @Test @Order(10)
    @DisplayName("findByRole: CUSTOMER returns at least 3 customers")
    void findByRole_customer() {
        List<User> list = dao.findByRole("CUSTOMER");
        assertTrue(list.size() >= 3);
        list.forEach(u -> assertEquals("CUSTOMER", u.getRole()));
    }

    @Test @Order(11)
    @DisplayName("findByRole: AGENT returns Gowtham Ravi")
    void findByRole_agent() {
        List<User> list = dao.findByRole("AGENT");
        assertFalse(list.isEmpty());
        assertTrue(list.stream().anyMatch(u -> "Gowtham Ravi".equals(u.getFullName())));
    }

    @Test @Order(12)
    @DisplayName("findByRole: FINANCE_OFFICER returns Udbhav Mishra")
    void findByRole_financeOfficer() {
        List<User> list = dao.findByRole("FINANCE_OFFICER");
        assertFalse(list.isEmpty());
        assertTrue(list.stream().anyMatch(u -> "Udbhav Mishra".equals(u.getFullName())));
    }

    @Test @Order(13)
    @DisplayName("findByRole: RM returns Hari Menon")
    void findByRole_rm() {
        List<User> list = dao.findByRole("RM");
        assertFalse(list.isEmpty());
        assertTrue(list.stream().anyMatch(u -> "Hari Menon".equals(u.getFullName())));
    }

    @Test @Order(14)
    @DisplayName("findByRole: FIELD_OFFICER returns Manav Singh")
    void findByRole_fieldOfficer() {
        List<User> list = dao.findByRole("FIELD_OFFICER");
        assertFalse(list.isEmpty());
        assertTrue(list.stream().anyMatch(u -> "Manav Singh".equals(u.getFullName())));
    }

    @Test @Order(15)
    @DisplayName("findByRole: IAM_ADMIN returns Vignesh Kumar")
    void findByRole_iamAdmin() {
        List<User> list = dao.findByRole("IAM_ADMIN");
        assertFalse(list.isEmpty());
        assertTrue(list.stream().anyMatch(u -> "Vignesh Kumar".equals(u.getFullName())));
    }

    @Test @Order(16)
    @DisplayName("findByRole: unknown role returns empty list")
    void findByRole_unknown_empty() {
        assertTrue(dao.findByRole("NONEXISTENT_ROLE_XYZ").isEmpty());
    }

    // ?? save / findById round-trip ????????????????????????????????????????????

    @Test @Order(17)
    @DisplayName("save+findById: all fields persisted correctly")
    void save_allFieldsPersisted() {
        User u = make(T_ID_1, "t1@userdao.test", "CUSTOMER", 28, false);
        dao.save(u);
        try {
            User found = dao.findById(T_ID_1);
            assertNotNull(found);
            assertEquals("t1@userdao.test", found.getEmail());
            assertEquals("CUSTOMER",        found.getRole());
            assertEquals("ACTIVE",          found.getStatus());
            assertEquals(28,                found.getAge());
            assertFalse(found.isDefaultPassword());
            assertFalse(found.isEmailVerified());
        } finally {
            dao.delete(T_ID_1);
        }
    }

    @Test @Order(18)
    @DisplayName("save+findById: isDefaultPassword=true persisted")
    void save_defaultPasswordTrue() {
        User u = make(T_ID_2, "t2@userdao.test", "CUSTOMER", 25, true);
        u.setPasswordHash("Welcome@7205");
        dao.save(u);
        try {
            User found = dao.findById(T_ID_2);
            assertNotNull(found);
            assertTrue(found.isDefaultPassword());
            assertEquals("Welcome@7205", found.getPasswordHash());
        } finally {
            dao.delete(T_ID_2);
        }
    }

    @Test @Order(19)
    @DisplayName("save+findById: staff user age=0 persisted")
    void save_staffAgeZero() {
        User u = make(T_ID_3, "t3@userdao.test", "FIELD_OFFICER", 0, false);
        dao.save(u);
        try {
            User found = dao.findById(T_ID_3);
            assertNotNull(found);
            assertEquals(0, found.getAge());
            assertEquals("FIELD_OFFICER", found.getRole());
        } finally {
            dao.delete(T_ID_3);
        }
    }

    @Test @Order(20)
    @DisplayName("save: duplicate ID throws RuntimeException")
    void save_duplicateId_throws() {
        User u = make(T_ID_4, "t4@userdao.test", "CUSTOMER", 30, false);
        dao.save(u);
        try {
            assertThrows(RuntimeException.class, () -> dao.save(make(T_ID_4, "t4b@userdao.test", "CUSTOMER", 30, false)));
        } finally {
            dao.delete(T_ID_4);
        }
    }

    @Test @Order(21)
    @DisplayName("save: null mobile and fullName accepted (nullable columns)")
    void save_nullableFields() {
        User u = make(T_ID_5, "t5@userdao.test", "CUSTOMER", 22, false);
        u.setMobile(null);
        u.setFullName(null);
        dao.save(u);
        try {
            User found = dao.findById(T_ID_5);
            assertNotNull(found);
            assertNull(found.getMobile());
            assertNull(found.getFullName());
        } finally {
            dao.delete(T_ID_5);
        }
    }

    // ?? update ????????????????????????????????????????????????????????????????

    @Test @Order(22)
    @DisplayName("update: status ACTIVE->INACTIVE->ACTIVE round-trip")
    void update_statusRoundTrip() {
        User u = make(T_ID_6, "t6@userdao.test", "CUSTOMER", 32, false);
        dao.save(u);
        try {
            u.setStatus("INACTIVE");
            dao.update(u);
            assertEquals("INACTIVE", dao.findById(T_ID_6).getStatus());
            u.setStatus("ACTIVE");
            dao.update(u);
            assertEquals("ACTIVE", dao.findById(T_ID_6).getStatus());
        } finally {
            dao.delete(T_ID_6);
        }
    }

    @Test @Order(23)
    @DisplayName("update: password hash change persisted")
    void update_passwordHash() {
        String id = "99990001-0000-0000-0000-000000000007";
        try { dao.delete(id); } catch (Exception ignored) {}
        User u = make(id, "t7@userdao.test", "CUSTOMER", 28, true);
        dao.save(u);
        try {
            u.setPasswordHash("NewHash@456");
            u.setDefaultPassword(false);
            dao.update(u);
            User updated = dao.findById(id);
            assertEquals("NewHash@456", updated.getPasswordHash());
            assertFalse(updated.isDefaultPassword());
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(24)
    @DisplayName("update: age change persisted")
    void update_age() {
        String id = "99990001-0000-0000-0000-000000000008";
        try { dao.delete(id); } catch (Exception ignored) {}
        User u = make(id, "t8@userdao.test", "CUSTOMER", 28, false);
        dao.save(u);
        try {
            u.setAge(35);
            dao.update(u);
            assertEquals(35, dao.findById(id).getAge());
        } finally {
            dao.delete(id);
        }
    }

    // ?? findByNameOrEmail ?????????????????????????????????????????????????????

    @Test @Order(25)
    @DisplayName("findByNameOrEmail: partial name match case-insensitive")
    void findByNameOrEmail_partialName() {
        List<User> r = dao.findByNameOrEmail("RAJAN");
        assertFalse(r.isEmpty());
        assertTrue(r.stream().anyMatch(u -> u.getFullName() != null
                && u.getFullName().toLowerCase().contains("rajan")));
    }

    @Test @Order(26)
    @DisplayName("findByNameOrEmail: partial email match")
    void findByNameOrEmail_partialEmail() {
        List<User> r = dao.findByNameOrEmail("priya.nair");
        assertFalse(r.isEmpty());
        assertTrue(r.stream().anyMatch(u -> u.getEmail().contains("priya.nair")));
    }

    @Test @Order(27)
    @DisplayName("findByNameOrEmail: no match returns empty list")
    void findByNameOrEmail_noMatch() {
        assertTrue(dao.findByNameOrEmail("xyznotexist99999").isEmpty());
    }

    // ?? findFullNameById ??????????????????????????????????????????????????????

    @Test @Order(28)
    @DisplayName("findFullNameById: Shankar Rajan returns correct name")
    void findFullNameById_shankar() {
        assertEquals("Shankar Rajan", dao.findFullNameById(SEED_SHANKAR_ID));
    }

    @Test @Order(29)
    @DisplayName("findFullNameById: UW officer Anuj Sharma")
    void findFullNameById_anuj() {
        assertEquals("Anuj Sharma", dao.findFullNameById(SEED_UW_ID));
    }

    @Test @Order(30)
    @DisplayName("findFullNameById: unknown ID returns dash")
    void findFullNameById_unknown_dash() {
        assertEquals("-", dao.findFullNameById("00000000-0000-0000-0000-000000000000"));
    }

    @Test @Order(31)
    @DisplayName("findFullNameById: null input returns dash")
    void findFullNameById_null_dash() {
        assertEquals("-", dao.findFullNameById(null));
    }

    // ?? age persistence ???????????????????????????????????????????????????????

    @Test @Order(32)
    @DisplayName("age: Shankar Rajan has age=33 in seed")
    void age_shankar33() {
        User u = dao.findById(SEED_SHANKAR_ID);
        assertNotNull(u);
        assertEquals(33, u.getAge());
    }

    @Test @Order(33)
    @DisplayName("age: Rahul Mehta has age=45 in seed")
    void age_rahul45() {
        User u = dao.findByUsername("rahul_mehta");
        assertNotNull(u);
        assertEquals(45, u.getAge());
    }

    @Test @Order(34)
    @DisplayName("age: Priya Nair has age=30 in seed")
    void age_priya30() {
        User u = dao.findByEmail(SEED_PRIYA_EMAIL);
        assertNotNull(u);
        assertEquals(30, u.getAge());
    }

    // ?? delete ????????????????????????????????????????????????????????????????

    @Test @Order(35)
    @DisplayName("delete: user cannot be found after deletion")
    void delete_userGone() {
        String id = "99990001-0000-0000-0000-000000000009";
        try { dao.delete(id); } catch (Exception ignored) {}
        User u = make(id, "t9@userdao.test", "CUSTOMER", 20, false);
        dao.save(u);
        assertNotNull(dao.findById(id));
        dao.delete(id);
        assertNull(dao.findById(id));
    }

    // ?? boundary ?????????????????????????????????????????????????????????????

    @Test @Order(36)
    @DisplayName("findAll: all users have non-null id, email, role")
    void findAll_mandatoryFieldsNonNull() {
        dao.findAll().forEach(u -> {
            assertNotNull(u.getId());
            assertNotNull(u.getEmail());
            assertNotNull(u.getRole());
        });
    }

    @Test @Order(37)
    @DisplayName("findByRole: single-char search 'a' returns results")
    void findByNameOrEmail_singleChar() {
        List<User> r = dao.findByNameOrEmail("a");
        assertTrue(r.size() >= 1);
    }

    @AfterAll
    static void finalCleanup() {
        for (int i = 1; i <= 9; i++) {
            String id = String.format("99990001-0000-0000-0000-0000000000%02d", i);
            try { dao.delete(id); } catch (Exception ignored) {}
        }
    }
}
