package com.insurance.dao;

import com.insurance.dao.impl.PolicyDaoImpl;
import com.insurance.entity.Policy;
import org.junit.jupiter.api.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for PolicyDaoImpl.
 *
 * DESIGN PRINCIPLES:
 * - Every test creates its own Policy and deletes it (inline try/finally).
 * - Seed data used ONLY for immutable reference IDs (plan, customer).
 * - Never assert mutable state on seed policies (status, cancellationReason, etc.).
 * - @BeforeAll removes stale test data from prior crashed runs.
 * - No shared mutable state between test methods.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class PolicyDaoTest {

    private static final PolicyDao dao = new PolicyDaoImpl();

    // ?? Stable seed reference IDs (immutable) ????????????????????????????????
    private static final String SEED_CUSTOMER_1  = "a1000000-0000-0000-0000-000000000001";
    private static final String SEED_CUSTOMER_2  = "a1000000-0000-0000-0000-000000000002";
    private static final String SEED_PLAN_BASIC  = "e1000000-0000-0000-0000-000000000001";
    private static final String SEED_PLAN_PLUS   = "e1000000-0000-0000-0000-000000000002";
    private static final String SEED_PLAN_PRO    = "e1000000-0000-0000-0000-000000000003";

    // ?? Test-owned IDs (prefix 99990002) ?????????????????????????????????????
    private static String[] ALL_TEST_IDS = {
        "99990002-0000-0000-0000-000000000001",
        "99990002-0000-0000-0000-000000000002",
        "99990002-0000-0000-0000-000000000003",
        "99990002-0000-0000-0000-000000000004",
        "99990002-0000-0000-0000-000000000005",
        "99990002-0000-0000-0000-000000000006",
        "99990002-0000-0000-0000-000000000007",
        "99990002-0000-0000-0000-000000000008",
        "99990002-0000-0000-0000-000000000009",
        "99990002-0000-0000-0000-000000000010"
    };

    @BeforeAll
    static void cleanStaleTestData() {
        for (String id : ALL_TEST_IDS) try { dao.delete(id); } catch (Exception ignored) {}
    }

    // ?? Helper factory ????????????????????????????????????????????????????????

    private Policy make(String id, String num, String custId, String planId, String status) {
        Policy p = new Policy();
        p.setId(id);
        p.setPolicyNumber(num);
        p.setCustomerId(custId);
        p.setPlanId(planId);
        p.setDestinationCountryCode("DE");
        p.setTripStartDate(LocalDate.of(2027, 3, 1));
        p.setTripEndDate(LocalDate.of(2027, 3, 10));
        p.setNumTravelers(2);
        p.setTripPurpose("LEISURE");
        p.setTotalPremium(new BigDecimal("3500.00"));
        p.setCurrency("INR");
        p.setRiskScore(new BigDecimal("1.50"));
        p.setRiskLevel("LOW");
        p.setStatus(status);
        p.setExpiryDate(LocalDate.of(2027, 3, 10));
        p.setRenewalCount(0);
        p.setCreatedAt(OffsetDateTime.now());
        p.setUpdatedAt(OffsetDateTime.now());
        p.setVersion(1L);
        return p;
    }

    // ?? findAll ???????????????????????????????????????????????????????????????

    @Test @Order(1)
    @DisplayName("findAll: returns at least 3 seed policies, mandatory fields non-null")
    void findAll_atLeastThree() {
        List<Policy> list = dao.findAll();
        assertTrue(list.size() >= 3);
        list.forEach(p -> {
            assertNotNull(p.getId());
            assertNotNull(p.getPolicyNumber());
            assertNotNull(p.getStatus());
            assertNotNull(p.getTripStartDate());
        });
    }

    // ?? findByPolicyNumber ????????????????????????????????????????????????????

    @Test @Order(2)
    @DisplayName("findByPolicyNumber: POL-2026-000001 found with correct immutable fields")
    void findByPolicyNumber_seed001() {
        Policy p = dao.findByPolicyNumber("POL-2026-000001");
        assertNotNull(p);
        assertEquals("ab000000-0000-0000-0000-000000000001", p.getId());
        assertEquals(SEED_CUSTOMER_1, p.getCustomerId());
        assertEquals(SEED_PLAN_BASIC, p.getPlanId());
        assertEquals("FR",            p.getDestinationCountryCode());
        assertNotNull(p.getTripStartDate());
        assertNotNull(p.getTripEndDate());
        // Do NOT assert status - it may have been modified by prior test runs
        assertTrue(p.getTotalPremium().compareTo(BigDecimal.ZERO) > 0);
    }

    @Test @Order(3)
    @DisplayName("findByPolicyNumber: non-existent returns null")
    void findByPolicyNumber_nonExistent_null() {
        assertNull(dao.findByPolicyNumber("POL-DOES-NOT-EXIST-999"));
    }

    // ?? findById ??????????????????????????????????????????????????????????????

    @Test @Order(4)
    @DisplayName("findById: seed policy ab-000002 (Priya JP) - immutable fields correct")
    void findById_seed002_immutableFields() {
        Policy p = dao.findById("ab000000-0000-0000-0000-000000000002");
        assertNotNull(p);
        assertEquals("POL-2026-000002", p.getPolicyNumber());
        assertEquals(SEED_CUSTOMER_2,   p.getCustomerId());
        assertEquals(SEED_PLAN_PLUS,    p.getPlanId());
        assertEquals("JP",              p.getDestinationCountryCode());
    }

    @Test @Order(5)
    @DisplayName("findById: non-existent ID returns null")
    void findById_nonExistent_null() {
        assertNull(dao.findById("00000000-0000-0000-0000-000000000000"));
    }

    // ?? findByCustomerId ??????????????????????????????????????????????????????

    @Test @Order(6)
    @DisplayName("findByCustomerId: Shankar has at least 1 policy")
    void findByCustomerId_shankar_notEmpty() {
        List<Policy> list = dao.findByCustomerId(SEED_CUSTOMER_1);
        assertFalse(list.isEmpty());
        list.forEach(p -> assertEquals(SEED_CUSTOMER_1, p.getCustomerId()));
    }

    @Test @Order(7)
    @DisplayName("findByCustomerId: Priya has at least 1 policy")
    void findByCustomerId_priya_notEmpty() {
        List<Policy> list = dao.findByCustomerId(SEED_CUSTOMER_2);
        assertFalse(list.isEmpty());
        list.forEach(p -> assertEquals(SEED_CUSTOMER_2, p.getCustomerId()));
    }

    @Test @Order(8)
    @DisplayName("findByCustomerId: unknown customer returns empty list")
    void findByCustomerId_unknown_empty() {
        assertTrue(dao.findByCustomerId("00000000-0000-0000-0000-000000000000").isEmpty());
    }

    // ?? findByStatus ??????????????????????????????????????????????????????????

    @Test @Order(9)
    @DisplayName("findByStatus: ACTIVE policies all have status=ACTIVE")
    void findByStatus_active_allActive() {
        String id = ALL_TEST_IDS[0];
        dao.save(make(id, "POL-T-0001", SEED_CUSTOMER_1, SEED_PLAN_BASIC, "ACTIVE"));
        try {
            List<Policy> list = dao.findByStatus("ACTIVE");
            assertFalse(list.isEmpty());
            list.forEach(p -> assertEquals("ACTIVE", p.getStatus()));
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(10)
    @DisplayName("findByStatus: QUOTED policies all have status=QUOTED")
    void findByStatus_quoted_allQuoted() {
        String id = ALL_TEST_IDS[1];
        dao.save(make(id, "POL-T-0002", SEED_CUSTOMER_1, SEED_PLAN_BASIC, "QUOTED"));
        try {
            List<Policy> list = dao.findByStatus("QUOTED");
            assertFalse(list.isEmpty());
            list.forEach(p -> assertEquals("QUOTED", p.getStatus()));
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(11)
    @DisplayName("findByStatus: PENDING_UW policies all have status=PENDING_UW")
    void findByStatus_pendingUw_allPendingUw() {
        String id = ALL_TEST_IDS[2];
        dao.save(make(id, "POL-T-0003", SEED_CUSTOMER_1, SEED_PLAN_BASIC, "PENDING_UW"));
        try {
            List<Policy> list = dao.findByStatus("PENDING_UW");
            assertFalse(list.isEmpty());
            list.forEach(p -> assertEquals("PENDING_UW", p.getStatus()));
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(12)
    @DisplayName("findByStatus: unknown status returns empty list")
    void findByStatus_unknown_empty() {
        assertTrue(dao.findByStatus("NOT_A_STATUS_XYZ").isEmpty());
    }

    // ?? save + findById round-trip ????????????????????????????????????????????

    @Test @Order(13)
    @DisplayName("save+findById: all fields persisted correctly")
    void save_allFieldsPersisted() {
        String id = ALL_TEST_IDS[3];
        Policy p = make(id, "POL-T-0004", SEED_CUSTOMER_1, SEED_PLAN_BASIC, "QUOTED");
        dao.save(p);
        try {
            Policy found = dao.findById(id);
            assertNotNull(found);
            assertEquals("POL-T-0004",    found.getPolicyNumber());
            assertEquals(SEED_CUSTOMER_1, found.getCustomerId());
            assertEquals(SEED_PLAN_BASIC, found.getPlanId());
            assertEquals("QUOTED",        found.getStatus());
            assertEquals("DE",            found.getDestinationCountryCode());
            assertEquals(2,               found.getNumTravelers());
            assertEquals(0, new BigDecimal("3500.00").compareTo(found.getTotalPremium()));
            assertEquals("INR",           found.getCurrency());
            assertEquals("LOW",           found.getRiskLevel());
            assertNull(found.getIssueDate());
            assertNull(found.getCancellationReason());
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(14)
    @DisplayName("save: duplicate policy ID throws RuntimeException")
    void save_duplicateId_throws() {
        String id = ALL_TEST_IDS[4];
        dao.save(make(id, "POL-T-0005", SEED_CUSTOMER_1, SEED_PLAN_BASIC, "QUOTED"));
        try {
            assertThrows(RuntimeException.class, () ->
                dao.save(make(id, "POL-T-0005b", SEED_CUSTOMER_1, SEED_PLAN_BASIC, "QUOTED")));
        } finally {
            dao.delete(id);
        }
    }

    // ?? update ????????????????????????????????????????????????????????????????

    @Test @Order(15)
    @DisplayName("update: QUOTED -> ACTIVE with issueDate stamped")
    void update_quotedToActive() {
        String id = ALL_TEST_IDS[5];
        Policy p = make(id, "POL-T-0006", SEED_CUSTOMER_1, SEED_PLAN_BASIC, "QUOTED");
        dao.save(p);
        try {
            p.setStatus("ACTIVE");
            p.setIssueDate(OffsetDateTime.now());
            dao.update(p);
            Policy updated = dao.findById(id);
            assertEquals("ACTIVE", updated.getStatus());
            assertNotNull(updated.getIssueDate());
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(16)
    @DisplayName("update: ACTIVE -> CANCELLED with cancellationReason stored")
    void update_cancelWithReason() {
        String id = ALL_TEST_IDS[6];
        Policy p = make(id, "POL-T-0007", SEED_CUSTOMER_1, SEED_PLAN_BASIC, "ACTIVE");
        p.setIssueDate(OffsetDateTime.now());
        dao.save(p);
        try {
            p.setStatus("CANCELLED");
            p.setCancellationReason("Visa rejected by embassy");
            dao.update(p);
            Policy updated = dao.findById(id);
            assertEquals("CANCELLED",              updated.getStatus());
            assertEquals("Visa rejected by embassy", updated.getCancellationReason());
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(17)
    @DisplayName("update: riskScore and riskLevel change persisted")
    void update_riskChange() {
        String id = ALL_TEST_IDS[7];
        Policy p = make(id, "POL-T-0008", SEED_CUSTOMER_2, SEED_PLAN_PLUS, "QUOTED");
        dao.save(p);
        try {
            p.setRiskScore(new BigDecimal("5.50"));
            p.setRiskLevel("MEDIUM");
            dao.update(p);
            Policy updated = dao.findById(id);
            assertEquals("MEDIUM", updated.getRiskLevel());
            assertEquals(0, new BigDecimal("5.50").compareTo(updated.getRiskScore()));
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(18)
    @DisplayName("update: PENDING_UW -> ACTIVE (UW approval)")
    void update_pendingUwToActive() {
        String id = ALL_TEST_IDS[8];
        Policy p = make(id, "POL-T-0009", SEED_CUSTOMER_2, SEED_PLAN_PRO, "PENDING_UW");
        p.setRiskLevel("HIGH");
        p.setRiskScore(new BigDecimal("7.00"));
        dao.save(p);
        try {
            p.setStatus("ACTIVE");
            p.setIssueDate(OffsetDateTime.now());
            dao.update(p);
            Policy updated = dao.findById(id);
            assertEquals("ACTIVE", updated.getStatus());
            assertNotNull(updated.getIssueDate());
        } finally {
            dao.delete(id);
        }
    }

    // ?? various plan IDs ??????????????????????????????????????????????????????

    @Test @Order(19)
    @DisplayName("save: PP_PLUS plan ID persisted correctly")
    void save_ppPlusPlan() {
        String id = ALL_TEST_IDS[9];
        Policy p = make(id, "POL-T-0010", SEED_CUSTOMER_1, SEED_PLAN_PLUS, "QUOTED");
        dao.save(p);
        try {
            assertEquals(SEED_PLAN_PLUS, dao.findById(id).getPlanId());
        } finally {
            dao.delete(id);
        }
    }

    // ?? 1-day trip boundary ???????????????????????????????????????????????????

    @Test @Order(20)
    @DisplayName("save: 1-day trip (startDate = endDate) persisted")
    void save_oneDayTrip() {
        String id = "99990002-0000-0000-0000-000000000011";
        try { dao.delete(id); } catch (Exception ignored) {}
        Policy p = make(id, "POL-T-0011", SEED_CUSTOMER_1, SEED_PLAN_BASIC, "QUOTED");
        p.setTripEndDate(p.getTripStartDate());
        dao.save(p);
        try {
            Policy found = dao.findById(id);
            assertEquals(found.getTripStartDate(), found.getTripEndDate());
        } finally {
            dao.delete(id);
        }
    }

    @AfterAll
    static void finalCleanup() {
        for (String id : ALL_TEST_IDS) try { dao.delete(id); } catch (Exception ignored) {}
        try { dao.delete("99990002-0000-0000-0000-000000000011"); } catch (Exception ignored) {}
    }
}
