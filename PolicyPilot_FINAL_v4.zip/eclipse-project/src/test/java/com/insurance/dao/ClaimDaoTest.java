package com.insurance.dao;

import com.insurance.dao.impl.ClaimDaoImpl;
import com.insurance.entity.Claim;
import org.junit.jupiter.api.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for ClaimDaoImpl.
 *
 * DESIGN PRINCIPLES:
 * - NO assertions on seed claim STATUS (it is mutable and may have changed).
 * - Each test creates its own Claim, asserts on it, and deletes it in try/finally.
 * - Seed data used only for: policyId and customerId references (immutable FK targets).
 * - @BeforeAll cleans all test-owned IDs from prior crashed runs.
 */
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ClaimDaoTest {

    private static final ClaimDao dao = new ClaimDaoImpl();

    // ?? Stable seed references (immutable FK targets) ?????????????????????????
    private static final String SEED_POLICY_1    = "ab000000-0000-0000-0000-000000000001";
    private static final String SEED_POLICY_2    = "ab000000-0000-0000-0000-000000000002";
    private static final String SEED_CUSTOMER_1  = "a1000000-0000-0000-0000-000000000001";
    private static final String SEED_CUSTOMER_2  = "a1000000-0000-0000-0000-000000000002";
    private static final String SEED_OFFICER     = "a1000000-0000-0000-0000-000000000005";
    private static final String SEED_FIELD_OFF   = "a1000000-0000-0000-0000-000000000009";
    private static final String SEED_TYPE_MED    = "af000000-0000-0000-0000-000000000001";
    private static final String SEED_TYPE_BAG    = "af000000-0000-0000-0000-000000000003";

    // ?? Test-owned IDs (prefix 99990003) ?????????????????????????????????????
    private static final String[] ALL_TEST_IDS = new String[20];
    static {
        for (int i = 1; i <= 20; i++)
            ALL_TEST_IDS[i-1] = String.format("99990003-0000-0000-0000-%012d", i);
    }

    @BeforeAll
    static void cleanStaleTestData() {
        for (String id : ALL_TEST_IDS) try { dao.delete(id); } catch (Exception ignored) {}
    }

    // ?? Helper factory ????????????????????????????????????????????????????????

    private Claim make(String id, String ref, String polId, String custId, String typeId) {
        Claim c = new Claim();
        c.setId(id);
        c.setClaimReference(ref);
        c.setPolicyId(polId);
        c.setCustomerId(custId);
        c.setClaimTypeId(typeId);
        c.setStatus("SUBMITTED");
        c.setIncidentDate(LocalDate.of(2026, 6, 15));
        c.setIncidentDescription("Integration test claim incident description");
        c.setClaimedAmount(new BigDecimal("5000.00"));
        c.setHighValue(false);
        c.setFieldInvestigationRequired(false);
        c.setCreatedAt(OffsetDateTime.now());
        c.setUpdatedAt(OffsetDateTime.now());
        c.setVersion(1L);
        return c;
    }

    // ?? findAll ???????????????????????????????????????????????????????????????

    @Test @Order(1)
    @DisplayName("findAll: returns at least 2 seed claims, mandatory fields non-null")
    void findAll_atLeastTwoClaims() {
        List<Claim> list = dao.findAll();
        assertTrue(list.size() >= 2);
        list.forEach(c -> {
            assertNotNull(c.getId());
            assertNotNull(c.getClaimReference());
            assertNotNull(c.getStatus());
            assertNotNull(c.getClaimedAmount());
        });
    }

    // ?? findById ??????????????????????????????????????????????????????????????

    @Test @Order(2)
    @DisplayName("findById: seed claim CLM-2026-000001 - immutable fields correct")
    void findById_seedClaim1_immutable() {
        Claim c = dao.findById("ba000000-0000-0000-0000-000000000001");
        assertNotNull(c);
        assertEquals("CLM-2026-000001", c.getClaimReference());
        assertEquals(SEED_POLICY_1,     c.getPolicyId());
        assertEquals(SEED_CUSTOMER_1,   c.getCustomerId());
        assertEquals(SEED_TYPE_MED,     c.getClaimTypeId());
        // Do NOT assert status - it may have been modified by prior test runs
        assertTrue(c.getClaimedAmount().compareTo(BigDecimal.ZERO) > 0);
    }

    @Test @Order(3)
    @DisplayName("findById: seed claim CLM-2026-000002 exists and has valid fields")
    void findById_seedClaim2_exists() {
        Claim c = dao.findById("ba000000-0000-0000-0000-000000000002");
        assertNotNull(c);
        assertEquals("CLM-2026-000002", c.getClaimReference());
        assertEquals(SEED_POLICY_2,     c.getPolicyId());
        assertEquals(SEED_CUSTOMER_2,   c.getCustomerId());
        // Do NOT assert status here - it is mutable
        assertNotNull(c.getClaimTypeId());
        assertTrue(c.getClaimedAmount().compareTo(BigDecimal.ZERO) > 0);
    }

    @Test @Order(4)
    @DisplayName("findById: non-existent ID returns null")
    void findById_nonExistent_null() {
        assertNull(dao.findById("00000000-0000-0000-0000-000000000000"));
    }

    // ?? findByClaimReference ??????????????????????????????????????????????????

    @Test @Order(5)
    @DisplayName("findByClaimReference: CLM-2026-000001 found")
    void findByClaimReference_seed001() {
        Claim c = dao.findByClaimReference("CLM-2026-000001");
        assertNotNull(c);
        assertEquals("ba000000-0000-0000-0000-000000000001", c.getId());
    }

    @Test @Order(6)
    @DisplayName("findByClaimReference: non-existent returns null")
    void findByClaimReference_nonExistent_null() {
        assertNull(dao.findByClaimReference("CLM-DOES-NOT-EXIST-999"));
    }

    // ?? findByPolicyId ????????????????????????????????????????????????????????

    @Test @Order(7)
    @DisplayName("findByPolicyId: seed policy 1 has at least 1 claim")
    void findByPolicyId_seedPolicy1() {
        List<Claim> list = dao.findByPolicyId(SEED_POLICY_1);
        assertFalse(list.isEmpty());
        list.forEach(c -> assertEquals(SEED_POLICY_1, c.getPolicyId()));
    }

    @Test @Order(8)
    @DisplayName("findByPolicyId: unknown policy returns empty list")
    void findByPolicyId_unknown_empty() {
        assertTrue(dao.findByPolicyId("00000000-0000-0000-0000-000000000000").isEmpty());
    }

    // ?? findByCustomerId ??????????????????????????????????????????????????????

    @Test @Order(9)
    @DisplayName("findByCustomerId: Shankar has at least 1 claim")
    void findByCustomerId_shankar_notEmpty() {
        List<Claim> list = dao.findByCustomerId(SEED_CUSTOMER_1);
        assertFalse(list.isEmpty());
        list.forEach(c -> assertEquals(SEED_CUSTOMER_1, c.getCustomerId()));
    }

    @Test @Order(10)
    @DisplayName("findByCustomerId: unknown customer returns empty list")
    void findByCustomerId_unknown_empty() {
        assertTrue(dao.findByCustomerId("00000000-0000-0000-0000-000000000000").isEmpty());
    }

    // ?? findByStatus ??????????????????????????????????????????????????????????

    @Test @Order(11)
    @DisplayName("findByStatus: APPROVED only returns APPROVED claims")
    void findByStatus_approved_allApproved() {
        // Ensure at least one APPROVED claim exists by checking seed (CLM-2026-000001 is APPROVED)
        List<Claim> list = dao.findByStatus("APPROVED");
        assertFalse(list.isEmpty());
        list.forEach(c -> assertEquals("APPROVED", c.getStatus()));
    }

    @Test @Order(12)
    @DisplayName("findByStatus: test-owned SUBMITTED claim found")
    void findByStatus_submitted_foundOwnClaim() {
        String id = ALL_TEST_IDS[0];
        dao.save(make(id, "CLM-T-0001", SEED_POLICY_1, SEED_CUSTOMER_1, SEED_TYPE_MED));
        try {
            List<Claim> list = dao.findByStatus("SUBMITTED");
            assertFalse(list.isEmpty());
            assertTrue(list.stream().anyMatch(c -> c.getId().equals(id)));
            list.forEach(c -> assertEquals("SUBMITTED", c.getStatus()));
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(13)
    @DisplayName("findByStatus: unknown status returns empty list")
    void findByStatus_unknown_empty() {
        assertTrue(dao.findByStatus("NOT_REAL_STATUS_XYZ").isEmpty());
    }

    // ?? save + findById round-trip ????????????????????????????????????????????

    @Test @Order(14)
    @DisplayName("save+findById: all fields persisted correctly")
    void save_allFieldsPersisted() {
        String id = ALL_TEST_IDS[1];
        Claim c = make(id, "CLM-T-0002", SEED_POLICY_1, SEED_CUSTOMER_1, SEED_TYPE_MED);
        dao.save(c);
        try {
            Claim found = dao.findById(id);
            assertNotNull(found);
            assertEquals("CLM-T-0002",   found.getClaimReference());
            assertEquals(SEED_POLICY_1,  found.getPolicyId());
            assertEquals(SEED_CUSTOMER_1, found.getCustomerId());
            assertEquals(SEED_TYPE_MED,  found.getClaimTypeId());
            assertEquals("SUBMITTED",    found.getStatus());
            assertEquals(0, new BigDecimal("5000.00").compareTo(found.getClaimedAmount()));
            assertNull(found.getApprovedAmount());
            assertNull(found.getAssignedOfficerId());
            assertNull(found.getDecidedBy());
            assertFalse(found.isHighValue());
            assertFalse(found.isFieldInvestigationRequired());
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(15)
    @DisplayName("save: duplicate ID throws RuntimeException")
    void save_duplicateId_throws() {
        String id = ALL_TEST_IDS[2];
        dao.save(make(id, "CLM-T-0003", SEED_POLICY_1, SEED_CUSTOMER_1, SEED_TYPE_MED));
        try {
            assertThrows(RuntimeException.class, () ->
                dao.save(make(id, "CLM-T-0003b", SEED_POLICY_1, SEED_CUSTOMER_1, SEED_TYPE_MED)));
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(16)
    @DisplayName("save: BAGGAGE type claim persisted")
    void save_baggageType() {
        String id = ALL_TEST_IDS[3];
        Claim c = make(id, "CLM-T-0004", SEED_POLICY_2, SEED_CUSTOMER_2, SEED_TYPE_BAG);
        dao.save(c);
        try {
            assertEquals(SEED_TYPE_BAG, dao.findById(id).getClaimTypeId());
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(17)
    @DisplayName("save: isHighValue=true persisted correctly")
    void save_highValue_true() {
        String id = ALL_TEST_IDS[4];
        Claim c = make(id, "CLM-T-0005", SEED_POLICY_1, SEED_CUSTOMER_1, SEED_TYPE_MED);
        c.setHighValue(true);
        c.setClaimedAmount(new BigDecimal("500000.00"));
        dao.save(c);
        try {
            Claim found = dao.findById(id);
            assertTrue(found.isHighValue());
            assertEquals(0, new BigDecimal("500000.00").compareTo(found.getClaimedAmount()));
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(18)
    @DisplayName("save: minimum amount 0.01 persisted")
    void save_minimumAmount() {
        String id = ALL_TEST_IDS[5];
        Claim c = make(id, "CLM-T-0006", SEED_POLICY_1, SEED_CUSTOMER_1, SEED_TYPE_MED);
        c.setClaimedAmount(new BigDecimal("0.01"));
        assertDoesNotThrow(() -> dao.save(c));
        try {
            assertEquals(0, new BigDecimal("0.01").compareTo(dao.findById(id).getClaimedAmount()));
        } finally {
            dao.delete(id);
        }
    }

    // ?? update ????????????????????????????????????????????????????????????????

    @Test @Order(19)
    @DisplayName("update: SUBMITTED -> IN_REVIEW with assignedOfficerId and fieldInvestigation=true")
    void update_inReviewWithOfficer() {
        String id = ALL_TEST_IDS[6];
        Claim c = make(id, "CLM-T-0007", SEED_POLICY_1, SEED_CUSTOMER_1, SEED_TYPE_MED);
        dao.save(c);
        try {
            c.setStatus("IN_REVIEW");
            c.setAssignedOfficerId(SEED_FIELD_OFF);
            c.setFieldInvestigationRequired(true);
            dao.update(c);
            Claim updated = dao.findById(id);
            assertEquals("IN_REVIEW",    updated.getStatus());
            assertEquals(SEED_FIELD_OFF, updated.getAssignedOfficerId());
            assertTrue(updated.isFieldInvestigationRequired());
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(20)
    @DisplayName("update: IN_REVIEW -> FIELD_APPROVED")
    void update_fieldApproved() {
        String id = ALL_TEST_IDS[7];
        Claim c = make(id, "CLM-T-0008", SEED_POLICY_1, SEED_CUSTOMER_1, SEED_TYPE_MED);
        c.setStatus("IN_REVIEW");
        c.setAssignedOfficerId(SEED_FIELD_OFF);
        c.setFieldInvestigationRequired(true);
        dao.save(c);
        try {
            c.setStatus("FIELD_APPROVED");
            dao.update(c);
            assertEquals("FIELD_APPROVED", dao.findById(id).getStatus());
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(21)
    @DisplayName("update: APPROVED with approvedAmount, decidedBy, decisionReason, decidedAt")
    void update_approved_allDecisionFields() {
        String id = ALL_TEST_IDS[8];
        Claim c = make(id, "CLM-T-0009", SEED_POLICY_1, SEED_CUSTOMER_1, SEED_TYPE_MED);
        dao.save(c);
        try {
            c.setStatus("APPROVED");
            c.setApprovedAmount(new BigDecimal("4500.00"));
            c.setDecidedBy(SEED_OFFICER);
            c.setDecisionReason("All documents verified and claim is valid");
            c.setDecidedAt(OffsetDateTime.now());
            dao.update(c);
            Claim updated = dao.findById(id);
            assertEquals("APPROVED",     updated.getStatus());
            assertEquals(0, new BigDecimal("4500.00").compareTo(updated.getApprovedAmount()));
            assertEquals(SEED_OFFICER,   updated.getDecidedBy());
            assertNotNull(updated.getDecisionReason());
            assertNotNull(updated.getDecidedAt());
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(22)
    @DisplayName("update: REJECTED with reason persisted")
    void update_rejected_reasonPersisted() {
        String id = ALL_TEST_IDS[9];
        Claim c = make(id, "CLM-T-0010", SEED_POLICY_1, SEED_CUSTOMER_1, SEED_TYPE_BAG);
        dao.save(c);
        try {
            c.setStatus("REJECTED");
            c.setDecidedBy(SEED_OFFICER);
            c.setDecisionReason("Insufficient documentation provided by claimant");
            c.setDecidedAt(OffsetDateTime.now());
            dao.update(c);
            Claim updated = dao.findById(id);
            assertEquals("REJECTED",  updated.getStatus());
            assertEquals(SEED_OFFICER, updated.getDecidedBy());
            assertNotNull(updated.getDecisionReason());
        } finally {
            dao.delete(id);
        }
    }

    // ?? findByAssignedOfficerId ???????????????????????????????????????????????

    @Test @Order(23)
    @DisplayName("findByAssignedOfficerId: returns assigned claims for field officer")
    void findByAssignedOfficerId_fieldOfficer() {
        String id = ALL_TEST_IDS[10];
        Claim c = make(id, "CLM-T-0011", SEED_POLICY_1, SEED_CUSTOMER_1, SEED_TYPE_MED);
        c.setStatus("IN_REVIEW");
        c.setAssignedOfficerId(SEED_FIELD_OFF);
        c.setFieldInvestigationRequired(true);
        dao.save(c);
        try {
            List<Claim> list = dao.findByAssignedOfficerId(SEED_FIELD_OFF);
            assertFalse(list.isEmpty());
            assertTrue(list.stream().anyMatch(x -> x.getId().equals(id)));
            list.forEach(x -> assertEquals(SEED_FIELD_OFF, x.getAssignedOfficerId()));
        } finally {
            dao.delete(id);
        }
    }

    @Test @Order(24)
    @DisplayName("findByAssignedOfficerId: unknown officer returns empty list")
    void findByAssignedOfficerId_unknown_empty() {
        assertTrue(dao.findByAssignedOfficerId("00000000-0000-0000-0000-000000000000").isEmpty());
    }

    // ?? second customer / second policy ??????????????????????????????????????

    @Test @Order(25)
    @DisplayName("save: second customer's claim on second policy persisted")
    void save_secondCustomerClaim() {
        String id = ALL_TEST_IDS[11];
        Claim c = make(id, "CLM-T-0012", SEED_POLICY_2, SEED_CUSTOMER_2, SEED_TYPE_BAG);
        dao.save(c);
        try {
            Claim found = dao.findById(id);
            assertEquals(SEED_POLICY_2,   found.getPolicyId());
            assertEquals(SEED_CUSTOMER_2, found.getCustomerId());
            assertEquals(SEED_TYPE_BAG,   found.getClaimTypeId());
        } finally {
            dao.delete(id);
        }
    }

    @AfterAll
    static void finalCleanup() {
        for (String id : ALL_TEST_IDS) try { dao.delete(id); } catch (Exception ignored) {}
    }
}
