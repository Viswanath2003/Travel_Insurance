package com.insurance.dto;

public class UserDto {
    private String username;
    private String email;
    private String mobile;
    private String fullName;
    private String passwordHash;
    private String role;
    private int age;
    private boolean isDefaultPassword;

    public UserDto() {}

    public UserDto(String username, String email, String mobile, String fullName,
                   String passwordHash, String role) {
        this(username, email, mobile, fullName, passwordHash, role, 0, false);
    }

    public UserDto(String username, String email, String mobile, String fullName,
                   String passwordHash, String role, int age) {
        this(username, email, mobile, fullName, passwordHash, role, age, false);
    }

    public UserDto(String username, String email, String mobile, String fullName,
                   String passwordHash, String role, int age, boolean isDefaultPassword) {
        this.username = username;
        this.email = email;
        this.mobile = mobile;
        this.fullName = fullName;
        this.passwordHash = passwordHash;
        this.role = role;
        this.age = age;
        this.isDefaultPassword = isDefaultPassword;
    }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public boolean isDefaultPassword() { return isDefaultPassword; }
    public void setDefaultPassword(boolean defaultPassword) { isDefaultPassword = defaultPassword; }
}
