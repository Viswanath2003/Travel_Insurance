package com.insurance.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ClaimDto {
    private String policyId;
    private String customerId;
    private String claimTypeId;
    private LocalDate incidentDate;
    private String incidentDescription;
    private BigDecimal claimedAmount;

    public ClaimDto() {}

    public ClaimDto(String policyId, String customerId, String claimTypeId,
                    LocalDate incidentDate, String incidentDescription, BigDecimal claimedAmount) {
        this.policyId = policyId;
        this.customerId = customerId;
        this.claimTypeId = claimTypeId;
        this.incidentDate = incidentDate;
        this.incidentDescription = incidentDescription;
        this.claimedAmount = claimedAmount;
    }

    public String getPolicyId() { return policyId; }
    public void setPolicyId(String policyId) { this.policyId = policyId; }
    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }
    public String getClaimTypeId() { return claimTypeId; }
    public void setClaimTypeId(String claimTypeId) { this.claimTypeId = claimTypeId; }
    public LocalDate getIncidentDate() { return incidentDate; }
    public void setIncidentDate(LocalDate incidentDate) { this.incidentDate = incidentDate; }
    public String getIncidentDescription() { return incidentDescription; }
    public void setIncidentDescription(String incidentDescription) { this.incidentDescription = incidentDescription; }
    public BigDecimal getClaimedAmount() { return claimedAmount; }
    public void setClaimedAmount(BigDecimal claimedAmount) { this.claimedAmount = claimedAmount; }
}
