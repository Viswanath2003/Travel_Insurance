package com.insurance.dto;

import java.math.BigDecimal;

public class PaymentDto {

    private String policyId;
    private BigDecimal amount;
    private String currency;

    public PaymentDto() {}

    public PaymentDto(String policyId, BigDecimal amount, String currency) {
        this.policyId = policyId;
        this.amount = amount;
        this.currency = currency;
    }

    public String getPolicyId() { return policyId; }
    public void setPolicyId(String policyId) { this.policyId = policyId; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
}
