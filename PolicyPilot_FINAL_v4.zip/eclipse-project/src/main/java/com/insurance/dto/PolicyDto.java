package com.insurance.dto;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PolicyDto {

    private String customerId;
    private String planId;
    private String destinationCountryCode;
    private LocalDate tripStartDate;
    private LocalDate tripEndDate;
    private int numTravelers;
    private List<Integer> travelerAges;   // age of each traveler
    private String tripPurpose;
    private String currency;
    private List<String> addonIds;

    public PolicyDto() {
        this.addonIds = new ArrayList<>();
        this.travelerAges = new ArrayList<>();
    }

    public PolicyDto(String customerId, String planId, String destinationCountryCode,
                     LocalDate tripStartDate, LocalDate tripEndDate, int numTravelers,
                     String tripPurpose, String currency, List<String> addonIds) {
        this.customerId = customerId;
        this.planId = planId;
        this.destinationCountryCode = destinationCountryCode;
        this.tripStartDate = tripStartDate;
        this.tripEndDate = tripEndDate;
        this.numTravelers = numTravelers;
        this.travelerAges = new ArrayList<>();
        this.tripPurpose = tripPurpose;
        this.currency = currency;
        this.addonIds = addonIds != null ? addonIds : new ArrayList<>();
    }

    public PolicyDto(String customerId, String planId, String destinationCountryCode,
                     LocalDate tripStartDate, LocalDate tripEndDate, int numTravelers,
                     List<Integer> travelerAges, String tripPurpose, String currency,
                     List<String> addonIds) {
        this.customerId = customerId;
        this.planId = planId;
        this.destinationCountryCode = destinationCountryCode;
        this.tripStartDate = tripStartDate;
        this.tripEndDate = tripEndDate;
        this.numTravelers = numTravelers;
        this.travelerAges = travelerAges != null ? travelerAges : new ArrayList<>();
        this.tripPurpose = tripPurpose;
        this.currency = currency;
        this.addonIds = addonIds != null ? addonIds : new ArrayList<>();
    }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public String getPlanId() { return planId; }
    public void setPlanId(String planId) { this.planId = planId; }

    public String getDestinationCountryCode() { return destinationCountryCode; }
    public void setDestinationCountryCode(String d) { this.destinationCountryCode = d; }

    public LocalDate getTripStartDate() { return tripStartDate; }
    public void setTripStartDate(LocalDate tripStartDate) { this.tripStartDate = tripStartDate; }

    public LocalDate getTripEndDate() { return tripEndDate; }
    public void setTripEndDate(LocalDate tripEndDate) { this.tripEndDate = tripEndDate; }

    public int getNumTravelers() { return numTravelers; }
    public void setNumTravelers(int numTravelers) { this.numTravelers = numTravelers; }

    public List<Integer> getTravelerAges() { return travelerAges; }
    public void setTravelerAges(List<Integer> travelerAges) { this.travelerAges = travelerAges; }

    public String getTripPurpose() { return tripPurpose; }
    public void setTripPurpose(String tripPurpose) { this.tripPurpose = tripPurpose; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public List<String> getAddonIds() { return addonIds; }
    public void setAddonIds(List<String> addonIds) { this.addonIds = addonIds; }
}
