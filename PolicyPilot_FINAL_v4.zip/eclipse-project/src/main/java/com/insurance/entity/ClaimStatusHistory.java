package com.insurance.entity;

import java.time.OffsetDateTime;

public class ClaimStatusHistory {

    private String id;
    private String claimId;
    private String status;
    private String changedBy;
    private OffsetDateTime changedAt;
    private String remarks;

    public ClaimStatusHistory() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getClaimId() { return claimId; }
    public void setClaimId(String claimId) { this.claimId = claimId; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getChangedBy() { return changedBy; }
    public void setChangedBy(String changedBy) { this.changedBy = changedBy; }

    public OffsetDateTime getChangedAt() { return changedAt; }
    public void setChangedAt(OffsetDateTime changedAt) { this.changedAt = changedAt; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    @Override
    public String toString() {
        return "ClaimStatusHistory{claimId=" + claimId + ", status=" + status +
               ", changedAt=" + changedAt + "}";
    }
}
