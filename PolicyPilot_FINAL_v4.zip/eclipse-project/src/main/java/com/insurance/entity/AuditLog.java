package com.insurance.entity;

import java.time.OffsetDateTime;

public class AuditLog {

    private long id;
    private OffsetDateTime eventTime;
    private String requestId;
    private String serviceName;
    private String action;
    private String actorUserId;
    private String actorIp;
    private String entityName;
    private String entityId;
    private String entityReference;
    private String result;
    private String failureReason;

    public AuditLog() {}

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public OffsetDateTime getEventTime() { return eventTime; }
    public void setEventTime(OffsetDateTime eventTime) { this.eventTime = eventTime; }

    public String getRequestId() { return requestId; }
    public void setRequestId(String requestId) { this.requestId = requestId; }

    public String getServiceName() { return serviceName; }
    public void setServiceName(String serviceName) { this.serviceName = serviceName; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getActorUserId() { return actorUserId; }
    public void setActorUserId(String actorUserId) { this.actorUserId = actorUserId; }

    public String getActorIp() { return actorIp; }
    public void setActorIp(String actorIp) { this.actorIp = actorIp; }

    public String getEntityName() { return entityName; }
    public void setEntityName(String entityName) { this.entityName = entityName; }

    public String getEntityId() { return entityId; }
    public void setEntityId(String entityId) { this.entityId = entityId; }

    public String getEntityReference() { return entityReference; }
    public void setEntityReference(String entityReference) { this.entityReference = entityReference; }

    public String getResult() { return result; }
    public void setResult(String result) { this.result = result; }

    public String getFailureReason() { return failureReason; }
    public void setFailureReason(String failureReason) { this.failureReason = failureReason; }

    @Override
    public String toString() {
        return "AuditLog{id=" + id + ", action=" + action + ", entity=" + entityName +
               ", result=" + result + ", time=" + eventTime + "}";
    }
}
