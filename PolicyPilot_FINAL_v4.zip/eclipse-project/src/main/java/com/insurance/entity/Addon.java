package com.insurance.entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

public class Addon {

    private String id;
    private String addonCode;
    private String addonName;
    private String addonCategory;
    private String description;
    private String pricingType;
    private BigDecimal pricingValue;
    private String currency;
    private boolean isActive;
    private int sortOrder;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;

    public Addon() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getAddonCode() { return addonCode; }
    public void setAddonCode(String addonCode) { this.addonCode = addonCode; }

    public String getAddonName() { return addonName; }
    public void setAddonName(String addonName) { this.addonName = addonName; }

    public String getAddonCategory() { return addonCategory; }
    public void setAddonCategory(String addonCategory) { this.addonCategory = addonCategory; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getPricingType() { return pricingType; }
    public void setPricingType(String pricingType) { this.pricingType = pricingType; }

    public BigDecimal getPricingValue() { return pricingValue; }
    public void setPricingValue(BigDecimal pricingValue) { this.pricingValue = pricingValue; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public int getSortOrder() { return sortOrder; }
    public void setSortOrder(int sortOrder) { this.sortOrder = sortOrder; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime updatedAt) { this.updatedAt = updatedAt; }

    @Override
    public String toString() {
        return "Addon{code=" + addonCode + ", name=" + addonName +
               ", pricingType=" + pricingType + ", value=" + pricingValue + " " + currency + "}";
    }
}
