package com.insurance.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

public class Claim {
    private String id;
    private String claimReference;
    private String policyId;
    private String customerId;
    private String claimTypeId;
    private String status;
    private LocalDate incidentDate;
    private String incidentDescription;
    private BigDecimal claimedAmount;
    private BigDecimal approvedAmount;
    private String assignedOfficerId;
    private String decidedBy;
    private String decisionReason;
    private OffsetDateTime decidedAt;
    private boolean isHighValue;
    private boolean fieldInvestigationRequired;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;
    private long version;

    public Claim() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getClaimReference() { return claimReference; }
    public void setClaimReference(String v) { this.claimReference = v; }
    public String getPolicyId() { return policyId; }
    public void setPolicyId(String v) { this.policyId = v; }
    public String getCustomerId() { return customerId; }
    public void setCustomerId(String v) { this.customerId = v; }
    public String getClaimTypeId() { return claimTypeId; }
    public void setClaimTypeId(String v) { this.claimTypeId = v; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDate getIncidentDate() { return incidentDate; }
    public void setIncidentDate(LocalDate v) { this.incidentDate = v; }
    public String getIncidentDescription() { return incidentDescription; }
    public void setIncidentDescription(String v) { this.incidentDescription = v; }
    public BigDecimal getClaimedAmount() { return claimedAmount; }
    public void setClaimedAmount(BigDecimal v) { this.claimedAmount = v; }
    public BigDecimal getApprovedAmount() { return approvedAmount; }
    public void setApprovedAmount(BigDecimal v) { this.approvedAmount = v; }
    public String getAssignedOfficerId() { return assignedOfficerId; }
    public void setAssignedOfficerId(String v) { this.assignedOfficerId = v; }
    public String getDecidedBy() { return decidedBy; }
    public void setDecidedBy(String v) { this.decidedBy = v; }
    public String getDecisionReason() { return decisionReason; }
    public void setDecisionReason(String v) { this.decisionReason = v; }
    public OffsetDateTime getDecidedAt() { return decidedAt; }
    public void setDecidedAt(OffsetDateTime v) { this.decidedAt = v; }
    public boolean isHighValue() { return isHighValue; }
    public void setHighValue(boolean v) { isHighValue = v; }
    public boolean isFieldInvestigationRequired() { return fieldInvestigationRequired; }
    public void setFieldInvestigationRequired(boolean v) { this.fieldInvestigationRequired = v; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime v) { this.createdAt = v; }
    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime v) { this.updatedAt = v; }
    public long getVersion() { return version; }
    public void setVersion(long v) { this.version = v; }

    @Override
    public String toString() {
        return "Claim{ref=" + claimReference + ", status=" + status +
               ", claimedAmount=" + claimedAmount + ", approvedAmount=" + approvedAmount + "}";
    }
}
