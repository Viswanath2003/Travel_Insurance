package com.insurance.entity;

import java.time.OffsetDateTime;

public class Notification {

    private String id;
    private String notificationRef;
    private String userId;
    private String title;
    private String message;
    private String notificationType;
    private String priority;
    private boolean isRead;
    private OffsetDateTime readAt;
    private String deliveryChannel;
    private String deliveryStatus;
    private OffsetDateTime createdAt;

    public Notification() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getNotificationRef() { return notificationRef; }
    public void setNotificationRef(String notificationRef) { this.notificationRef = notificationRef; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getNotificationType() { return notificationType; }
    public void setNotificationType(String notificationType) { this.notificationType = notificationType; }

    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }

    public boolean isRead() { return isRead; }
    public void setRead(boolean read) { isRead = read; }

    public OffsetDateTime getReadAt() { return readAt; }
    public void setReadAt(OffsetDateTime readAt) { this.readAt = readAt; }

    public String getDeliveryChannel() { return deliveryChannel; }
    public void setDeliveryChannel(String deliveryChannel) { this.deliveryChannel = deliveryChannel; }

    public String getDeliveryStatus() { return deliveryStatus; }
    public void setDeliveryStatus(String deliveryStatus) { this.deliveryStatus = deliveryStatus; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return "Notification{ref=" + notificationRef + ", userId=" + userId +
               ", title=" + title + ", read=" + isRead + "}";
    }
}
