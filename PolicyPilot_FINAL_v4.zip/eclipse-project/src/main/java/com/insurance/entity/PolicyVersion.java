package com.insurance.entity;

import java.time.OffsetDateTime;

public class PolicyVersion {

    private String id;
    private String policyId;
    private int versionNumber;
    private String dataSnapshot;
    private OffsetDateTime createdAt;

    public PolicyVersion() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPolicyId() { return policyId; }
    public void setPolicyId(String policyId) { this.policyId = policyId; }

    public int getVersionNumber() { return versionNumber; }
    public void setVersionNumber(int versionNumber) { this.versionNumber = versionNumber; }

    public String getDataSnapshot() { return dataSnapshot; }
    public void setDataSnapshot(String dataSnapshot) { this.dataSnapshot = dataSnapshot; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return "PolicyVersion{policyId=" + policyId + ", version=" + versionNumber + "}";
    }
}
