package com.insurance.entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

public class Plan {

    private String id;
    private String planCode;
    private String planName;
    private String productId;
    private BigDecimal basePremium;
    private BigDecimal dailyRate;
    private String currency;
    private int minTripDays;
    private int maxTripDays;
    private int minTravelerAge;
    private int maxTravelerAge;
    private int maxTravelers;
    private String status;
    private int version;
    private OffsetDateTime publishedAt;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;

    public Plan() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPlanCode() { return planCode; }
    public void setPlanCode(String planCode) { this.planCode = planCode; }

    public String getPlanName() { return planName; }
    public void setPlanName(String planName) { this.planName = planName; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public BigDecimal getBasePremium() { return basePremium; }
    public void setBasePremium(BigDecimal basePremium) { this.basePremium = basePremium; }

    public BigDecimal getDailyRate() { return dailyRate; }
    public void setDailyRate(BigDecimal dailyRate) { this.dailyRate = dailyRate; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public int getMinTripDays() { return minTripDays; }
    public void setMinTripDays(int minTripDays) { this.minTripDays = minTripDays; }

    public int getMaxTripDays() { return maxTripDays; }
    public void setMaxTripDays(int maxTripDays) { this.maxTripDays = maxTripDays; }

    public int getMinTravelerAge() { return minTravelerAge; }
    public void setMinTravelerAge(int minTravelerAge) { this.minTravelerAge = minTravelerAge; }

    public int getMaxTravelerAge() { return maxTravelerAge; }
    public void setMaxTravelerAge(int maxTravelerAge) { this.maxTravelerAge = maxTravelerAge; }

    public int getMaxTravelers() { return maxTravelers; }
    public void setMaxTravelers(int maxTravelers) { this.maxTravelers = maxTravelers; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public int getVersion() { return version; }
    public void setVersion(int version) { this.version = version; }

    public OffsetDateTime getPublishedAt() { return publishedAt; }
    public void setPublishedAt(OffsetDateTime publishedAt) { this.publishedAt = publishedAt; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime updatedAt) { this.updatedAt = updatedAt; }

    @Override
    public String toString() {
        return "Plan{code=" + planCode + ", name=" + planName + ", basePremium=" + basePremium +
               " " + currency + ", status=" + status + "}";
    }
}
