package com.insurance.entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

public class UnderwritingCase {

    private String id;
    private String caseReference;
    private String policyId;
    private String customerId;
    private BigDecimal riskScore;
    private String riskLevel;
    private int uwLevel;
    private String currentState;
    private String assignedToUserId;
    private String assignedByUserId;
    private OffsetDateTime assignedAt;
    private int slaHours;
    private OffsetDateTime slaDueAt;
    private boolean slaBreached;
    private boolean isLocked;
    private String lockedBy;
    private OffsetDateTime lockedAt;
    private BigDecimal premiumLoadingPercent;
    private BigDecimal finalPremium;
    private boolean isActive;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;
    private long version;

    public UnderwritingCase() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getCaseReference() { return caseReference; }
    public void setCaseReference(String caseReference) { this.caseReference = caseReference; }

    public String getPolicyId() { return policyId; }
    public void setPolicyId(String policyId) { this.policyId = policyId; }

    public String getCustomerId() { return customerId; }
    public void setCustomerId(String customerId) { this.customerId = customerId; }

    public BigDecimal getRiskScore() { return riskScore; }
    public void setRiskScore(BigDecimal riskScore) { this.riskScore = riskScore; }

    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }

    public int getUwLevel() { return uwLevel; }
    public void setUwLevel(int uwLevel) { this.uwLevel = uwLevel; }

    public String getCurrentState() { return currentState; }
    public void setCurrentState(String currentState) { this.currentState = currentState; }

    public String getAssignedToUserId() { return assignedToUserId; }
    public void setAssignedToUserId(String assignedToUserId) { this.assignedToUserId = assignedToUserId; }

    public String getAssignedByUserId() { return assignedByUserId; }
    public void setAssignedByUserId(String assignedByUserId) { this.assignedByUserId = assignedByUserId; }

    public OffsetDateTime getAssignedAt() { return assignedAt; }
    public void setAssignedAt(OffsetDateTime assignedAt) { this.assignedAt = assignedAt; }

    public int getSlaHours() { return slaHours; }
    public void setSlaHours(int slaHours) { this.slaHours = slaHours; }

    public OffsetDateTime getSlaDueAt() { return slaDueAt; }
    public void setSlaDueAt(OffsetDateTime slaDueAt) { this.slaDueAt = slaDueAt; }

    public boolean isSlaBreached() { return slaBreached; }
    public void setSlaBreached(boolean slaBreached) { this.slaBreached = slaBreached; }

    public boolean isLocked() { return isLocked; }
    public void setLocked(boolean locked) { isLocked = locked; }

    public String getLockedBy() { return lockedBy; }
    public void setLockedBy(String lockedBy) { this.lockedBy = lockedBy; }

    public OffsetDateTime getLockedAt() { return lockedAt; }
    public void setLockedAt(OffsetDateTime lockedAt) { this.lockedAt = lockedAt; }

    public BigDecimal getPremiumLoadingPercent() { return premiumLoadingPercent; }
    public void setPremiumLoadingPercent(BigDecimal premiumLoadingPercent) { this.premiumLoadingPercent = premiumLoadingPercent; }

    public BigDecimal getFinalPremium() { return finalPremium; }
    public void setFinalPremium(BigDecimal finalPremium) { this.finalPremium = finalPremium; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime updatedAt) { this.updatedAt = updatedAt; }

    public long getVersion() { return version; }
    public void setVersion(long version) { this.version = version; }

    @Override
    public String toString() {
        return "UnderwritingCase{ref=" + caseReference + ", policyId=" + policyId +
               ", riskLevel=" + riskLevel + ", state=" + currentState + "}";
    }
}
