package com.insurance.entity;

import java.time.OffsetDateTime;

public class PlanAddonMapping {

    private String id;
    private String planId;
    private String addonId;
    private boolean isActive;
    private OffsetDateTime createdAt;

    public PlanAddonMapping() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPlanId() { return planId; }
    public void setPlanId(String planId) { this.planId = planId; }

    public String getAddonId() { return addonId; }
    public void setAddonId(String addonId) { this.addonId = addonId; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return "PlanAddonMapping{planId=" + planId + ", addonId=" + addonId + ", active=" + isActive + "}";
    }
}
