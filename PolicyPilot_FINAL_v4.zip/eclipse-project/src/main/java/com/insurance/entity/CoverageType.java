package com.insurance.entity;

import java.time.OffsetDateTime;

public class CoverageType {

    private String id;
    private String coverageCode;
    private String coverageName;
    private String coverageCategory;
    private String description;
    private boolean isActive;
    private int sortOrder;
    private OffsetDateTime createdAt;

    public CoverageType() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getCoverageCode() { return coverageCode; }
    public void setCoverageCode(String coverageCode) { this.coverageCode = coverageCode; }

    public String getCoverageName() { return coverageName; }
    public void setCoverageName(String coverageName) { this.coverageName = coverageName; }

    public String getCoverageCategory() { return coverageCategory; }
    public void setCoverageCategory(String coverageCategory) { this.coverageCategory = coverageCategory; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public int getSortOrder() { return sortOrder; }
    public void setSortOrder(int sortOrder) { this.sortOrder = sortOrder; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return "CoverageType{code=" + coverageCode + ", name=" + coverageName +
               ", category=" + coverageCategory + ", active=" + isActive + "}";
    }
}
