package com.insurance.entity;

import java.time.OffsetDateTime;

public class ClaimType {
    private String id;
    private String code;
    private String name;
    private String description;
    private String coverageTypeId;   // links claim type to a coverage type (null for addon claims)
    private int defaultSlaHours;
    private boolean isActive;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;

    public ClaimType() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getCoverageTypeId() { return coverageTypeId; }
    public void setCoverageTypeId(String coverageTypeId) { this.coverageTypeId = coverageTypeId; }
    public int getDefaultSlaHours() { return defaultSlaHours; }
    public void setDefaultSlaHours(int v) { this.defaultSlaHours = v; }
    public boolean isActive() { return isActive; }
    public void setActive(boolean v) { this.isActive = v; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime v) { this.createdAt = v; }
    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime v) { this.updatedAt = v; }
}
