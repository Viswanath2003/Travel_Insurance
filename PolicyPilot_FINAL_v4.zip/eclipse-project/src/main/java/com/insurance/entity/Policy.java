package com.insurance.entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

public class Policy {
    private String id;
    private String policyNumber;
    private String quoteId;
    private String customerId;
    private String productId;
    private String planId;
    private String destinationCountryCode;
    private String destinationZoneId;
    private LocalDate tripStartDate;
    private LocalDate tripEndDate;
    private int numTravelers;
    private String tripPurpose;
    private BigDecimal totalPremium;
    private String currency;
    private BigDecimal riskScore;
    private String riskLevel;
    private String status;
    private OffsetDateTime issueDate;
    private LocalDate expiryDate;
    private String parentPolicyId;
    private int renewalCount;
    private String cancellationReason;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;
    private long version;

    public Policy() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getPolicyNumber() { return policyNumber; }
    public void setPolicyNumber(String v) { this.policyNumber = v; }
    public String getQuoteId() { return quoteId; }
    public void setQuoteId(String v) { this.quoteId = v; }
    public String getCustomerId() { return customerId; }
    public void setCustomerId(String v) { this.customerId = v; }
    public String getProductId() { return productId; }
    public void setProductId(String v) { this.productId = v; }
    public String getPlanId() { return planId; }
    public void setPlanId(String v) { this.planId = v; }
    public String getDestinationCountryCode() { return destinationCountryCode; }
    public void setDestinationCountryCode(String v) { this.destinationCountryCode = v; }
    public String getDestinationZoneId() { return destinationZoneId; }
    public void setDestinationZoneId(String v) { this.destinationZoneId = v; }
    public LocalDate getTripStartDate() { return tripStartDate; }
    public void setTripStartDate(LocalDate v) { this.tripStartDate = v; }
    public LocalDate getTripEndDate() { return tripEndDate; }
    public void setTripEndDate(LocalDate v) { this.tripEndDate = v; }
    public int getNumTravelers() { return numTravelers; }
    public void setNumTravelers(int v) { this.numTravelers = v; }
    public String getTripPurpose() { return tripPurpose; }
    public void setTripPurpose(String v) { this.tripPurpose = v; }
    public BigDecimal getTotalPremium() { return totalPremium; }
    public void setTotalPremium(BigDecimal v) { this.totalPremium = v; }
    public String getCurrency() { return currency; }
    public void setCurrency(String v) { this.currency = v; }
    public BigDecimal getRiskScore() { return riskScore; }
    public void setRiskScore(BigDecimal v) { this.riskScore = v; }
    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String v) { this.riskLevel = v; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public OffsetDateTime getIssueDate() { return issueDate; }
    public void setIssueDate(OffsetDateTime v) { this.issueDate = v; }
    public LocalDate getExpiryDate() { return expiryDate; }
    public void setExpiryDate(LocalDate v) { this.expiryDate = v; }
    public String getParentPolicyId() { return parentPolicyId; }
    public void setParentPolicyId(String v) { this.parentPolicyId = v; }
    public int getRenewalCount() { return renewalCount; }
    public void setRenewalCount(int v) { this.renewalCount = v; }
    public String getCancellationReason() { return cancellationReason; }
    public void setCancellationReason(String v) { this.cancellationReason = v; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime v) { this.createdAt = v; }
    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime v) { this.updatedAt = v; }
    public long getVersion() { return version; }
    public void setVersion(long v) { this.version = v; }
}
