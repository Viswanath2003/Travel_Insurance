package com.insurance.entity;

import java.math.BigDecimal;

public class PlanCoverage {

    private String id;
    private String planId;
    private String coverageTypeId;
    private BigDecimal minLimit;
    private BigDecimal maxLimit;
    private BigDecimal defaultLimit;
    private BigDecimal limitStep;
    private String currency;
    private BigDecimal deductible;
    private boolean isMandatory;
    private boolean isAdjustable;
    private boolean isActive;

    public PlanCoverage() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPlanId() { return planId; }
    public void setPlanId(String planId) { this.planId = planId; }

    public String getCoverageTypeId() { return coverageTypeId; }
    public void setCoverageTypeId(String coverageTypeId) { this.coverageTypeId = coverageTypeId; }

    public BigDecimal getMinLimit() { return minLimit; }
    public void setMinLimit(BigDecimal minLimit) { this.minLimit = minLimit; }

    public BigDecimal getMaxLimit() { return maxLimit; }
    public void setMaxLimit(BigDecimal maxLimit) { this.maxLimit = maxLimit; }

    public BigDecimal getDefaultLimit() { return defaultLimit; }
    public void setDefaultLimit(BigDecimal defaultLimit) { this.defaultLimit = defaultLimit; }

    public BigDecimal getLimitStep() { return limitStep; }
    public void setLimitStep(BigDecimal limitStep) { this.limitStep = limitStep; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public BigDecimal getDeductible() { return deductible; }
    public void setDeductible(BigDecimal deductible) { this.deductible = deductible; }

    public boolean isMandatory() { return isMandatory; }
    public void setMandatory(boolean mandatory) { isMandatory = mandatory; }

    public boolean isAdjustable() { return isAdjustable; }
    public void setAdjustable(boolean adjustable) { isAdjustable = adjustable; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    @Override
    public String toString() {
        return "PlanCoverage{planId=" + planId + ", coverageTypeId=" + coverageTypeId +
               ", defaultLimit=" + defaultLimit + " " + currency + ", mandatory=" + isMandatory + "}";
    }
}
