package com.insurance.entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

public class Payment {

    private String id;
    private String policyId;
    private String claimId;           // null for PREMIUM_RECEIVED, set for CLAIM_PAYOUT
    private String paymentReference;
    private BigDecimal amount;
    private String currency;
    private String paymentType;       // PREMIUM_RECEIVED | CLAIM_PAYOUT
    private String status;
    private OffsetDateTime paidAt;
    private OffsetDateTime createdAt;

    public Payment() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPolicyId() { return policyId; }
    public void setPolicyId(String policyId) { this.policyId = policyId; }

    public String getClaimId() { return claimId; }
    public void setClaimId(String claimId) { this.claimId = claimId; }

    public String getPaymentReference() { return paymentReference; }
    public void setPaymentReference(String paymentReference) { this.paymentReference = paymentReference; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public String getPaymentType() { return paymentType; }
    public void setPaymentType(String paymentType) { this.paymentType = paymentType; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public OffsetDateTime getPaidAt() { return paidAt; }
    public void setPaidAt(OffsetDateTime paidAt) { this.paidAt = paidAt; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return "Payment{ref=" + paymentReference + ", type=" + paymentType +
               ", policyId=" + policyId + ", amount=" + amount + " " + currency +
               ", status=" + status + "}";
    }
}
