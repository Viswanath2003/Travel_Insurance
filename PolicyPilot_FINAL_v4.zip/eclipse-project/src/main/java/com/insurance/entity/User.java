package com.insurance.entity;

import java.time.OffsetDateTime;

public class User {
    private String id;
    private String username;
    private String email;
    private String mobile;
    private String fullName;
    private String passwordHash;
    private String role;
    private String status;
    private int age;
    private boolean isDefaultPassword;
    private int failedLoginAttempts;
    private OffsetDateTime lockedUntil;
    private OffsetDateTime lastLoginAt;
    private boolean emailVerified;
    private boolean mobileVerified;
    private String profilePhotoPath;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;
    private long version;

    public User() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public boolean isDefaultPassword() { return isDefaultPassword; }
    public void setDefaultPassword(boolean defaultPassword) { isDefaultPassword = defaultPassword; }
    public int getFailedLoginAttempts() { return failedLoginAttempts; }
    public void setFailedLoginAttempts(int v) { this.failedLoginAttempts = v; }
    public OffsetDateTime getLockedUntil() { return lockedUntil; }
    public void setLockedUntil(OffsetDateTime v) { this.lockedUntil = v; }
    public OffsetDateTime getLastLoginAt() { return lastLoginAt; }
    public void setLastLoginAt(OffsetDateTime v) { this.lastLoginAt = v; }
    public boolean isEmailVerified() { return emailVerified; }
    public void setEmailVerified(boolean v) { this.emailVerified = v; }
    public boolean isMobileVerified() { return mobileVerified; }
    public void setMobileVerified(boolean v) { this.mobileVerified = v; }
    public String getProfilePhotoPath() { return profilePhotoPath; }
    public void setProfilePhotoPath(String v) { this.profilePhotoPath = v; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime v) { this.createdAt = v; }
    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime v) { this.updatedAt = v; }
    public long getVersion() { return version; }
    public void setVersion(long version) { this.version = version; }

    @Override
    public String toString() {
        return "User{id=" + id + ", email=" + email + ", role=" + role + ", age=" + age + "}";
    }
}
