package com.insurance.ui;

import com.insurance.dao.AddonDao;
import com.insurance.dao.ClaimTypeDao;
import com.insurance.dao.PlanCoverageDao;
import com.insurance.dao.UserDao;
import com.insurance.dao.impl.AddonDaoImpl;
import com.insurance.dao.impl.ClaimTypeDaoImpl;
import com.insurance.dao.impl.PlanCoverageDaoImpl;
import com.insurance.dao.impl.UserDaoImpl;
import com.insurance.dto.ClaimDto;
import com.insurance.dto.PolicyDto;
import com.insurance.dto.UserDto;
import com.insurance.entity.*;
import com.insurance.service.*;
import com.insurance.service.impl.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class ConsoleUI {

    private static final String CURRENCY = "INR";

    private static final String[][] DESTINATIONS = {
        {"1","India (Domestic)","IN"},
        {"2","South / South-East Asia","SG"},
        {"3","Middle East / Africa","AE"},
        {"4","Europe","GB"},
        {"5","Australia / New Zealand","AU"},
        {"6","USA / Canada","US"},
        {"7","Worldwide","WW"},
    };

    private final Scanner         scanner        = new Scanner(System.in);
    private final UserService     userService    = new UserServiceImpl();
    private final PlanService     planService    = new PlanServiceImpl();
    private final PolicyService   policyService  = new PolicyServiceImpl();
    private final ClaimService    claimService   = new ClaimServiceImpl();
    private final PaymentService  paymentService = new PaymentServiceImpl();
    private final UserDao         userDao        = new UserDaoImpl();
    private final ClaimTypeDao    claimTypeDao   = new ClaimTypeDaoImpl();
    private final PlanCoverageDao coverageDao    = new PlanCoverageDaoImpl();
    private final AddonDao        addonDao       = new AddonDaoImpl();

    private User session = null;

    // =========================================================================
    // ENTRY POINT
    // =========================================================================
    public void run() {
        printBanner();
        boolean running = true;
        while (running) {
            if (session == null) {
                switch (showAuthMenu()) {
                    case 1 -> doLogin();
                    case 2 -> doRegister();
                    case 0 -> { running = false; print("\nThank you for using Policy Pilot. Goodbye!\n"); }
                }
            } else {
                dispatchRoleMenu();
            }
        }
    }

    private void printBanner() {
        print("+==========================================================+");
        print("|         POLICY PILOT - TRAVEL INSURANCE SYSTEM          |");
        print("+==========================================================+");
    }

    private int showAuthMenu() {
        print("\n+--- MAIN MENU -------------------------+");
        print("|  1. Login                             |");
        print("|  2. Register as Customer              |");
        print("|  0. Exit                              |");
        print("+---------------------------------------+");
        return readChoice(2);
    }

    // =========================================================================
    // AUTH
    // =========================================================================
    private void doLogin() {
        print("\n---- LOGIN ----");
        String email = readNonBlank("Email: ").trim().toLowerCase();
        if (!isValidEmail(email)) { print("Invalid email format."); return; }

        User user = userService.findByEmail(email);
        if (user == null) { print("No account found with email: " + email); return; }

        // Account status checks before asking password
        if ("SUSPENDED".equals(user.getStatus())) { print("Account suspended. Contact: support@policypilot.com"); return; }
        if ("LOCKED".equals(user.getStatus()))    { print("Account locked. Contact: support@policypilot.com"); return; }
        if ("INACTIVE".equals(user.getStatus()))  { print("Account inactive. Contact: support@policypilot.com"); return; }

        boolean isStaff = !"CUSTOMER".equals(user.getRole());
        if (isStaff && !email.endsWith("@policypilot.com")) { print("Staff must use @policypilot.com email."); return; }
        if (!isStaff && email.endsWith("@policypilot.com")) { print("Customers cannot use @policypilot.com domain."); return; }

        // Password loop - email is confirmed correct, only ask password
        // Enter 0 to go back to main menu
        int maxAttempts = 3;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            System.out.print("Password (0 to cancel): ");
            String password = scanner.nextLine().trim();
            if ("0".equals(password)) { print("Login cancelled."); return; }
            if (password.equals(user.getPasswordHash())) {
                // Check if this is a default password - force change before proceeding
                if (user.isDefaultPassword()) {
                    print("\n[!] You are using a default password. You must set a new password before logging in.");
                    print("  The default password 'Welcome@7205' cannot be kept.");
                    String newPwd = null;
                    while (true) {
                        System.out.print("  New Password (min 8 chars, uppercase, lowercase, digit, special): ");
                        String np = scanner.nextLine().trim();
                        if (np.equals("Welcome@7205")) {
                            print("  You cannot use the default password as your new password. Choose a different one.");
                            continue;
                        }
                        if (!isValidStaffPassword(np)) {
                            print("  Password too weak. Must be 8+ chars with uppercase, lowercase, digit and special char.");
                            continue;
                        }
                        System.out.print("  Confirm New Password: ");
                        String cp = scanner.nextLine().trim();
                        if (!np.equals(cp)) { print("  Passwords do not match. Try again."); continue; }
                        newPwd = np;
                        break;
                    }
                    user.setPasswordHash(newPwd);
                    user.setDefaultPassword(false);
                    userDao.update(user);
                    print("[OK] Password updated successfully!");
                }
                session = user;
                print("\n[OK] Welcome, " + safe(user.getFullName()) + "!  Role: " + user.getRole());
                return;
            }
            if (attempt < maxAttempts) {
                print("Incorrect password. " + (maxAttempts - attempt) + " attempt(s) remaining. Enter 0 to cancel.");
            } else {
                print("Incorrect password. Maximum attempts reached.");
            }
        }
    }

    private void doRegister() {
        print("\n---- CUSTOMER REGISTRATION ----");
        print("Note: @policypilot.com is reserved for staff only.");
        String fullName = readNonBlank("Full Name: ").trim();
        if (fullName.length() < 2 || !fullName.matches("[a-zA-Z .'\\-]+")) {
            print("Name must be 2+ characters, letters only."); return;
        }
        String email = readNonBlank("Email: ").trim().toLowerCase();
        if (!isValidEmail(email)) { print("Invalid email format."); return; }
        if (email.endsWith("@policypilot.com")) { print("Customers cannot use @policypilot.com domain."); return; }
        if (userService.findByEmail(email) != null) { print("Account already exists with this email."); return; }
        String username = readNonBlank("Username (letters, digits, underscores, 3-30 chars): ").trim();
        if (username.length() < 3 || username.length() > 30 || !username.matches("[a-zA-Z0-9_]+")) {
            print("Username must be 3-30 chars, letters/digits/underscores only."); return;
        }
        String mobile = readNonBlank("Mobile (e.g. +919876543210): ").trim();
        if (!mobile.matches("[0-9]{10}")) { print("Invalid mobile number. Enter exactly 10 digits (e.g. 9876543210)."); return; }
        String password = readNonBlank("Password (min 8 chars, 1 uppercase, 1 lowercase, 1 digit, 1 special): ").trim();
        if (!isValidStaffPassword(password)) { print("Password must be 8+ chars with uppercase, lowercase, digit and special character."); return; }
        if (!readNonBlank("Confirm Password: ").trim().equals(password)) { print("Passwords do not match."); return; }

        // Ask age
        int age = 0;
        while (true) {
            System.out.print("Your Age: ");
            try {
                age = Integer.parseInt(scanner.nextLine().trim());
                if (age < 18) { print("You must be at least 18 years old to register."); return; }
                if (age > 120) { print("Please enter a valid age."); continue; }
                break;
            } catch (NumberFormatException e) { print("Invalid age. Enter a number."); }
        }

        try {
            userService.registerUser(new UserDto(username, email, mobile, fullName, password, "CUSTOMER", age));
            print("[OK] Registration successful! You can now login.");
        } catch (Exception e) { print("Registration failed: " + e.getMessage()); }
    }

    // =========================================================================
    // ROLE DISPATCH
    // =========================================================================
    private void dispatchRoleMenu() {
        switch (session.getRole()) {
            case "CUSTOMER"        -> customerPortal();
            case "UW_OFFICER"      -> uwPortal();
            case "CLAIMS_OFFICER"  -> claimsOfficerPortal();
            case "AGENT"           -> agentPortal();
            case "FINANCE_OFFICER" -> financePortal();
            case "RM"              -> rmPortal();
            case "FIELD_OFFICER"   -> fieldOfficerPortal();
            case "IAM_ADMIN"       -> iamAdminPortal();
            default -> { print("Unknown role: " + session.getRole() + ". Logging out."); session = null; }
        }
    }

    // =========================================================================
    // CUSTOMER PORTAL
    // =========================================================================
    private void customerPortal() {
        boolean active = true;
        while (active) {
            print("\n+=== CUSTOMER PORTAL ===================================+");
            print("|  Name  : " + pad(safe(session.getFullName()), 45) + "|");
            print("|  Email : " + pad(safe(session.getEmail()), 45) + "|");
            print("+=======================================================+");
            print("|  1. My Policies                                       |");
            print("|  2. Browse Plans & Buy Policy                         |");
            print("|  3. My Claims                                         |");
            print("|  4. File a Claim                                      |");
            print("|  5. My Premium Payments                               |");
            print("|  6. Cancel a Policy                                   |");
            print("|  0. Logout                                            |");
            print("+=======================================================+");
            switch (readChoice(6)) {
                case 1 -> viewMyPolicies();
                case 2 -> browseAndBuyPolicy();
                case 3 -> viewMyClaims();
                case 4 -> fileClaim();
                case 5 -> viewMyPayments();
                case 6 -> cancelMyPolicy();
                case 0 -> { session = null; active = false; print("Logged out."); }
            }
        }
    }

    private void viewMyPolicies() {
        print("\n-- My Policies --");
        try {
            List<Policy> policies = policyService.findByCustomerId(session.getId());
            if (policies.isEmpty()) { print("No policies yet. Select 'Browse Plans & Buy Policy'."); return; }
            printPolicyTable(policies);
            print("\n  Policy Status Guide:");
            print("  QUOTED        - Created, payment not yet made");
            print("  ACTIVE        - Payment done, coverage is running");
            print("  PENDING_UW    - Under underwriter review (high-risk trip)");
            print("  CANCELLED     - Policy cancelled before or during trip");
            print("  EXPIRED       - Trip end date has passed");
            List<Policy> quoted = policies.stream().filter(p -> "QUOTED".equals(p.getStatus())).toList();
            if (!quoted.isEmpty()) {
                print("\n-- Quoted Policies - Pay to Activate --");
                for (int i = 0; i < quoted.size(); i++) {
                    Policy q = quoted.get(i);
                    print("  " + (i+1) + ". [" + q.getPolicyNumber() + "]  " +
                          q.getTripStartDate() + " to " + q.getTripEndDate() +
                          "  " + formatINR(q.getTotalPremium()));
                }
                print("  0. Skip");
                int qIdx = readChoiceInRange("Select to pay now (0 to skip): ", 0, quoted.size()) - 1;
                if (qIdx >= 0) payForQuotedPolicy(quoted.get(qIdx));
            }
        } catch (Exception e) { print("Error: " + e.getMessage()); }
    }

    private void payForQuotedPolicy(Policy policy) {
        print("\n-- Pay for Policy [" + policy.getPolicyNumber() + "] --");
        print("  Trip    : " + policy.getTripStartDate() + " to " + policy.getTripEndDate());
        print("  Premium : " + formatINR(policy.getTotalPremium()));
        print("  1. Confirm Payment & Activate   2. Cancel");
        if (readChoice(2) != 1) return;
        try {
            Payment payment = paymentService.processPayment(policy.getId(), policy.getTotalPremium(), CURRENCY);
            paymentService.completePayment(payment.getId());
            policyService.activatePolicy(policy.getId());
            print("[OK] Payment confirmed! Ref: " + payment.getPaymentReference());
            print("[OK] Policy " + policy.getPolicyNumber() + " is now ACTIVE.");
        } catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    private void browseAndBuyPolicy() {
        print("\n+=== TRAVEL INSURANCE MARKETPLACE =====================+");
        print("|  All amounts in Indian Rupees (INR)                  |");
        List<Plan> plans = planService.getActivePlans();
        if (plans.isEmpty()) { print("No plans available."); return; }
        showPlanCards(plans);
        print("\n  1-" + plans.size() + ". Select plan to view details & buy");
        print("  0. Back");
        int planIdx = readChoiceInRange("Your choice: ", 0, plans.size()) - 1;
        if (planIdx < 0) return;
        Plan selected = plans.get(planIdx);
        if (viewPlanDetailsAndConfirm(selected)) collectTripDetailsAndPurchase(selected);
    }

    private void showPlanCards(List<Plan> plans) {
        print("\n-- Available Plans --");
        for (int i = 0; i < plans.size(); i++) {
            Plan p = plans.get(i);
            print("\n  [" + (i+1) + "] " + p.getPlanName() + " (" + p.getPlanCode() + ")");
            print("      Base Premium  : " + formatINR(p.getBasePremium()));
            print("      Trip Duration : " + p.getMinTripDays() + "-" + p.getMaxTripDays() + " days");
            print("      Max Travelers : " + p.getMaxTravelers());
            try {
                List<PlanCoverage> coverages = coverageDao.findByPlanId(p.getId());
                for (PlanCoverage pc : coverages) {
                    String[] pts = pc.getCoverageTypeId().split("\\|");
                    String name = pts.length > 1 ? pts[1] : "Coverage";
                    print("                      - " + name + " up to " + formatINR(pc.getDefaultLimit()));
                }
            } catch (Exception ignored) {}
        }
    }

    private boolean viewPlanDetailsAndConfirm(Plan selected) {
        print("\n+=== PLAN DETAILS: " + selected.getPlanName() + " ===");
        print("  Base Premium  : " + formatINR(selected.getBasePremium()));
        print("  Trip Range    : " + selected.getMinTripDays() + " to " + selected.getMaxTripDays() + " days");
        print("  Max Travelers : " + selected.getMaxTravelers());
        print("\n  -- WHAT'S COVERED (Sum Insured) --");
        print("  " + row("Coverage",30) + row("Sum Insured",18) + row("Deductible",14) + "Type");
        print("  " + "-".repeat(70));
        try {
            List<PlanCoverage> coverages = coverageDao.findByPlanId(selected.getId());
            if (coverages.isEmpty()) print("  No coverage details found.");
            else for (PlanCoverage pc : coverages) {
                String[] pts = pc.getCoverageTypeId().split("\\|");
                String name = pts.length > 1 ? pts[1] : "-";
                String ded  = pc.getDeductible() != null && pc.getDeductible().compareTo(BigDecimal.ZERO) > 0
                        ? formatINR(pc.getDeductible()) : "Nil";
                print("  " + row(name,30) + row(formatINR(pc.getDefaultLimit()),18) +
                      row(ded,14) + (pc.isMandatory() ? "Included" : "Optional"));
            }
        } catch (Exception e) { print("  Could not load coverages: " + e.getMessage()); }
        print("\n  -- AVAILABLE ADD-ONS --");
        List<Addon> addons = new ArrayList<>();
        try {
            addons = addonDao.findByPlanId(selected.getId());
            if (addons.isEmpty()) print("  No add-ons for this plan.");
            else for (int i = 0; i < addons.size(); i++) {
                Addon a = addons.get(i);
                String price = "FLAT".equals(a.getPricingType())
                        ? formatINR(a.getPricingValue()) : a.getPricingValue() + "% of premium";
                print("  " + (i+1) + ". " + a.getAddonName() + " [" + price + "] - " + safe(a.getDescription()));
            }
        } catch (Exception e) { print("  Could not load add-ons."); }
        print("\n  1. Proceed to Buy   2. Back");
        return readChoice(2) == 1;
    }

    private void collectTripDetailsAndPurchase(Plan selected) {
        print("\n---- Trip Details ---- (enter 0 at any step to go back to plan list)");

        // STEP 1: Destination
        print("\nStep 1 of 5 - Destination");
        print("Select Destination (0 to go back):");
        for (String[] d : DESTINATIONS) print("  " + d[0] + ". " + d[1]);
        int destChoice = readChoiceInRange("Destination: ", 0, DESTINATIONS.length);
        if (destChoice == 0) { print("Returning to plan list."); browseAndBuyPolicy(); return; }
        String destLabel = DESTINATIONS[destChoice-1][1];
        String destCode  = DESTINATIONS[destChoice-1][2];
        print("  Selected: " + destLabel);

        // STEP 2: Trip dates
        print("\nStep 2 of 5 - Trip Dates (enter BACK to return to destination)");
        LocalDate start;
        while (true) {
            start = readDateOrBack("Trip Start Date (YYYY-MM-DD, or BACK): ");
            if (start == null) return; // timeout
            if (start == LocalDate.MIN) { print("Returning to plan list."); browseAndBuyPolicy(); return; }
            if (start.isBefore(LocalDate.now())) { print("Start date cannot be in the past. Try again."); continue; }
            break;
        }
        LocalDate end;
        while (true) {
            end = readDateOrBack("Trip End Date   (YYYY-MM-DD, or BACK): ");
            if (end == null) return;
            if (end == LocalDate.MIN) { print("Returning to start date entry."); continue; }
            if (end.isBefore(start)) { print("End date cannot be before " + start + ". Try again."); continue; }
            break;
        }
        long tripDays = java.time.temporal.ChronoUnit.DAYS.between(start, end);
        if (tripDays < selected.getMinTripDays()) { print("This plan requires at least " + selected.getMinTripDays() + " days. Trip is only " + tripDays + " days."); return; }
        if (tripDays > selected.getMaxTripDays()) { print("This plan allows max " + selected.getMaxTripDays() + " days. Trip is " + tripDays + " days."); return; }
        print("  Trip: " + start + " to " + end + " (" + tripDays + " days)");

        // STEP 3: Travelers and their ages
        print("\nStep 3 of 5 - Travelers (0 to go back)");
        int travelers;
        while (true) {
            System.out.print("Number of Travelers (1-" + selected.getMaxTravelers() + ", 0 to go back): ");
            try {
                travelers = Integer.parseInt(scanner.nextLine().trim());
                if (travelers == 0) { print("Returning to plan list."); browseAndBuyPolicy(); return; }
                if (travelers < 1) { print("At least 1 traveler required."); continue; }
                if (travelers > selected.getMaxTravelers()) { print("Max " + selected.getMaxTravelers() + " travelers for this plan."); continue; }
                break;
            } catch (NumberFormatException e) { print("Invalid number."); }
        }

        // Collect age for each traveler
        List<Integer> travelerAges = new ArrayList<>();
        print("  Please enter age for each traveler (for risk assessment):");
        for (int i = 1; i <= travelers; i++) {
            while (true) {
                System.out.print("  Traveler " + i + " age: ");
                try {
                    int age = Integer.parseInt(scanner.nextLine().trim());
                    if (age < 0 || age > 120) { print("  Enter a valid age (0-120)."); continue; }
                    travelerAges.add(age);
                    break;
                } catch (NumberFormatException e) { print("  Invalid age."); }
            }
        }
        // Show senior traveler notice if any > 60
        long seniors = travelerAges.stream().filter(a -> a > 60).count();
        if (seniors > 0) {
            print("  [!] Note: " + seniors + " traveler(s) above age 60. Senior traveler surcharge applies.");
        }

        // STEP 4: Trip purpose
        print("\nStep 4 of 5 - Trip Purpose (0 to go back)");
        print("  1. LEISURE   2. BUSINESS   0. Back");
        int purposeChoice = readChoiceInRange("Your choice (1-2, 0 to go back): ", 0, 2);
        if (purposeChoice == 0) { print("Returning to plan list."); browseAndBuyPolicy(); return; }
        String purpose = purposeChoice == 2 ? "BUSINESS" : "LEISURE";
        List<String> selectedAddonIds = new ArrayList<>();
        BigDecimal addonTotal = BigDecimal.ZERO;
        List<Addon> availableAddons = new ArrayList<>();
        try { availableAddons = addonDao.findByPlanId(selected.getId()); } catch (Exception ignored) {}
        if (!availableAddons.isEmpty()) {
            print("\nStep 5 of 5 - Add-ons (optional, 0 for none)");
            for (int i = 0; i < availableAddons.size(); i++) {
                Addon a = availableAddons.get(i);
                String price = "FLAT".equals(a.getPricingType())
                        ? formatINR(a.getPricingValue()) : a.getPricingValue() + "% of premium";
                print("  " + (i+1) + ". " + a.getAddonName() + " [" + price + "] - " + safe(a.getDescription()));
            }
            print("  0. No add-ons");
            print("Enter add-on numbers (e.g. 1,2) or 0:");
            String input = scanner.nextLine().trim();
            if (!input.equals("0") && !input.isBlank()) {
                for (String part : input.split(",")) {
                    try {
                        int idx = Integer.parseInt(part.trim()) - 1;
                        if (idx >= 0 && idx < availableAddons.size()) {
                            Addon a = availableAddons.get(idx);
                            if (!selectedAddonIds.contains(a.getId())) {
                                selectedAddonIds.add(a.getId());
                                if ("FLAT".equals(a.getPricingType()))
                                    addonTotal = addonTotal.add(a.getPricingValue());
                            }
                        }
                    } catch (NumberFormatException ignored) {}
                }
            }
        }
        print("\n-- Policy Summary --");
        print("  Plan        : " + selected.getPlanName());
        print("  Destination : " + destLabel + " (" + destCode + ")");
        print("  Trip        : " + start + " to " + end + " (" + tripDays + " days)");
        print("  Travelers   : " + travelers);
        if (!travelerAges.isEmpty()) {
            StringBuilder agesStr = new StringBuilder();
            for (int i = 0; i < travelerAges.size(); i++) {
                if (i > 0) agesStr.append(", ");
                agesStr.append("T").append(i+1).append(":").append(travelerAges.get(i)).append("yrs");
            }
            print("  Ages        : " + agesStr);
        }
        print("  Purpose     : " + purpose);
        if (!selectedAddonIds.isEmpty()) {
            print("  Add-ons     :");
            for (String id : selectedAddonIds)
                for (Addon a : availableAddons)
                    if (a.getId().equals(id))
                        print("    + " + a.getAddonName());
        }
        print("  Base Premium: " + formatINR(selected.getBasePremium()) + " (+ daily rate x days x travelers)");
        if (addonTotal.compareTo(BigDecimal.ZERO) > 0)
            print("  Add-on Total: +" + formatINR(addonTotal));
        print("  Final amount calculated on confirm (includes risk loading).");
        print("\n  1. Confirm Details & Continue   2. Cancel");
        int confirmChoice = readChoiceInRange("Your choice (1-2): ", 1, 2);
        if (confirmChoice == 2) { print("Cancelled."); return; }
        try {
            PolicyDto dto = new PolicyDto(session.getId(), selected.getId(), destCode,
                    start, end, travelers, travelerAges, purpose, CURRENCY, selectedAddonIds);
            Policy policy = policyService.createPolicy(dto);

            // Show risk assessment result to customer BEFORE payment
            print("\n+- Risk Assessment Result ----------------------------------");
            print("|  Risk Score  : " + policy.getRiskScore());
            print("|  Risk Level  : " + policy.getRiskLevel());
            if ("HIGH".equals(policy.getRiskLevel())) {
                print("|  [!] HIGH RISK: This policy requires underwriter review.");
                print("|  Your policy will be reviewed before activation.");
                print("|  Typical review time: 24-48 hours.");
            } else if ("MEDIUM".equals(policy.getRiskLevel())) {
                print("|  [OK] MEDIUM RISK: Standard policy. Proceed to payment.");
            } else {
                print("|  [OK] LOW RISK: Standard policy. Proceed to payment.");
            }
            print("+----------------------------------------------------------");

            print("\n  Policy Number : " + policy.getPolicyNumber());
            print("  Premium       : " + formatINR(policy.getTotalPremium()));

            if ("PENDING_UW".equals(policy.getStatus())) {
                // High risk: no payment yet, pending underwriter
                print("  Status        : PENDING_UW (awaiting underwriter approval)");
                print("\n[OK] Policy registered and sent for underwriter review.");
                print("  Reference: " + policy.getPolicyNumber());
                print("  You will be notified once the underwriter takes action.");
                print("  Payment will be collected after approval.");
            } else {
                // QUOTED: low/medium risk, ask for payment
                print("  Status        : QUOTED");
                print("\n-- Payment ------------------------------------------");
                print("  Premium Amount : " + formatINR(policy.getTotalPremium()));
                print("  1. Pay Now     - Confirm payment & activate policy immediately");
                print("  2. Pay Later   - Save as QUOTED (pay later from My Policies)");
                int payChoice = readChoiceInRange("Your choice (1-2): ", 1, 2);
                if (payChoice == 1) {
                    Payment payment = paymentService.processPayment(
                            policy.getId(), policy.getTotalPremium(), CURRENCY);
                    paymentService.completePayment(payment.getId());
                    policyService.activatePolicy(policy.getId());
                    print("[OK] Payment confirmed! Ref: " + payment.getPaymentReference());
                    print("[OK] Policy " + policy.getPolicyNumber() + " is now ACTIVE. Coverage starts " + policy.getTripStartDate() + ".");
                } else {
                    print("[OK] Policy saved as QUOTED. Go to My Policies to pay when ready.");
                }
            }
        } catch (Exception e) { print("Error: " + e.getMessage()); }
    }


    private void cancelMyPolicy() {
        print("\n---- Cancel a Policy ----");
        try {
            List<Policy> cancellable = policyService.findByCustomerId(session.getId()).stream()
                    .filter(p -> "ACTIVE".equals(p.getStatus()) || "QUOTED".equals(p.getStatus()))
                    .toList();
            if (cancellable.isEmpty()) {
                print("You have no cancellable policies (only ACTIVE or QUOTED policies can be cancelled).");
                return;
            }
            printPolicyTable(cancellable);
            print("\n  Note: ACTIVE policies that have not been used may be cancelled.");
            print("  Cancellation is final and cannot be undone.");
            int idx = readChoiceInRange("Select policy to cancel (0 to go back): ", 0, cancellable.size()) - 1;
            if (idx < 0) return;
            Policy chosen = cancellable.get(idx);
            print("\n  Policy to cancel:");
            print("  [" + chosen.getPolicyNumber() + "]  " +
                  chosen.getTripStartDate() + " to " + chosen.getTripEndDate() +
                  "  Premium: " + formatINR(chosen.getTotalPremium()));
            print("\n  Select cancellation reason:");
            String[] reasons = {
                "Change of travel plans",
                "Found a better plan",
                "Medical reason - unable to travel",
                "Visa rejected",
                "Other"
            };
            for (int i = 0; i < reasons.length; i++)
                print("  " + (i+1) + ". " + reasons[i]);
            int rIdx = readChoiceInRange("Reason (1-" + reasons.length + ", 0 to go back): ", 0, reasons.length) - 1;
            if (rIdx < 0) return;
            String reason = reasons[rIdx];
            print("  1. Confirm Cancellation   2. Go Back");
            if (readChoiceInRange("Your choice (1-2): ", 1, 2) != 1) { print("Cancellation aborted."); return; }
            policyService.cancelPolicy(chosen.getId(), reason);
            print("[OK] Policy " + chosen.getPolicyNumber() + " has been CANCELLED.");
            print("  Reason: " + reason);
        } catch (Exception e) { print("Error: " + e.getMessage()); }
    }

    private void viewMyClaims() {
        print("\n-- My Claims --");
        try {
            List<Claim> claims = claimService.findByCustomerId(session.getId());
            if (claims.isEmpty()) { print("No claims on record."); return; }
            printClaimTable(claims);
        } catch (Exception e) { print("Error: " + e.getMessage()); }
    }

    private void fileClaim() {
        print("\n---- File a Claim ----");
        List<Policy> activePolicies;
        try {
            activePolicies = policyService.findByCustomerId(session.getId()).stream()
                    .filter(p -> "ACTIVE".equals(p.getStatus())).toList();
        } catch (Exception e) { print("Error: " + e.getMessage()); return; }
        if (activePolicies.isEmpty()) { print("No active policies. Claims require an active policy."); return; }
        print("\nYour Active Policies:");
        for (int i = 0; i < activePolicies.size(); i++) {
            Policy p = activePolicies.get(i);
            print("  " + (i+1) + ". [" + p.getPolicyNumber() + "]  " +
                  p.getTripStartDate() + " to " + p.getTripEndDate() +
                  "  Dest: " + safe(p.getDestinationCountryCode()) +
                  "  Premium: " + formatINR(p.getTotalPremium()));
        }
        int pIdx = readChoiceInRange("Select policy (0 to cancel): ", 0, activePolicies.size()) - 1;
        if (pIdx < 0) return;
        Policy chosenPolicy = activePolicies.get(pIdx);
        // Show claim types relevant to the customer's plan (coverage + addon claims)
        com.insurance.dao.impl.ClaimTypeDaoImpl ctDaoImpl = new com.insurance.dao.impl.ClaimTypeDaoImpl();
        List<ClaimType> types = ctDaoImpl.findByPlanId(chosenPolicy.getPlanId());
        if (types.isEmpty()) { types = claimTypeDao.findAll(); } // fallback
        print("\nClaim Types for your plan:");
        for (int i = 0; i < types.size(); i++)
            print("  " + (i+1) + ". " + types.get(i).getName() +
                  (types.get(i).getCoverageTypeId() == null ? " [Add-on]" : ""));
        int tIdx = readChoiceInRange("Select type (0 to cancel): ", 0, types.size()) - 1;
        if (tIdx < 0) return;
        ClaimType chosenType = types.get(tIdx);
        LocalDate incidentDate = readDate("Incident Date (YYYY-MM-DD): ");
        if (incidentDate == null) return;
        if (incidentDate.isAfter(LocalDate.now())) { print("Incident date cannot be in the future."); return; }
        if (incidentDate.isBefore(chosenPolicy.getTripStartDate())) {
            print("Incident date cannot be before trip start (" + chosenPolicy.getTripStartDate() + ")."); return;
        }
        String desc;
        while (true) {
            desc = readNonBlank("Describe the incident (min 10 characters): ").trim();
            if (desc.length() >= 10) break;
            print("Description too short.");
        }
        // Show sum insured for context
        print("\n  Sum Insured for your plan:");
        try {
            List<PlanCoverage> coverages = coverageDao.findByPlanId(chosenPolicy.getPlanId());
            for (PlanCoverage pc : coverages) {
                String[] pts = pc.getCoverageTypeId().split("\\|");
                print("  - " + (pts.length > 1 ? pts[1] : "Coverage") +
                      ": up to " + formatINR(pc.getDefaultLimit()));
            }
        } catch (Exception ignored) {}
        print("\n  Note: Enter the approximate value of your claim.");
        print("  The claims officer will determine the final settlement amount.");
        BigDecimal amount = readPositiveDecimal("Approximate Claim Value (INR): ");
        if (amount == null) return;
        print("\n-- Claim Summary --");
        print("  Policy     : " + chosenPolicy.getPolicyNumber());
        print("  Claim Type : " + chosenType.getName());
        print("  Incident   : " + incidentDate);
        print("  Approx Val : " + formatINR(amount));
        print("  High Value : " + (amount.compareTo(new BigDecimal("1000000")) > 0
                ? "YES - extra review required" : "No"));
        print("  1. Submit   2. Cancel");
        if (readChoiceInRange("Your choice (1-2): ", 1, 2) != 1) { print("Cancelled."); return; }
        try {
            Claim claim = claimService.submitClaim(new ClaimDto(
                    chosenPolicy.getId(), session.getId(),
                    chosenType.getId(), incidentDate, desc, amount));
            print("[OK] Claim submitted! Reference: " + claim.getClaimReference());
        } catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    private void viewMyPayments() {
        print("\n-- My Premium Payments (payments made by you for your policies) --");
        try {
            List<Policy> policies = policyService.findByCustomerId(session.getId());
            List<Payment> allPayments = new ArrayList<>();
            for (Policy p : policies)
                allPayments.addAll(paymentService.findByPolicyId(p.getId()));
            List<Payment> premiumPayments = allPayments.stream()
                    .filter(p -> "PREMIUM_RECEIVED".equals(p.getPaymentType()) || p.getPaymentType() == null)
                    .toList();
            if (premiumPayments.isEmpty()) { print("No premium payments found."); return; }
            printPaymentTable(premiumPayments);
        } catch (Exception e) { print("Error: " + e.getMessage()); }
    }

    // =========================================================================
    // UNDERWRITER PORTAL
    // =========================================================================
    private void uwPortal() {
        boolean active = true;
        while (active) {
            print("\n+=== UNDERWRITER PORTAL ================================+");
            print("|  Officer : " + pad(safe(session.getFullName()), 43) + "|");
            print("|  Email   : " + pad(safe(session.getEmail()), 43) + "|");
            print("+=======================================================+");
            print("|  1. Policies Pending Review                           |");
            print("|  2. Approve Policy                                    |");
            print("|  3. Reject Policy                                     |");
            print("|  4. View All Policies (with status)                   |");
            print("|  0. Logout                                            |");
            print("+=======================================================+");
            switch (readChoice(4)) {
                case 1 -> { List<Policy> p = policyService.findByStatus("PENDING_UW"); printPolicyTable(p); }
                case 2 -> approvePolicy();
                case 3 -> rejectPolicy();
                case 4 -> { List<Policy> all = policyService.findAll(); printPolicyTable(all); }
                case 0 -> { session = null; active = false; print("Logged out."); }
            }
        }
    }

    private void approvePolicy() {
        List<Policy> pending = policyService.findByStatus("PENDING_UW");
        if (pending.isEmpty()) { print("No policies pending UW review."); return; }
        printNumberedPolicyList(pending);
        int idx = readChoiceInRange("Select to approve (0 to cancel): ", 0, pending.size()) - 1;
        if (idx < 0) return;
        Policy chosen = pending.get(idx);
        print("Approving: [" + chosen.getPolicyNumber() + "]  " +
              "Customer: " + userDao.findFullNameById(chosen.getCustomerId()) +
              "  Risk: " + chosen.getRiskLevel() + "  Premium: " + formatINR(chosen.getTotalPremium()));
        print("  1. Confirm   2. Cancel");
        if (readChoiceInRange("Your choice (1-2): ", 1, 2) != 1) return;
        try { policyService.activatePolicy(chosen.getId()); print("[OK] Policy ACTIVATED."); }
        catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    private void rejectPolicy() {
        List<Policy> pending = policyService.findByStatus("PENDING_UW");
        if (pending.isEmpty()) { print("No policies pending."); return; }
        printNumberedPolicyList(pending);
        int idx = readChoiceInRange("Select to reject (0 to cancel): ", 0, pending.size()) - 1;
        if (idx < 0) return;
        Policy chosen = pending.get(idx);
        String reason;
        while (true) {
            reason = readNonBlank("Rejection reason (min 10 chars): ").trim();
            if (reason.length() >= 10) break;
            print("Reason too short.");
        }
        print("  1. Confirm   2. Cancel");
        if (readChoiceInRange("Your choice (1-2): ", 1, 2) != 1) return;
        try { policyService.rejectPolicy(chosen.getId(), reason); print("[OK] Policy REJECTED."); }
        catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    // =========================================================================
    // CLAIMS OFFICER PORTAL
    // =========================================================================
    private void claimsOfficerPortal() {
        boolean active = true;
        while (active) {
            print("\n+=== CLAIMS OFFICER PORTAL =============================+");
            print("|  Officer : " + pad(safe(session.getFullName()), 43) + "|");
            print("|  Email   : " + pad(safe(session.getEmail()), 43) + "|");
            print("+=======================================================+");
            print("|  1. Claims Queue (SUBMITTED)                          |");
            print("|  2. Field Investigation Results (FIELD_APPROVED/REJ)  |");
            print("|  3. All Claims                                        |");
            print("|  4. Approve Claim (Final Settlement)                  |");
            print("|  5. Reject Claim                                      |");
            print("|  6. Request More Documents                            |");
            print("|  7. Assign Field Officer                              |");
            print("|  0. Logout                                            |");
            print("+=======================================================+");
            switch (readChoice(7)) {
                case 1 -> { printClaimTable(claimService.findByStatus("SUBMITTED")); }
                case 2 -> viewFieldResults();
                case 3 -> { printClaimTable(claimService.findAll()); }
                case 4 -> approveClaim();
                case 5 -> rejectClaim();
                case 6 -> requestMoreDocs();
                case 7 -> assignFieldOfficer();
                case 0 -> { session = null; active = false; print("Logged out."); }
            }
        }
    }

    private void viewFieldResults() {
        print("\n-- Field Investigation Results --");
        List<Claim> fieldApproved = claimService.findByStatus("FIELD_APPROVED");
        List<Claim> fieldRejected = claimService.findByStatus("FIELD_REJECTED");
        if (fieldApproved.isEmpty() && fieldRejected.isEmpty()) {
            print("No field investigation results pending your action."); return;
        }
        if (!fieldApproved.isEmpty()) {
            print("\n[FIELD OFFICER RECOMMENDS APPROVAL]");
            printClaimTable(fieldApproved);
        }
        if (!fieldRejected.isEmpty()) {
            print("\n[FIELD OFFICER RECOMMENDS REJECTION]");
            printClaimTable(fieldRejected);
        }
        print("\nUse option 4 (Approve) or 5 (Reject) to take final action on these claims.");
    }

    private void approveClaim() {
        print("\n-- Approve Claim (Final Settlement Decision) --");
        List<Claim> eligible = claimService.findAll().stream()
                .filter(c -> "SUBMITTED".equals(c.getStatus())
                        || "FIELD_APPROVED".equals(c.getStatus())
                        || "FIELD_REJECTED".equals(c.getStatus()))
                .toList();
        if (eligible.isEmpty()) { print("No claims eligible for approval decision."); return; }
        printNumberedClaimList(eligible);
        int idx = readChoiceInRange("Select claim (0 to cancel): ", 0, eligible.size()) - 1;
        if (idx < 0) return;
        Claim chosen = eligible.get(idx);
        printClaimDetail(chosen);
        if ("FIELD_REJECTED".equals(chosen.getStatus())) {
            print("  [!] Field officer recommended REJECTION. You are overriding that recommendation.");
        }
        print("\n  The customer's approximate claim value: " + formatINR(chosen.getClaimedAmount()));
        print("  Enter the settlement amount (must be <= approximate claim value).");
        BigDecimal approved = readDecimalMax(
                "Settlement Amount (INR, max " + formatINR(chosen.getClaimedAmount()) + "): ",
                chosen.getClaimedAmount());
        if (approved == null) return;
        print("  1. Confirm Approve with " + formatINR(approved) + "   2. Cancel");
        if (readChoice(2) != 1) return;
        try {
            claimService.approveClaim(chosen.getId(), approved, session.getId());
            print("[OK] Claim " + chosen.getClaimReference() + " APPROVED. Settlement: " + formatINR(approved));
            print("[OK] Finance officer can now process the payout.");
        } catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    private void rejectClaim() {
        print("\n-- Reject Claim --");
        List<Claim> eligible = claimService.findAll().stream()
                .filter(c -> "SUBMITTED".equals(c.getStatus())
                        || "FIELD_APPROVED".equals(c.getStatus())
                        || "FIELD_REJECTED".equals(c.getStatus()))
                .toList();
        if (eligible.isEmpty()) { print("No eligible claims."); return; }
        printNumberedClaimList(eligible);
        int idx = readChoiceInRange("Select claim (0 to cancel): ", 0, eligible.size()) - 1;
        if (idx < 0) return;
        Claim chosen = eligible.get(idx);
        printClaimDetail(chosen);
        String reason;
        while (true) {
            reason = readNonBlank("Rejection reason (min 10 chars): ").trim();
            if (reason.length() >= 10) break;
            print("Reason too short.");
        }
        print("  1. Confirm   2. Cancel");
        if (readChoiceInRange("Your choice (1-2): ", 1, 2) != 1) return;
        try {
            claimService.rejectClaim(chosen.getId(), reason, session.getId());
            print("[OK] Claim " + chosen.getClaimReference() + " REJECTED.");
        } catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    private void requestMoreDocs() {
        List<Claim> submitted = claimService.findByStatus("SUBMITTED");
        if (submitted.isEmpty()) { print("No submitted claims."); return; }
        printNumberedClaimList(submitted);
        int idx = readChoiceInRange("Select claim (0 to cancel): ", 0, submitted.size()) - 1;
        if (idx < 0) return;
        try {
            claimService.updateStatus(submitted.get(idx).getId(), "PENDING_DOCS");
            print("[OK] Status updated to PENDING_DOCS. Customer notified.");
        } catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    private void assignFieldOfficer() {
        List<Claim> eligible = claimService.findAll().stream()
                .filter(c -> "SUBMITTED".equals(c.getStatus())).toList();
        if (eligible.isEmpty()) { print("No submitted claims to assign."); return; }
        printNumberedClaimList(eligible);
        int cIdx = readChoiceInRange("Select claim (0 to cancel): ", 0, eligible.size()) - 1;
        if (cIdx < 0) return;
        List<User> fieldOfficers = userDao.findByRole("FIELD_OFFICER");
        if (fieldOfficers.isEmpty()) { print("No field officers available."); return; }
        print("\nField Officers:");
        for (int i = 0; i < fieldOfficers.size(); i++)
            print("  " + (i+1) + ". " + safe(fieldOfficers.get(i).getFullName()) +
                  " (" + fieldOfficers.get(i).getEmail() + ")");
        int oIdx = readChoiceInRange("Select officer (0 to cancel): ", 0, fieldOfficers.size()) - 1;
        if (oIdx < 0) return;
        try {
            claimService.assignFieldOfficer(eligible.get(cIdx).getId(), fieldOfficers.get(oIdx).getId());
            print("[OK] Assigned to " + safe(fieldOfficers.get(oIdx).getFullName()) + ".");
            print("[OK] Claim moved to IN_REVIEW. Awaiting field officer findings.");
        } catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    // =========================================================================
    // FIELD OFFICER PORTAL
    // =========================================================================
    private void fieldOfficerPortal() {
        boolean active = true;
        while (active) {
            print("\n+=== FIELD OFFICER PORTAL ==============================+");
            print("|  Officer : " + pad(safe(session.getFullName()), 43) + "|");
            print("|  Email   : " + pad(safe(session.getEmail()), 43) + "|");
            print("+=======================================================+");
            print("|  1. My Assigned Claims                                |");
            print("|  2. Submit Investigation Findings                     |");
            print("|  0. Logout                                            |");
            print("+=======================================================+");
            switch (readChoice(2)) {
                case 1 -> viewMyAssignments();
                case 2 -> submitInvestigationFindings();
                case 0 -> { session = null; active = false; print("Logged out."); }
            }
        }
    }

    private void viewMyAssignments() {
        print("\n-- My Assigned Claims --");
        List<Claim> assigned = claimService.findByAssignedOfficerId(session.getId());
        if (assigned.isEmpty()) { print("No claims assigned to you."); return; }
        printClaimTable(assigned);
    }

    private void submitInvestigationFindings() {
        print("\n-- Submit Investigation Findings --");
        List<Claim> assigned = claimService.findByAssignedOfficerId(session.getId()).stream()
                .filter(c -> "IN_REVIEW".equals(c.getStatus())).toList();
        if (assigned.isEmpty()) { print("No claims pending your findings (must be IN_REVIEW status)."); return; }
        printNumberedClaimList(assigned);
        int idx = readChoiceInRange("Select claim to submit findings (0 to cancel): ", 0, assigned.size()) - 1;
        if (idx < 0) return;
        Claim chosen = assigned.get(idx);
        printClaimDetail(chosen);
        print("\n  Submit your investigation outcome:");
        print("  1. FIELD_APPROVED - I recommend approving this claim");
        print("  2. FIELD_REJECTED - I recommend rejecting this claim");
        print("  3. Cancel");
        int choice = readChoice(3);
        if (choice == 3) return;
        String outcome = choice == 1 ? "FIELD_APPROVED" : "FIELD_REJECTED";
        print("  1. Confirm submission of '" + outcome + "'   2. Cancel");
        if (readChoice(2) != 1) { print("Cancelled."); return; }
        try {
            claimService.submitFieldFindings(chosen.getId(), outcome, session.getId());
            print("[OK] Findings submitted: " + outcome);
            print("[OK] Claims officer has been notified and will take the final decision.");
        } catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    // =========================================================================
    // FINANCE OFFICER PORTAL
    // =========================================================================
    private void financePortal() {
        boolean active = true;
        while (active) {
            print("\n+=== FINANCE OFFICER PORTAL ============================+");
            print("|  Officer : " + pad(safe(session.getFullName()), 43) + "|");
            print("|  Email   : " + pad(safe(session.getEmail()), 43) + "|");
            print("+=======================================================+");
            print("|  1. Pending Payments                                  |");
            print("|  2. Mark Payment as Completed                         |");
            print("|  3. All Payments                                      |");
            print("|  4. Finance Summary (Credits / Settlements)           |");
            print("|  0. Logout                                            |");
            print("+=======================================================+");
            switch (readChoice(4)) {
                case 1 -> pendingPaymentsMenu();
                case 2 -> markCompletedMenu();
                case 3 -> allPaymentsMenu();
                case 4 -> showFinanceSummary();
                case 0 -> { session = null; active = false; print("Logged out."); }
            }
        }
    }

    private void pendingPaymentsMenu() {
        print("\n-- Pending Payments --");
        print("  1. Premium pending from customer");
        print("  2. Claims payout pending (to be released to customer)");
        print("  3. View both");
        print("  0. Back");
        switch (readChoice(3)) {
            case 1 -> {
                List<Payment> p = paymentService.findByType("PREMIUM_RECEIVED").stream()
                        .filter(x -> "PENDING".equals(x.getStatus())).toList();
                print("\n--- Premium Pending from Customer ---");
                printPaymentTable(p);
            }
            case 2 -> {
                List<Payment> p = paymentService.findByType("CLAIM_PAYOUT").stream()
                        .filter(x -> "PENDING".equals(x.getStatus())).toList();
                print("\n--- Claims Payout Pending (Company to Customer) ---");
                printPaymentTable(p);
            }
            case 3 -> {
                print("\n--- Premium Pending ---");
                printPaymentTable(paymentService.findByType("PREMIUM_RECEIVED").stream()
                        .filter(x -> "PENDING".equals(x.getStatus())).toList());
                print("\n--- Claims Payout Pending ---");
                printPaymentTable(paymentService.findByType("CLAIM_PAYOUT").stream()
                        .filter(x -> "PENDING".equals(x.getStatus())).toList());
            }
        }
    }

    private void markCompletedMenu() {
        print("\n-- Mark Payment as Completed --");
        print("  1. Received premium from customer");
        print("  2. Settle claim payout to customer");
        print("  0. Back");
        int choice = readChoice(2);
        if (choice == 0) return;
        String type = choice == 1 ? "PREMIUM_RECEIVED" : "CLAIM_PAYOUT";
        String label = choice == 1 ? "Premium Received" : "Claim Payout";
        List<Payment> pending = paymentService.findByType(type).stream()
                .filter(x -> "PENDING".equals(x.getStatus())).toList();
        if (pending.isEmpty()) { print("No pending " + label + " payments found."); return; }
        printNumberedPaymentList(pending);
        int idx = readChoiceInRange("Select to mark complete (0 to cancel): ", 0, pending.size()) - 1;
        if (idx < 0) return;
        Payment chosen = pending.get(idx);
        String customerName = "-";
        try {
            // For claim payouts, look up via claim's customerId directly
            if ("CLAIM_PAYOUT".equals(chosen.getPaymentType()) && chosen.getClaimId() != null) {
                com.insurance.entity.Claim c2 = claimService.findById(chosen.getClaimId());
                if (c2 != null) customerName = userDao.findFullNameById(c2.getCustomerId());
            } else {
                com.insurance.entity.Policy pol = policyService.findAll().stream()
                    .filter(p -> p.getId().equals(chosen.getPolicyId())).findFirst().orElse(null);
                if (pol != null) customerName = userDao.findFullNameById(pol.getCustomerId());
            }
        } catch (Exception ignored) {}
        print("  " + label + " | Customer: " + customerName +
              " | Amount: " + formatINR(chosen.getAmount()));
        print("  1. Confirm Completed   2. Cancel");
        if (readChoiceInRange("Your choice (1-2): ", 1, 2) != 1) return;
        try {
            if (choice == 1) paymentService.completePayment(chosen.getId());
            else             paymentService.completeClaimPayout(chosen.getId());
            print("[OK] " + label + " marked COMPLETED. Ref: " + chosen.getPaymentReference());
        } catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    private void allPaymentsMenu() {
        print("\n-- All Payments --");
        print("  1. Payments received from customers (premiums)");
        print("  2. Payments released to customers (claim payouts)");
        print("  3. View all");
        print("  0. Back");
        switch (readChoice(3)) {
            case 1 -> { print("\n--- Premiums Received ---"); printPaymentTable(paymentService.findByType("PREMIUM_RECEIVED")); }
            case 2 -> { print("\n--- Claim Payouts Released to Customers ---");
                List<Payment> released = paymentService.findByType("CLAIM_PAYOUT").stream().filter(p -> "COMPLETED".equals(p.getStatus())).toList();
                printPaymentTable(released); }
            case 3 -> { print("\n--- All Payments ---"); printPaymentTable(paymentService.findAll()); }
        }
    }

    private void showFinanceSummary() {
        print("\n+= FINANCE SUMMARY =========================================+");
        try {
            Map<String, BigDecimal> summary = paymentService.getFinanceSummary();
            BigDecimal credited   = summary.get("totalCredited");
            BigDecimal settled    = summary.get("totalSettled");
            BigDecimal pct        = summary.get("settlementPercent");
            BigDecimal netBalance = credited.subtract(settled);
            print("|  Total Premiums Credited  : " + pad(formatINR(credited), 27) + "|");
            print("|  Total Claims Settled     : " + pad(formatINR(settled), 27) + "|");
            print("|  Net Balance              : " + pad(formatINR(netBalance), 27) + "|");
            print("|  Claims Settlement %      : " + pad(pct + "%", 27) + "|");
        } catch (Exception e) {
            print("|  Error loading summary: " + e.getMessage());
        }
        print("+============================================================+");
        print("\n  Approved claims awaiting payout:");
        List<Claim> approved = claimService.findByStatus("APPROVED");
        if (approved.isEmpty()) print("  None pending.");
        else {
            printClaimTable(approved);
            print("\n  To create a payout for an approved claim:");
            print("  1. Create Payout Record for Approved Claim");
            print("  0. Back");
            if (readChoice(1) == 1) createClaimPayout(approved);
        }
    }

    private void createClaimPayout(List<Claim> approved) {
        printNumberedClaimList(approved);
        int idx = readChoiceInRange("Select claim to create payout (0 to cancel): ", 0, approved.size()) - 1;
        if (idx < 0) return;
        Claim chosen = approved.get(idx);
        String customerName = userDao.findFullNameById(chosen.getCustomerId());
        print("  Claim      : " + chosen.getClaimReference());
        print("  Customer   : " + customerName);
        print("  Approved   : " + formatINR(chosen.getApprovedAmount()));
        print("  1. Create Payout Record   2. Cancel");
        if (readChoice(2) != 1) return;
        try {
            Payment payout = paymentService.processClaimPayout(
                    chosen.getPolicyId(), chosen.getId(),
                    chosen.getApprovedAmount(), CURRENCY);
            print("[OK] Payout record created! Ref: " + payout.getPaymentReference());
            print("[OK] Use 'Mark Payment Completed' -> 'Settled claim payout' to mark it done.");
        } catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    // =========================================================================
    // AGENT PORTAL
    // =========================================================================
    private void agentPortal() {
        boolean active = true;
        while (active) {
            print("\n+=== AGENT PORTAL ======================================+");
            print("|  Agent   : " + pad(safe(session.getFullName()), 43) + "|");
            print("|  Email   : " + pad(safe(session.getEmail()), 43) + "|");
            print("+=======================================================+");
            print("|  1. Search Customer (by name or email)                |");
            print("|  2. Create New Customer                               |");
            print("|  3. Create Policy for Customer                        |");
            print("|  4. View All Policies                                 |");
            print("|  0. Logout                                            |");
            print("+=======================================================+");
            switch (readChoice(4)) {
                case 1 -> agentSearchCustomer();
                case 2 -> agentCreateCustomer();
                case 3 -> createPolicyForCustomer();
                case 4 -> { printPolicyTable(policyService.findAll()); }
                case 0 -> { session = null; active = false; print("Logged out."); }
            }
        }
    }

    private void agentSearchCustomer() {
        print("\n-- Search Customer --");
        String term = readNonBlank("Enter name or email (partial is fine, e.g. 'mani'): ").trim();
        List<User> results = userDao.findByNameOrEmail(term).stream()
                .filter(u -> "CUSTOMER".equals(u.getRole())).toList();
        if (results.isEmpty()) { print("No customers found matching '" + term + "'."); return; }
        print("\nFound " + results.size() + " customer(s):");
        print(row("#",4) + row("Full Name",25) + row("Email",35) + row("Mobile",16) + "Status");
        print("-".repeat(88));
        for (int i = 0; i < results.size(); i++) {
            User u = results.get(i);
            print(row(String.valueOf(i+1),4) + row(safe(u.getFullName()),25) +
                  row(u.getEmail(),35) + row(safe(u.getMobile()),16) + safe(u.getStatus()));
        }
        print("\n  1. View this customer's policies");
        print("  0. Back");
        if (readChoice(1) == 0) return;
        int sel = readChoiceInRange("Select customer number: ", 1, results.size()) - 1;
        User selected = results.get(sel);
        print("\n  Customer: " + safe(selected.getFullName()) + " | " + selected.getEmail());
        List<Policy> policies = policyService.findByCustomerId(selected.getId());
        if (policies.isEmpty()) print("  No policies for this customer.");
        else printPolicyTable(policies);
    }

    private void agentCreateCustomer() {
        print("\n-- Create New Customer --");
        print("  A default password will be generated. Share credentials with the customer.");
        String fullName = readNonBlank("Customer Full Name: ").trim();
        if (fullName.length() < 2 || !fullName.matches("[a-zA-Z .'\\-]+")) {
            print("Name invalid."); return;
        }
        String email = readNonBlank("Customer Email: ").trim().toLowerCase();
        if (!isValidEmail(email)) { print("Invalid email."); return; }
        if (email.endsWith("@policypilot.com")) { print("Customers cannot use @policypilot.com."); return; }
        if (userService.findByEmail(email) != null) { print("Account already exists with this email."); return; }
        String mobile = readMobile();
        // Ask age for the new customer
        int cAge = 0;
        while (true) {
            System.out.print("Customer Age: ");
            try {
                cAge = Integer.parseInt(scanner.nextLine().trim());
                if (cAge < 18) { print("Must be at least 18 to register."); continue; }
                if (cAge > 120) { print("Invalid age."); continue; }
                break;
            } catch (NumberFormatException e) { print("Invalid age. Enter a number."); }
        }
        // Generate username from name + random 3 digits
        String baseUsername = fullName.trim().toLowerCase()
                .replaceAll("[^a-z0-9]","_")
                .replaceAll("_+","_");
        if (baseUsername.length() > 15) baseUsername = baseUsername.substring(0, 15);
        String username = baseUsername + "_" + (100 + (int)(Math.random() * 900));
        String defaultPassword = "Welcome@7205"; // Fixed default password for all agent-created customers
        try {
            User newUser = userService.registerUser(
                    new UserDto(username, email, mobile, fullName, defaultPassword, "CUSTOMER", cAge, true));
            print("\n+-- NEW CUSTOMER CREATED --------------------------+");
            print("|  Full Name : " + pad(safe(newUser.getFullName()),41) + "|");
            print("|  Username  : " + pad(username, 41) + "|");
            print("|  Email     : " + pad(email, 41) + "|");
            print("|  Password  : " + pad(defaultPassword, 41) + "|");
            print("|  Role      : CUSTOMER                               |");
            print("|  Status    : ACTIVE                                 |");
            print("+-----------------------------------------------------+");
            print("  Share these credentials with the customer.");
            print("  They should change their password after first login.");
        } catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    private void createPolicyForCustomer() {
        print("\n-- Create Policy for Customer --");
        String term = readNonBlank("Search customer by name or email: ").trim();
        List<User> results = userDao.findByNameOrEmail(term).stream()
                .filter(u -> "CUSTOMER".equals(u.getRole()) && "ACTIVE".equals(u.getStatus())).toList();
        if (results.isEmpty()) { print("No active customers found matching '" + term + "'."); return; }
        print("\nFound:");
        for (int i = 0; i < results.size(); i++)
            print("  " + (i+1) + ". " + safe(results.get(i).getFullName()) + " (" + results.get(i).getEmail() + ")");
        int sel = readChoiceInRange("Select customer (0 to cancel): ", 0, results.size()) - 1;
        if (sel < 0) return;
        User customer = results.get(sel);
        print("Customer: " + safe(customer.getFullName()));
        List<Plan> plans = planService.getActivePlans();
        if (plans.isEmpty()) { print("No active plans."); return; }
        showPlanCards(plans);
        int planIdx = readChoiceInRange("Select plan (0 to cancel): ", 0, plans.size()) - 1;
        if (planIdx < 0) return;
        Plan selectedPlan = plans.get(planIdx);
        print("Select Destination:");
        for (String[] d : DESTINATIONS) print("  " + d[0] + ". " + d[1]);
        int destChoice = readChoiceInRange("Destination: ", 1, DESTINATIONS.length);
        String destCode = DESTINATIONS[destChoice-1][2];
        LocalDate start = readDate("Trip Start (YYYY-MM-DD): ");
        if (start == null) return;
        if (start.isBefore(LocalDate.now())) { print("Past date not allowed."); return; }
        LocalDate end = readDate("Trip End   (YYYY-MM-DD): ");
        if (end == null) return;
        if (end.isBefore(start)) { print("End before start."); return; }
        int travelers = readPositiveInt("Travelers (1-" + selectedPlan.getMaxTravelers() + "): ");
        if (travelers > selectedPlan.getMaxTravelers()) { print("Exceeds plan max."); return; }
        print("Purpose:  1. LEISURE   2. BUSINESS");
        String purpose = readChoice(2) == 2 ? "BUSINESS" : "LEISURE";
        try {
            PolicyDto dto = new PolicyDto(customer.getId(), selectedPlan.getId(), destCode,
                    start, end, travelers, purpose, CURRENCY, new ArrayList<>());
            Policy policy = policyService.createPolicy(dto);
            print("\n[OK] Policy " + policy.getPolicyNumber() + " created for " + safe(customer.getFullName()));
            print("     Premium : " + formatINR(policy.getTotalPremium()));
            print("     Status  : " + policy.getStatus());
            if ("PENDING_UW".equals(policy.getStatus())) {
                print("     [!] High risk - sent for underwriter review.");
            } else if ("QUOTED".equals(policy.getStatus())) {
                print("\n     Payment options:");
                print("     1. Pay Now - confirm payment & activate immediately");
                print("     2. Leave as QUOTED - customer can pay on their own login");
                int payNow = readChoiceInRange("     Choice (1-2): ", 1, 2);
                if (payNow == 1) {
                    try {
                        Payment pmnt = paymentService.processPayment(policy.getId(), policy.getTotalPremium(), "INR");
                        paymentService.completePayment(pmnt.getId());
                        policyService.activatePolicy(policy.getId());
                        print("[OK] Payment confirmed! Ref: " + pmnt.getPaymentReference());
                        print("[OK] Policy is now ACTIVE.");
                    } catch (Exception pe) { print("Payment error: " + pe.getMessage()); }
                } else {
                    print("[OK] Policy saved as QUOTED. Customer can pay via their login.");
                }
            }
        } catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    // =========================================================================
    // RELATIONSHIP MANAGER PORTAL
    // =========================================================================
    private void rmPortal() {
        boolean active = true;
        while (active) {
            print("\n+=== RELATIONSHIP MANAGER PORTAL =======================+");
            print("|  RM      : " + pad(safe(session.getFullName()), 43) + "|");
            print("|  Email   : " + pad(safe(session.getEmail()), 43) + "|");
            print("+=======================================================+");
            print("|  1. All Customers                                     |");
            print("|  2. Search Customer (name or email)                   |");
            print("|  3. View Customer Policies                            |");
            print("|  4. View Customer Claims                              |");
            print("|  5. View All Policies                                 |");
            print("|  0. Logout                                            |");
            print("+=======================================================+");
            switch (readChoice(5)) {
                case 1 -> rmShowAllCustomers();
                case 2 -> rmSearchCustomer();
                case 3 -> viewCustomerPolicies();
                case 4 -> viewCustomerClaims();
                case 5 -> { printPolicyTable(policyService.findAll()); }
                case 0 -> { session = null; active = false; print("Logged out."); }
            }
        }
    }


    private void rmShowAllCustomers() {
        print("\n-- All Customers --");
        List<User> customers = userDao.findByRole("CUSTOMER");
        if (customers.isEmpty()) { print("No customers registered."); return; }
        print(row("#",4) + row("Full Name",25) + row("Email",35) + row("Mobile",12) + row("Age",5) + "Status");
        print("-".repeat(88));
        for (int i = 0; i < customers.size(); i++) {
            User u = customers.get(i);
            print(row(String.valueOf(i+1),4) + row(safe(u.getFullName()),25) +
                  row(u.getEmail(),35) + row(safe(u.getMobile()),12) +
                  row(String.valueOf(u.getAge()),5) + safe(u.getStatus()));
        }
        print("Total customers: " + customers.size());
    }

    private void rmSearchCustomer() {
        print("\n-- Search Customer --");
        String term = readNonBlank("Enter name or email (e.g. 'mani' matches 'Hari Mani Kumar'): ").trim();
        List<User> results = userDao.findByNameOrEmail(term).stream()
                .filter(u -> "CUSTOMER".equals(u.getRole())).toList();
        if (results.isEmpty()) { print("No customers found for '" + term + "'."); return; }
        print(row("#",4) + row("Full Name",25) + row("Email",35) + row("Mobile",16) + "Status");
        print("-".repeat(88));
        for (int i = 0; i < results.size(); i++) {
            User u = results.get(i);
            print(row(String.valueOf(i+1),4) + row(safe(u.getFullName()),25) +
                  row(u.getEmail(),35) + row(safe(u.getMobile()),16) + safe(u.getStatus()));
        }
    }

    private void viewCustomerPolicies() {
        String term = readNonBlank("Search customer by name or email: ").trim();
        List<User> results = userDao.findByNameOrEmail(term).stream()
                .filter(u -> "CUSTOMER".equals(u.getRole())).toList();
        if (results.isEmpty()) { print("No customers found."); return; }
        User customer = pickFromList(results);
        if (customer == null) return;
        print("Customer: " + safe(customer.getFullName()) + " | " + customer.getEmail());
        List<Policy> policies = policyService.findByCustomerId(customer.getId());
        if (policies.isEmpty()) print("No policies for this customer.");
        else printPolicyTable(policies);
    }

    private void viewCustomerClaims() {
        String term = readNonBlank("Search customer by name or email: ").trim();
        List<User> results = userDao.findByNameOrEmail(term).stream()
                .filter(u -> "CUSTOMER".equals(u.getRole())).toList();
        if (results.isEmpty()) { print("No customers found."); return; }
        User customer = pickFromList(results);
        if (customer == null) return;
        print("Customer: " + safe(customer.getFullName()) + " | " + customer.getEmail());
        List<Claim> claims = claimService.findByCustomerId(customer.getId());
        if (claims.isEmpty()) print("No claims for this customer.");
        else printClaimTable(claims);
    }

    private User pickFromList(List<User> users) {
        if (users.size() == 1) return users.get(0);
        print("Multiple matches found:");
        for (int i = 0; i < users.size(); i++)
            print("  " + (i+1) + ". " + safe(users.get(i).getFullName()) + " (" + users.get(i).getEmail() + ")");
        int idx = readChoiceInRange("Select (0 to cancel): ", 0, users.size()) - 1;
        return idx < 0 ? null : users.get(idx);
    }

    // =========================================================================
    // IAM ADMIN PORTAL
    // =========================================================================
    private void iamAdminPortal() {
        boolean active = true;
        while (active) {
            print("\n+=== IAM ADMIN PORTAL ==================================+");
            print("|  Admin   : " + pad(safe(session.getFullName()), 43) + "|");
            print("|  Email   : " + pad(safe(session.getEmail()), 43) + "|");
            print("+=======================================================+");
            print("|  1. Create Staff User                                 |");
            print("|  2. View All Staff Users                              |");
            print("|  0. Logout                                            |");
            print("+=======================================================+");
            switch (readChoice(2)) {
                case 1 -> iamCreateStaffUser();
                case 2 -> iamViewAllStaff();
                case 0 -> { session = null; active = false; print("Logged out."); }
            }
        }
    }

    private void iamCreateStaffUser() {
        print("\n-- Create Staff User --");
        print("  Select role to create:");
        String[][] roles = {
            {"1","UW_OFFICER",      "Underwriter"},
            {"2","CLAIMS_OFFICER",  "Claims Officer"},
            {"3","AGENT",           "Agent"},
            {"4","FINANCE_OFFICER", "Finance Officer"},
            {"5","RM",              "Relationship Manager"},
            {"6","FIELD_OFFICER",   "Field Officer"},
        };
        for (String[] r : roles) print("  " + r[0] + ". " + r[2]);
        print("  0. Cancel");
        int roleChoice = readChoice(6);
        if (roleChoice == 0) return;
        String selectedRole  = roles[roleChoice-1][1];
        String selectedLabel = roles[roleChoice-1][2];
        print("\n  Creating: " + selectedLabel + " (" + selectedRole + ")");
        String fullName = readNonBlank("Full Name: ").trim();
        if (fullName.length() < 2 || !fullName.matches("[a-zA-Z .'\\-]+")) {
            print("Invalid name."); return;
        }
        // Auto-generate email from name and role
        String roleShort = selectedRole.toLowerCase().replace("_officer","").replace("_admin","");
        String nameSlug = fullName.trim().toLowerCase().split("\\s+")[0]; // first name
        String email = nameSlug + "." + roleShort + "@policypilot.com";
        // If taken, try name1.role, name2.role etc.
        int suffix = 1;
        while (userService.findByEmail(email) != null) {
            email = nameSlug + suffix + "." + roleShort + "@policypilot.com";
            suffix++;
        }
        print("  Auto-assigned email: " + email);
        String mobile = readNonBlank("Mobile (+91XXXXXXXXXX): ").trim();
        if (!mobile.matches("[0-9]{10}")) { print("Invalid mobile. Enter exactly 10 digits (e.g. 9876543210)."); return; }
        String baseUsername = fullName.trim().toLowerCase()
                .replaceAll("[^a-z0-9]","_").replaceAll("_+","_");
        if (baseUsername.length() > 12) baseUsername = baseUsername.substring(0, 12);
        String username = baseUsername + "_" + selectedRole.toLowerCase().replace("_","");
        print("\n  Password Requirements: min 8 chars, 1 uppercase, 1 lowercase, 1 digit, 1 special char");
        String password = null;
        while (true) {
            System.out.print("Set Password: ");
            String pwd = scanner.nextLine().trim();
            if (isValidStaffPassword(pwd)) { password = pwd; break; }
            print("  Password too weak. Must be 8+ chars with: uppercase letter, lowercase letter, digit, special character (!@#$% etc.).");
            print("  Please try again.");
        }
        print("  1. Confirm Create   2. Cancel");
        if (readChoice(2) != 1) return;
        try {
            User newUser = userService.registerUser(
                    new UserDto(username, email, mobile, fullName, password, selectedRole));
            print("\n+-- NEW STAFF USER CREATED ----------------------------+");
            print("|  Full Name : " + pad(safe(newUser.getFullName()), 41) + "|");
            print("|  Username  : " + pad(username, 41) + "|");
            print("|  Email     : " + pad(email, 41) + "|");
            print("|  Password  : " + pad(password, 41) + "|");
            print("|  Role      : " + pad(selectedRole, 41) + "|");
            print("|  Status    : ACTIVE                                  |");
            print("+------------------------------------------------------+");
            print("  Share these credentials securely with the staff member.");
        } catch (Exception e) { print("Failed: " + e.getMessage()); }
    }

    private void iamViewAllStaff() {
        print("\n-- All Staff Users --");
        List<User> all = userDao.findAll();
        List<User> staff = all.stream()
                .filter(u -> !"CUSTOMER".equals(u.getRole()))
                .toList();
        if (staff.isEmpty()) { print("No staff users found."); return; }
        print(row("#",4) + row("Full Name",22) + row("Role",18) + row("Email",38) + "Status");
        print("-".repeat(90));
        for (int i = 0; i < staff.size(); i++) {
            User u = staff.get(i);
            print(row(String.valueOf(i+1),4) + row(safe(u.getFullName()),22) +
                  row(safe(u.getRole()),18) + row(u.getEmail(),38) + safe(u.getStatus()));
        }
        print("Total staff: " + staff.size());
    }

    // =========================================================================
    // DISPLAY TABLES
    // =========================================================================
    private void printPolicyTable(List<Policy> policies) {
        if (policies.isEmpty()) { print("No policies to display."); return; }
        print("\n" + row("Policy No.",20) + row("Customer",20) + row("Status",14) +
              row("Trip Period",24) + row("Premium",15) + "Dest");
        print("-".repeat(97));
        for (Policy p : policies) {
            String custName = userDao.findFullNameById(p.getCustomerId());
            print(row(p.getPolicyNumber(),20) + row(custName,20) +
                  row(safe(p.getStatus()),14) +
                  row(p.getTripStartDate() + " to " + p.getTripEndDate(),24) +
                  row(formatINR(p.getTotalPremium()),15) +
                  safe(p.getDestinationCountryCode()));
        }
        print("Total: " + policies.size());
    }

    private void printNumberedPolicyList(List<Policy> policies) {
        print("\n" + row("#",4) + row("Policy No.",20) + row("Customer",20) +
              row("Risk",8) + row("Premium",15) + "Status");
        print("-".repeat(75));
        for (int i = 0; i < policies.size(); i++) {
            Policy p = policies.get(i);
            String custName = userDao.findFullNameById(p.getCustomerId());
            print(row(String.valueOf(i+1),4) + row(p.getPolicyNumber(),20) +
                  row(custName,20) + row(safe(p.getRiskLevel()),8) +
                  row(formatINR(p.getTotalPremium()),15) + safe(p.getStatus()));
        }
    }

    private void printClaimTable(List<Claim> claims) {
        if (claims.isEmpty()) { print("No claims to display."); return; }
        print("\n" + row("Claim Ref",20) + row("Customer",20) + row("Status",16) +
              row("Approx Value",14) + row("Priority",10) + "Incident");
        print("-".repeat(88));
        for (Claim c : claims) {
            String custName = userDao.findFullNameById(c.getCustomerId());
            print(row(c.getClaimReference(),20) + row(custName,20) +
                  row(safe(c.getStatus()),16) + row(formatINR(c.getClaimedAmount()),14) +
                  String.valueOf(c.getIncidentDate()));
        }
        print("Total: " + claims.size());
    }

    private void printNumberedClaimList(List<Claim> claims) {
        print("\n" + row("#",4) + row("Claim Ref",20) + row("Customer",20) +
              row("Status",16) + row("Approx Value",14) + "Incident");
        print("-".repeat(80));
        for (int i = 0; i < claims.size(); i++) {
            Claim c = claims.get(i);
            String custName = userDao.findFullNameById(c.getCustomerId());
            print(row(String.valueOf(i+1),4) + row(c.getClaimReference(),20) +
                  row(custName,20) + row(safe(c.getStatus()),16) +
                  row(formatINR(c.getClaimedAmount()),14) + c.getIncidentDate());
        }
    }

    private void printPaymentTable(List<Payment> payments) {
        if (payments.isEmpty()) { print("No payments to display."); return; }
        print("\n" + row("Reference",24) + row("Type",18) + row("Status",12) +
              row("Amount",15) + "Paid At");
        print("-".repeat(85));
        for (Payment p : payments) {
            String typeLabel = "PREMIUM_RECEIVED".equals(p.getPaymentType())
                    ? "Premium" : "CLAIM_PAYOUT".equals(p.getPaymentType()) ? "Claim Payout" : safe(p.getPaymentType());
            print(row(p.getPaymentReference(),24) + row(typeLabel,18) +
                  row(safe(p.getStatus()),12) + row(formatINR(p.getAmount()),15) +
                  (p.getPaidAt() != null ? safeDate(p.getPaidAt().toString()) : "-"));
        }
        print("Total: " + payments.size());
    }

    private void printNumberedPaymentList(List<Payment> payments) {
        print("\n" + row("#",4) + row("Reference",24) + row("Type",16) + row("Amount",15) + "Status");
        print("-".repeat(65));
        for (int i = 0; i < payments.size(); i++) {
            Payment p = payments.get(i);
            String typeLabel = "PREMIUM_RECEIVED".equals(p.getPaymentType()) ? "Premium" : "Claim Payout";
            print(row(String.valueOf(i+1),4) + row(p.getPaymentReference(),24) +
                  row(typeLabel,16) + row(formatINR(p.getAmount()),15) + safe(p.getStatus()));
        }
    }

    private void printClaimDetail(Claim c) {
        String custName = userDao.findFullNameById(c.getCustomerId());
        print("\n+- Claim Detail -------------------------------------------");
        print("| Reference        : " + c.getClaimReference());
        print("| Customer         : " + custName);
        print("| Status           : " + safe(c.getStatus()));
        print("| Incident Date    : " + c.getIncidentDate());
        print("| Description      : " + safe(c.getIncidentDescription()));
        print("| Approx Claim Val : " + formatINR(c.getClaimedAmount()));
        print("| Settlement Amt   : " + (c.getApprovedAmount() != null
                ? formatINR(c.getApprovedAmount()) : "Pending decision"));
        print("| High Value       : " + (c.isHighValue() ? "YES" : "No"));
        print("| Field Invest.    : " + (c.isFieldInvestigationRequired() ? "YES" : "No"));
        if (c.getAssignedOfficerId() != null)
            print("| Field Officer    : " + userDao.findFullNameById(c.getAssignedOfficerId()));
        if (c.getDecisionReason() != null)
            print("| Decision Reason  : " + c.getDecisionReason());
        print("+----------------------------------------------------------");
    }

    // =========================================================================
    // INPUT HELPERS
    // =========================================================================
    private int readChoice(int max) {
        while (true) {
            System.out.print("Your choice (0-" + max + "): ");
            try {
                int n = Integer.parseInt(scanner.nextLine().trim());
                if (n >= 0 && n <= max) return n;
                print("Enter 0-" + max + ".");
            } catch (NumberFormatException e) { print("Invalid input."); }
        }
    }

    private int readChoiceInRange(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            try {
                int n = Integer.parseInt(scanner.nextLine().trim());
                if (n >= min && n <= max) return n;
                print("Enter " + min + "-" + max + ".");
            } catch (NumberFormatException e) { print("Invalid input."); }
        }
    }

    private String readNonBlank(String prompt) {
        while (true) {
            System.out.print(prompt);
            String val = scanner.nextLine().trim();
            if (!val.isBlank()) return val;
            print("This field cannot be empty.");
        }
    }


    /** Returns null after 3 failed attempts, LocalDate.MIN if user typed BACK, or the parsed date */
    private LocalDate readDateOrBack(String prompt) {
        for (int i = 0; i < 3; i++) {
            System.out.print(prompt);
            String val = scanner.nextLine().trim();
            if (val.equalsIgnoreCase("BACK") || val.equalsIgnoreCase("B") || val.equals("0")) {
                return LocalDate.MIN;
            }
            try { return LocalDate.parse(val); }
            catch (DateTimeParseException e) {
                print("Invalid date. Use YYYY-MM-DD (e.g. 2026-08-15). Attempt " + (i+1) + " of 3.");
            }
        }
        print("Too many invalid attempts.");
        return null;
    }

    private LocalDate readDate(String prompt) {
        for (int i = 0; i < 3; i++) {
            System.out.print(prompt);
            try { return LocalDate.parse(scanner.nextLine().trim()); }
            catch (DateTimeParseException e) {
                print("Invalid date. Use YYYY-MM-DD (e.g. 2026-08-15). Attempt " + (i+1) + " of 3.");
            }
        }
        print("Too many invalid attempts.");
        return null;
    }

    private int readPositiveInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                int n = Integer.parseInt(scanner.nextLine().trim());
                if (n > 0) return n;
                print("Must be greater than 0.");
            } catch (NumberFormatException e) { print("Invalid number."); }
        }
    }

    private BigDecimal readPositiveDecimal(String prompt) {
        for (int i = 0; i < 3; i++) {
            System.out.print(prompt);
            try {
                BigDecimal bd = new BigDecimal(scanner.nextLine().trim());
                if (bd.compareTo(BigDecimal.ZERO) > 0) return bd;
                print("Amount must be greater than zero.");
            } catch (NumberFormatException e) { print("Invalid amount."); }
        }
        print("Too many attempts.");
        return null;
    }

    private BigDecimal readDecimalMax(String prompt, BigDecimal max) {
        for (int i = 0; i < 3; i++) {
            System.out.print(prompt);
            try {
                BigDecimal bd = new BigDecimal(scanner.nextLine().trim());
                if (bd.compareTo(BigDecimal.ZERO) < 0) { print("Cannot be negative."); continue; }
                if (bd.compareTo(max) > 0) { print("Cannot exceed " + formatINR(max) + "."); continue; }
                return bd;
            } catch (NumberFormatException e) { print("Invalid amount."); }
        }
        print("Too many attempts.");
        return null;
    }

    // =========================================================================
    // VALIDATION & FORMAT HELPERS
    // =========================================================================
    private boolean isValidEmail(String email) {
        if (email == null || email.isBlank()) return false;
        int atIdx = email.indexOf('@');
        if (atIdx <= 0 || atIdx != email.lastIndexOf('@')) return false;
        String domain = email.substring(atIdx + 1);
        if (!domain.contains(".") || domain.startsWith(".") || domain.endsWith(".") || domain.contains("..")) return false;
        return domain.split("\\.")[domain.split("\\.").length-1].length() >= 2;
    }

    private boolean isValidPassword(String p) {
        if (p == null || p.length() < 6) return false;
        boolean hasL = false, hasD = false;
        for (char c : p.toCharArray()) {
            if (Character.isLetter(c)) hasL = true;
            if (Character.isDigit(c)) hasD = true;
        }
        return hasL && hasD;
    }

    private boolean isValidStaffPassword(String p) {
        if (p == null || p.length() < 8) return false;
        boolean hasUpper = false, hasLower = false, hasDigit = false, hasSpecial = false;
        for (char c : p.toCharArray()) {
            if (Character.isUpperCase(c)) hasUpper = true;
            if (Character.isLowerCase(c)) hasLower = true;
            if (Character.isDigit(c)) hasDigit = true;
            if ("!@#$%^&*()_+-=[]{}|;':\",./<>?".indexOf(c) >= 0) hasSpecial = true;
        }
        return hasUpper && hasLower && hasDigit && hasSpecial;
    }

    private String formatINR(BigDecimal amount) {
        if (amount == null) return "INR -";
        long paise = amount.multiply(new BigDecimal("100")).longValue();
        long rupees = paise / 100;
        long dec = paise % 100;
        return "INR " + formatIndianNumber(rupees) + "." + String.format("%02d", dec);
    }

    private String formatIndianNumber(long n) {
        if (n < 0) return "-" + formatIndianNumber(-n);
        if (n < 1000) return String.valueOf(n);
        String s = String.valueOf(n);
        int len = s.length();
        StringBuilder result = new StringBuilder(s.substring(len - 3));
        int remaining = len - 3;
        while (remaining > 0) {
            int start = Math.max(0, remaining - 2);
            result.insert(0, ",").insert(0, s.substring(start, remaining));
            remaining = start;
        }
        return result.toString();
    }


    /** Reads a 10-digit mobile number, re-asks on invalid input */
    private String readMobile() {
        while (true) {
            System.out.print("Mobile Number (10 digits, e.g. 9876543210): ");
            String val = scanner.nextLine().trim();
            // Strip +91 or 91 prefix if entered
            if (val.startsWith("+91") && val.length() == 13) val = val.substring(3);
            else if (val.startsWith("91") && val.length() == 12) val = val.substring(2);
            if (val.matches("[0-9]{10}")) return val;
            print("Invalid mobile. Enter exactly 10 digits without country code (e.g. 9876543210).");
        }
    }


    /** Safe substring of date string - avoids index out of bounds */
    private String safeDate(String dateStr) {
        if (dateStr == null) return "-";
        return dateStr.length() >= 19 ? dateStr.substring(0, 19) : dateStr;
    }

    private void print(String msg) { System.out.println(msg); }
    private String safe(String v)  { return v != null ? v : "-"; }

    private String row(String value, int width) {
        if (value == null) value = "-";
        return value.length() >= width
                ? value.substring(0, width - 1) + " "
                : String.format("%-" + width + "s", value);
    }

    private String pad(String value, int width) {
        if (value == null) value = "";
        return value.length() >= width
                ? value.substring(0, width)
                : String.format("%-" + width + "s", value);
    }
}
