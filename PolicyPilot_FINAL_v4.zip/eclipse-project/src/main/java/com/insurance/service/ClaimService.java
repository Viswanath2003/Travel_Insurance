package com.insurance.service;

import com.insurance.dto.ClaimDto;
import com.insurance.entity.Claim;
import java.math.BigDecimal;
import java.util.List;

public interface ClaimService {
    Claim submitClaim(ClaimDto dto);
    Claim findByClaimReference(String claimReference);
    List<Claim> findByPolicyId(String policyId);
    List<Claim> findAll();
    List<Claim> findByCustomerId(String customerId);
    List<Claim> findByStatus(String status);
    List<Claim> findByAssignedOfficerId(String officerId);
    void approveClaim(String claimId, BigDecimal approvedAmount, String officerId);
    void rejectClaim(String claimId, String reason, String officerId);
    void updateStatus(String claimId, String newStatus);
    void assignFieldOfficer(String claimId, String fieldOfficerId);
    void submitFieldFindings(String claimId, String outcome, String fieldOfficerId);
    Claim findById(String claimId);
}
