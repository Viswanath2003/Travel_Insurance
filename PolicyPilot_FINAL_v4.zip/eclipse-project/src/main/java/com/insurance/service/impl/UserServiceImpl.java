package com.insurance.service.impl;

import com.insurance.dao.UserDao;
import com.insurance.dao.impl.UserDaoImpl;
import com.insurance.dto.UserDto;
import com.insurance.entity.User;
import com.insurance.service.UserService;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

public class UserServiceImpl implements UserService {

    private final UserDao userDao;

    public UserServiceImpl() {
        this.userDao = new UserDaoImpl();
    }

    public UserServiceImpl(UserDao userDao) {
        this.userDao = userDao;
    }

    @Override
    public User registerUser(UserDto dto) {
        if (dto.getEmail() == null || dto.getEmail().isBlank())
            throw new IllegalArgumentException("Email is required");
        if (dto.getUsername() == null || dto.getUsername().isBlank())
            throw new IllegalArgumentException("Username is required");

        User existing = userDao.findByEmail(dto.getEmail());
        if (existing != null)
            throw new IllegalStateException("A user with email '" + dto.getEmail() + "' already exists");

        User user = new User();
        user.setId(UUID.randomUUID().toString());
        user.setUsername(dto.getUsername());
        user.setEmail(dto.getEmail());
        user.setMobile(dto.getMobile());
        user.setFullName(dto.getFullName());
        user.setPasswordHash(dto.getPasswordHash());
        user.setRole(dto.getRole() != null ? dto.getRole() : "CUSTOMER");
        user.setStatus("ACTIVE");
        user.setAge(dto.getAge());
        user.setDefaultPassword(dto.isDefaultPassword());
        user.setFailedLoginAttempts(0);
        user.setEmailVerified(false);
        user.setMobileVerified(false);
        user.setCreatedAt(OffsetDateTime.now());
        user.setUpdatedAt(OffsetDateTime.now());
        user.setVersion(1L);

        userDao.save(user);
        return user;
    }

    @Override
    public User findByEmail(String email) {
        return userDao.findByEmail(email);
    }

    @Override
    public User findById(String id) {
        return userDao.findById(id);
    }

    @Override
    public List<User> findAll() {
        return userDao.findAll();
    }

    @Override
    public void updateStatus(String userId, String newStatus) {
        User user = userDao.findById(userId);
        if (user == null)
            throw new IllegalArgumentException("User not found: " + userId);

        List<String> validStatuses = List.of("ACTIVE", "INACTIVE", "SUSPENDED", "LOCKED");
        if (!validStatuses.contains(newStatus))
            throw new IllegalArgumentException("Invalid status: " + newStatus +
                    ". Must be one of: " + validStatuses);

        user.setStatus(newStatus);
        userDao.update(user);
    }
}
