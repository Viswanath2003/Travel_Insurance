package com.insurance.service;

import com.insurance.entity.Plan;
import java.util.List;

public interface PlanService {
    List<Plan> getActivePlans();
    Plan findById(String id);
}
