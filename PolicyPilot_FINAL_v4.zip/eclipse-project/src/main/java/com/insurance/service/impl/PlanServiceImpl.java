package com.insurance.service.impl;

import com.insurance.dao.PlanDao;
import com.insurance.dao.impl.PlanDaoImpl;
import com.insurance.entity.Plan;
import com.insurance.service.PlanService;

import java.util.List;

public class PlanServiceImpl implements PlanService {

    private final PlanDao planDao;

    public PlanServiceImpl() {
        this.planDao = new PlanDaoImpl();
    }

    public PlanServiceImpl(PlanDao planDao) {
        this.planDao = planDao;
    }

    @Override
    public List<Plan> getActivePlans() {
        return planDao.findByStatus("ACTIVE");
    }

    @Override
    public Plan findById(String id) {
        if (id == null || id.isBlank())
            throw new IllegalArgumentException("Plan ID is required");
        return planDao.findById(id);
    }
}
