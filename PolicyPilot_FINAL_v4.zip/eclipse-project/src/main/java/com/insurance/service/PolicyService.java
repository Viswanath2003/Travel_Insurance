package com.insurance.service;

import com.insurance.dto.PolicyDto;
import com.insurance.entity.Policy;
import java.util.List;

public interface PolicyService {
    Policy createPolicy(PolicyDto dto);
    Policy findByPolicyNumber(String policyNumber);
    List<Policy> findByCustomerId(String customerId);
    List<Policy> findAll();
    List<Policy> findByStatus(String status);
    void cancelPolicy(String policyId);
    void cancelPolicy(String policyId, String reason);
    void activatePolicy(String policyId);
    void rejectPolicy(String policyId, String reason);
    void saveAsQuote(String policyId);
}
