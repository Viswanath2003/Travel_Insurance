package com.insurance.service;

import com.insurance.entity.Payment;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public interface PaymentService {
    // Premium payments (customer -> company)
    Payment processPayment(String policyId, BigDecimal amount, String currency);
    void completePayment(String paymentId);

    // Claim payout (company -> customer)
    Payment processClaimPayout(String policyId, String claimId, BigDecimal amount, String currency);
    void completeClaimPayout(String paymentId);
    Payment autoCreateClaimPayout(String policyId, String claimId, BigDecimal amount, String currency);

    // Queries
    Payment findById(String id);
    List<Payment> findAll();
    List<Payment> findByPolicyId(String policyId);
    List<Payment> findByStatus(String status);
    List<Payment> findByType(String paymentType);
    List<Payment> findByClaimId(String claimId);

    // Finance summary: totalCredited, totalSettled, settlementPercent
    Map<String, BigDecimal> getFinanceSummary();
}
