package com.insurance.service.impl;

import com.insurance.dao.PolicyDao;
import com.insurance.dao.PlanDao;
import com.insurance.dao.UnderwritingCaseDao;
import com.insurance.dao.impl.PolicyDaoImpl;
import com.insurance.dao.impl.PlanDaoImpl;
import com.insurance.dao.impl.UnderwritingCaseDaoImpl;
import com.insurance.dto.PolicyDto;
import com.insurance.entity.Plan;
import com.insurance.entity.Policy;
import com.insurance.entity.UnderwritingCase;
import com.insurance.service.PolicyService;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

public class PolicyServiceImpl implements PolicyService {

    private final PolicyDao policyDao;
    private final PlanDao planDao;
    private final UnderwritingCaseDao uwCaseDao;

    public PolicyServiceImpl() {
        this.policyDao = new PolicyDaoImpl();
        this.planDao = new PlanDaoImpl();
        this.uwCaseDao = new UnderwritingCaseDaoImpl();
    }

    public PolicyServiceImpl(PolicyDao policyDao, PlanDao planDao, UnderwritingCaseDao uwCaseDao) {
        this.policyDao = policyDao;
        this.planDao = planDao;
        this.uwCaseDao = uwCaseDao;
    }

    @Override
    public Policy createPolicy(PolicyDto dto) {
        if (dto.getCustomerId() == null || dto.getCustomerId().isBlank())
            throw new IllegalArgumentException("Customer ID is required");
        if (dto.getPlanId() == null || dto.getPlanId().isBlank())
            throw new IllegalArgumentException("Plan ID is required");
        if (dto.getTripStartDate() == null || dto.getTripEndDate() == null)
            throw new IllegalArgumentException("Trip start and end dates are required");
        if (dto.getTripEndDate().isBefore(dto.getTripStartDate()))
            throw new IllegalArgumentException("Trip end date must be on or after start date");
        if (dto.getTripStartDate().isBefore(LocalDate.now()))
            throw new IllegalArgumentException("Trip start date cannot be in the past");
        if (dto.getNumTravelers() < 1)
            throw new IllegalArgumentException("Number of travelers must be at least 1");

        Plan plan = planDao.findById(dto.getPlanId());
        if (plan == null)
            throw new IllegalArgumentException("Plan not found: " + dto.getPlanId());
        if (!"ACTIVE".equals(plan.getStatus()))
            throw new IllegalStateException("Selected plan is not currently active");

        long tripDays = ChronoUnit.DAYS.between(dto.getTripStartDate(), dto.getTripEndDate());
        if (tripDays < plan.getMinTripDays())
            throw new IllegalArgumentException("Trip must be at least " + plan.getMinTripDays() + " day(s) for this plan");
        if (tripDays > plan.getMaxTripDays())
            throw new IllegalArgumentException("Trip cannot exceed " + plan.getMaxTripDays() + " days for this plan");
        if (dto.getNumTravelers() > plan.getMaxTravelers())
            throw new IllegalArgumentException("This plan supports a maximum of " + plan.getMaxTravelers() + " travelers");

        BigDecimal premium = calculatePremium(plan, tripDays, dto.getNumTravelers());
        BigDecimal riskScore = calculateRiskScore(dto);
        String riskLevel = getRiskLevel(riskScore);

        // Apply risk loading to premium
        BigDecimal loadingPercent = riskScore.multiply(new BigDecimal("2"))
                .divide(new BigDecimal("100"), 4, RoundingMode.HALF_UP);
        BigDecimal loadedPremium = premium.multiply(BigDecimal.ONE.add(loadingPercent))
                .setScale(2, RoundingMode.HALF_UP);

        String policyNumber = generatePolicyNumber();
        boolean needsUW = "HIGH".equals(riskLevel);

        // Policy is always created as QUOTED (low/medium) or PENDING_UW (high risk).
        // It becomes ACTIVE only after payment is confirmed (for QUOTED)
        // or after underwriter approves (for PENDING_UW).
        // This is the correct insurance flow: quote -> pay -> activate.
        String initialStatus = needsUW ? "PENDING_UW" : "QUOTED";

        Policy policy = new Policy();
        policy.setId(UUID.randomUUID().toString());
        policy.setPolicyNumber(policyNumber);
        policy.setCustomerId(dto.getCustomerId());
        policy.setPlanId(dto.getPlanId());
        policy.setDestinationCountryCode(dto.getDestinationCountryCode());
        policy.setTripStartDate(dto.getTripStartDate());
        policy.setTripEndDate(dto.getTripEndDate());
        policy.setNumTravelers(dto.getNumTravelers());
        policy.setTripPurpose(dto.getTripPurpose() != null ? dto.getTripPurpose() : "LEISURE");
        policy.setTotalPremium(loadedPremium);
        policy.setCurrency(dto.getCurrency() != null ? dto.getCurrency() : "INR");
        policy.setRiskScore(riskScore);
        policy.setRiskLevel(riskLevel);
        policy.setStatus(initialStatus);
        policy.setIssueDate(null); // set by activatePolicy() after payment
        policy.setExpiryDate(dto.getTripEndDate());
        policy.setRenewalCount(0);
        policy.setCreatedAt(OffsetDateTime.now());
        policy.setUpdatedAt(OffsetDateTime.now());
        policy.setVersion(1L);

        policyDao.save(policy);

        if (needsUW) {
            createUnderwritingCase(policy, riskScore, riskLevel);
        }

        return policy;
    }

    @Override
    public Policy findByPolicyNumber(String policyNumber) {
        return policyDao.findByPolicyNumber(policyNumber);
    }

    @Override
    public List<Policy> findByCustomerId(String customerId) {
        return policyDao.findByCustomerId(customerId);
    }

    @Override
    public List<Policy> findAll() {
        return policyDao.findAll();
    }

    @Override
    public List<Policy> findByStatus(String status) {
        return policyDao.findByStatus(status);
    }

    @Override
    public void cancelPolicy(String policyId) {
        cancelPolicy(policyId, null);
    }

    @Override
    public void cancelPolicy(String policyId, String reason) {
        Policy policy = policyDao.findById(policyId);
        if (policy == null)
            throw new IllegalArgumentException("Policy not found: " + policyId);
        if ("CANCELLED".equals(policy.getStatus()))
            throw new IllegalStateException("Policy is already cancelled");
        if ("EXPIRED".equals(policy.getStatus()))
            throw new IllegalStateException("Cannot cancel an expired policy");

        policy.setStatus("CANCELLED");
        policy.setCancellationReason(reason);
        policyDao.update(policy);
    }

    @Override
    public void activatePolicy(String policyId) {
        Policy policy = policyDao.findById(policyId);
        if (policy == null)
            throw new IllegalArgumentException("Policy not found: " + policyId);
        if (!"PENDING_UW".equals(policy.getStatus()) && !"QUOTED".equals(policy.getStatus()))
            throw new IllegalStateException("Only QUOTED or PENDING_UW policies can be activated. Current: " + policy.getStatus());

        policy.setStatus("ACTIVE");
        policy.setIssueDate(OffsetDateTime.now());
        policyDao.update(policy);

        UnderwritingCase uwCase = uwCaseDao.findByPolicyId(policyId);
        if (uwCase != null) {
            uwCase.setCurrentState("APPROVED");
            uwCase.setFinalPremium(policy.getTotalPremium());
            uwCaseDao.update(uwCase);
        }
    }

    @Override
    public void rejectPolicy(String policyId, String reason) {
        Policy policy = policyDao.findById(policyId);
        if (policy == null)
            throw new IllegalArgumentException("Policy not found: " + policyId);
        if (!"PENDING_UW".equals(policy.getStatus()))
            throw new IllegalStateException("Only PENDING_UW policies can be rejected by underwriter");

        policy.setStatus("CANCELLED");
        policyDao.update(policy);

        UnderwritingCase uwCase = uwCaseDao.findByPolicyId(policyId);
        if (uwCase != null) {
            uwCase.setCurrentState("REJECTED");
            uwCase.setActive(false);
            uwCaseDao.update(uwCase);
        }
    }

    // --- Private helpers ---

    private BigDecimal calculatePremium(Plan plan, long tripDays, int numTravelers) {
        BigDecimal dailyCost = plan.getDailyRate()
                .multiply(BigDecimal.valueOf(tripDays))
                .multiply(BigDecimal.valueOf(numTravelers));
        return plan.getBasePremium().add(dailyCost).setScale(2, RoundingMode.HALF_UP);
    }

    private BigDecimal calculateRiskScore(PolicyDto dto) {
        double score = 0.0;

        // 1. Destination risk
        String dest = dto.getDestinationCountryCode() != null
                ? dto.getDestinationCountryCode().toUpperCase() : "";
        if (List.of("US", "CA").contains(dest))                                    score += 4.0;
        else if (List.of("AU", "NZ").contains(dest))                               score += 3.5;
        else if (List.of("GB", "FR", "DE", "IT", "ES", "JP").contains(dest))       score += 3.0;
        else if (List.of("AE", "SA", "ZA").contains(dest))                         score += 2.5;
        else if ("SG".equals(dest))                                                 score += 2.0;
        else                                                                        score += 1.0;

        // 2. Trip purpose
        if ("BUSINESS".equalsIgnoreCase(dto.getTripPurpose())) score += 1.5;

        // 3. Trip duration
        long days = ChronoUnit.DAYS.between(dto.getTripStartDate(), dto.getTripEndDate());
        if (days > 30)       score += 2.0;
        else if (days > 14)  score += 1.0;
        else if (days > 7)   score += 0.5;

        // 4. Number of travelers
        if (dto.getNumTravelers() >= 5)      score += 1.0;
        else if (dto.getNumTravelers() >= 2) score += 0.5;

        // 5. Traveler age risk (senior travelers - age > 60 adds risk)
        //    Cap total age loading at +2.0 regardless of how many seniors
        if (dto.getTravelerAges() != null && !dto.getTravelerAges().isEmpty()) {
            double ageLoading = 0.0;
            for (int age : dto.getTravelerAges()) {
                if (age > 70)       ageLoading += 1.5;  // very senior
                else if (age > 60)  ageLoading += 1.0;  // senior
                else if (age < 5)   ageLoading += 0.5;  // infant/toddler risk
            }
            score += Math.min(ageLoading, 2.0); // cap at +2.0
        }

        return new BigDecimal(score).setScale(2, RoundingMode.HALF_UP);
    }

    private String getRiskLevel(BigDecimal riskScore) {
        double score = riskScore.doubleValue();
        if (score >= 6.0) return "HIGH";
        if (score >= 3.0) return "MEDIUM";
        return "LOW";
    }

    private void createUnderwritingCase(Policy policy, BigDecimal riskScore, String riskLevel) {
        String caseRef = "UWC-" + LocalDate.now().getYear() + "-" +
                         String.format("%06d", (int)(Math.random() * 999999) + 1);
        UnderwritingCase uc = new UnderwritingCase();
        uc.setId(UUID.randomUUID().toString());
        uc.setCaseReference(caseRef);
        uc.setPolicyId(policy.getId());
        uc.setCustomerId(policy.getCustomerId());
        uc.setRiskScore(riskScore);
        uc.setRiskLevel(riskLevel);
        uc.setUwLevel(2);
        uc.setCurrentState("PENDING_REVIEW");
        uc.setSlaHours(48);
        uc.setSlaDueAt(OffsetDateTime.now().plusHours(48));
        uc.setSlaBreached(false);
        uc.setLocked(false);
        uc.setPremiumLoadingPercent(BigDecimal.ZERO);
        uc.setFinalPremium(policy.getTotalPremium());
        uc.setActive(true);
        uc.setCreatedAt(OffsetDateTime.now());
        uc.setUpdatedAt(OffsetDateTime.now());
        uc.setVersion(1L);
        uwCaseDao.save(uc);
    }

    private String generatePolicyNumber() {
        String year = String.valueOf(LocalDate.now().getYear());
        String unique = String.format("%06d", (int)(Math.random() * 999999) + 1);
        return "POL-" + year + "-" + unique;
    }

    @Override
    public void saveAsQuote(String policyId) {
        Policy policy = policyDao.findById(policyId);
        if (policy == null)
            throw new IllegalArgumentException("Policy not found: " + policyId);
        // Policy is already saved - just ensure status is QUOTED (it should be ACTIVE for low-risk)
        // We downgrade to QUOTED so customer can pay later
        policy.setStatus("QUOTED");
        policy.setIssueDate(null);
        policyDao.update(policy);
    }

}