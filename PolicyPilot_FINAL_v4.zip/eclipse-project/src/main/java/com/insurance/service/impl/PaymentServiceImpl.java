package com.insurance.service.impl;

import com.insurance.dao.PaymentDao;
import com.insurance.dao.impl.PaymentDaoImpl;
import com.insurance.entity.Payment;
import com.insurance.service.PaymentService;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class PaymentServiceImpl implements PaymentService {

    private final PaymentDao paymentDao;

    public PaymentServiceImpl() { this.paymentDao = new PaymentDaoImpl(); }
    public PaymentServiceImpl(PaymentDao paymentDao) { this.paymentDao = paymentDao; }

    @Override
    public Payment processPayment(String policyId, BigDecimal amount, String currency) {
        if (policyId == null || policyId.isBlank())
            throw new IllegalArgumentException("Policy ID is required");
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0)
            throw new IllegalArgumentException("Payment amount must be greater than zero");

        Payment payment = new Payment();
        payment.setId(UUID.randomUUID().toString());
        payment.setPolicyId(policyId);
        payment.setClaimId(null);
        payment.setPaymentReference(generateRef("PAY"));
        payment.setAmount(amount);
        payment.setCurrency(currency != null ? currency : "INR");
        payment.setPaymentType("PREMIUM_RECEIVED");
        payment.setStatus("PENDING");
        payment.setCreatedAt(OffsetDateTime.now());
        paymentDao.save(payment);
        return payment;
    }

    @Override
    public void completePayment(String paymentId) {
        Payment payment = paymentDao.findById(paymentId);
        if (payment == null)
            throw new IllegalArgumentException("Payment not found: " + paymentId);
        if ("COMPLETED".equals(payment.getStatus()))
            throw new IllegalStateException("Payment is already completed");
        payment.setStatus("COMPLETED");
        payment.setPaidAt(OffsetDateTime.now());
        paymentDao.update(payment);
    }

    @Override
    public Payment processClaimPayout(String policyId, String claimId, BigDecimal amount, String currency) {
        if (policyId == null || policyId.isBlank())
            throw new IllegalArgumentException("Policy ID is required");
        if (claimId == null || claimId.isBlank())
            throw new IllegalArgumentException("Claim ID is required");
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0)
            throw new IllegalArgumentException("Payout amount must be greater than zero");

        Payment payment = new Payment();
        payment.setId(UUID.randomUUID().toString());
        payment.setPolicyId(policyId);
        payment.setClaimId(claimId);
        payment.setPaymentReference(generateRef("PAYOUT"));
        payment.setAmount(amount);
        payment.setCurrency(currency != null ? currency : "INR");
        payment.setPaymentType("CLAIM_PAYOUT");
        payment.setStatus("PENDING");
        payment.setCreatedAt(OffsetDateTime.now());
        paymentDao.save(payment);
        return payment;
    }

    @Override
    public void completeClaimPayout(String paymentId) {
        Payment payment = paymentDao.findById(paymentId);
        if (payment == null)
            throw new IllegalArgumentException("Payout record not found: " + paymentId);
        if (!"CLAIM_PAYOUT".equals(payment.getPaymentType()))
            throw new IllegalStateException("This is not a claim payout record");
        if ("COMPLETED".equals(payment.getStatus()))
            throw new IllegalStateException("Payout already completed");
        payment.setStatus("COMPLETED");
        payment.setPaidAt(OffsetDateTime.now());
        paymentDao.update(payment);
    }

    @Override
    public Payment findById(String id) { return paymentDao.findById(id); }

    @Override
    public List<Payment> findAll() { return paymentDao.findAll(); }

    @Override
    public List<Payment> findByPolicyId(String policyId) { return paymentDao.findByPolicyId(policyId); }

    @Override
    public List<Payment> findByStatus(String status) { return paymentDao.findByStatus(status); }

    @Override
    public List<Payment> findByType(String paymentType) { return paymentDao.findByType(paymentType); }

    @Override
    public List<Payment> findByClaimId(String claimId) { return paymentDao.findByClaimId(claimId); }

    @Override
    public Map<String, BigDecimal> getFinanceSummary() {
        BigDecimal totalCredited = paymentDao.sumByType("PREMIUM_RECEIVED", "COMPLETED");
        BigDecimal totalSettled  = paymentDao.sumByType("CLAIM_PAYOUT",     "COMPLETED");
        BigDecimal settlementPct = BigDecimal.ZERO;
        if (totalCredited.compareTo(BigDecimal.ZERO) > 0) {
            settlementPct = totalSettled
                    .multiply(new BigDecimal("100"))
                    .divide(totalCredited, 2, RoundingMode.HALF_UP);
        }
        Map<String, BigDecimal> summary = new HashMap<>();
        summary.put("totalCredited",     totalCredited);
        summary.put("totalSettled",      totalSettled);
        summary.put("settlementPercent", settlementPct);
        return summary;
    }

    private String generateRef(String prefix) {
        return prefix + "-" + LocalDate.now().getYear() + "-" +
               String.format("%06d", (int)(Math.random() * 999999) + 1);
    }

    /**
     * Auto-creates a PENDING claim payout record when a claim is approved.
     * Called by ClaimServiceImpl after approveClaim().
     * Finance officer sees it directly in pending payouts without any extra steps.
     */
    @Override
    public Payment autoCreateClaimPayout(String policyId, String claimId, BigDecimal amount, String currency) {
        // Check if payout already exists for this claim
        List<Payment> existing = paymentDao.findByClaimId(claimId);
        for (Payment p : existing) {
            if ("CLAIM_PAYOUT".equals(p.getPaymentType())) {
                return p; // already created
            }
        }
        return processClaimPayout(policyId, claimId, amount, currency);
    }


}