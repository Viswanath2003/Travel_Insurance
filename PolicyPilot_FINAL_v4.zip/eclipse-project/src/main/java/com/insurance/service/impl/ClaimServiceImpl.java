package com.insurance.service.impl;

import com.insurance.dao.ClaimDao;
import com.insurance.dao.PolicyDao;
import com.insurance.dao.impl.ClaimDaoImpl;
import com.insurance.dao.impl.PolicyDaoImpl;
import com.insurance.service.PaymentService;
import com.insurance.service.impl.PaymentServiceImpl;
import com.insurance.dao.PlanCoverageDao;
import com.insurance.dao.impl.PlanCoverageDaoImpl;
import com.insurance.entity.PlanCoverage;
import com.insurance.dto.ClaimDto;
import com.insurance.entity.Claim;
import com.insurance.entity.Policy;
import com.insurance.service.ClaimService;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

public class ClaimServiceImpl implements ClaimService {

    private final ClaimDao claimDao;
    private final PolicyDao policyDao;
    private final PlanCoverageDao planCoverageDao;
    private final PaymentService paymentService;

    public ClaimServiceImpl() {
        this.claimDao = new ClaimDaoImpl();
        this.policyDao = new PolicyDaoImpl();
        this.planCoverageDao = new PlanCoverageDaoImpl();
        this.paymentService = new PaymentServiceImpl();
    }

    public ClaimServiceImpl(ClaimDao claimDao, PolicyDao policyDao) {
        this.claimDao = claimDao;
        this.policyDao = policyDao;
        this.planCoverageDao = new PlanCoverageDaoImpl();
        this.paymentService = new PaymentServiceImpl();
    }

    @Override
    public Claim submitClaim(ClaimDto dto) {
        if (dto.getPolicyId() == null || dto.getPolicyId().isBlank())
            throw new IllegalArgumentException("Policy ID is required");
        if (dto.getClaimedAmount() == null || dto.getClaimedAmount().compareTo(BigDecimal.ZERO) <= 0)
            throw new IllegalArgumentException("Claimed amount must be greater than zero");
        if (dto.getIncidentDate() == null)
            throw new IllegalArgumentException("Incident date is required");

        Policy policy = policyDao.findById(dto.getPolicyId());
        if (policy == null)
            throw new IllegalArgumentException("Policy not found: " + dto.getPolicyId());
        if (!"ACTIVE".equals(policy.getStatus()))
            throw new IllegalStateException("Claims can only be submitted on ACTIVE policies. " +
                    "Current status: " + policy.getStatus());

        String claimRef = generateClaimReference();

        Claim claim = new Claim();
        claim.setId(UUID.randomUUID().toString());
        claim.setClaimReference(claimRef);
        claim.setPolicyId(dto.getPolicyId());
        claim.setCustomerId(dto.getCustomerId() != null ? dto.getCustomerId() : policy.getCustomerId());
        claim.setClaimTypeId(dto.getClaimTypeId());
        claim.setStatus("SUBMITTED");
        claim.setIncidentDate(dto.getIncidentDate());
        claim.setIncidentDescription(dto.getIncidentDescription());
        claim.setClaimedAmount(dto.getClaimedAmount());
        claim.setHighValue(dto.getClaimedAmount().compareTo(new BigDecimal("100000")) > 0);
        claim.setFieldInvestigationRequired(false);
        claim.setCreatedAt(OffsetDateTime.now());
        claim.setUpdatedAt(OffsetDateTime.now());
        claim.setVersion(1L);

        claimDao.save(claim);
        return claim;
    }

    @Override
    public Claim findById(String claimId) {
        return claimDao.findById(claimId);
    }

    @Override
    public Claim findByClaimReference(String claimReference) {
        return claimDao.findByClaimReference(claimReference);
    }

    @Override
    public List<Claim> findByPolicyId(String policyId) {
        return claimDao.findByPolicyId(policyId);
    }

    @Override
    public List<Claim> findByCustomerId(String customerId) {
        return claimDao.findByCustomerId(customerId);
    }

    @Override
    public List<Claim> findByStatus(String status) {
        return claimDao.findByStatus(status);
    }

    @Override
    public List<Claim> findByAssignedOfficerId(String officerId) {
        return claimDao.findByAssignedOfficerId(officerId);
    }

    @Override
    public List<Claim> findAll() {
        return claimDao.findAll();
    }

    @Override
    public void approveClaim(String claimId, BigDecimal approvedAmount, String officerId) {
        Claim claim = claimDao.findById(claimId);
        if (claim == null)
            throw new IllegalArgumentException("Claim not found: " + claimId);
        // Block if claim is still with field officer (assigned + not yet returned)
        if (claim.isFieldInvestigationRequired()
                && "IN_REVIEW".equals(claim.getStatus())
                && claim.getAssignedOfficerId() != null) {
            throw new IllegalStateException(
                "This claim is assigned to a field officer for investigation. " +
                "Please wait for the field officer to submit their findings (FIELD_APPROVED or FIELD_REJECTED) " +
                "before taking action.");
        }
        if (approvedAmount == null || approvedAmount.compareTo(BigDecimal.ZERO) < 0)
            throw new IllegalArgumentException("Settlement amount cannot be negative");

        // Validate against sum insured for the coverage type, not the claimed amount
        Policy policy = policyDao.findById(claim.getPolicyId());
        if (policy != null) {
            java.math.BigDecimal sumInsured = getSumInsuredForClaim(policy.getPlanId(), claim.getClaimTypeId());
            if (sumInsured != null && sumInsured.compareTo(BigDecimal.ZERO) > 0) {
                if (approvedAmount.compareTo(sumInsured) > 0) {
                    throw new IllegalArgumentException(
                        "Settlement amount " + approvedAmount +
                        " cannot exceed the sum insured of " + sumInsured +
                        " for this coverage type.");
                }
            }
        }
        // Also cannot exceed what customer requested
        if (approvedAmount.compareTo(claim.getClaimedAmount()) > 0)
            throw new IllegalArgumentException(
                "Settlement amount cannot exceed the customer's requested amount of " +
                claim.getClaimedAmount() + ".");

        claim.setStatus("APPROVED");
        claim.setApprovedAmount(approvedAmount);
        claim.setDecidedBy(officerId);
        claim.setDecidedAt(OffsetDateTime.now());
        claim.setDecisionReason("Claim approved");
        claimDao.update(claim);

        // Auto-create PENDING payout so finance officer sees it immediately
        try {
            paymentService.autoCreateClaimPayout(
                claim.getPolicyId(), claim.getId(), approvedAmount, "INR");
        } catch (Exception ignored) {
            // Payout record creation failure should not block claim approval
        }
    }

    @Override
    public void rejectClaim(String claimId, String reason, String officerId) {
        Claim claim = claimDao.findById(claimId);
        if (claim == null)
            throw new IllegalArgumentException("Claim not found: " + claimId);
        if (reason == null || reason.isBlank())
            throw new IllegalArgumentException("Rejection reason is required");

        claim.setStatus("REJECTED");
        claim.setApprovedAmount(BigDecimal.ZERO);
        claim.setDecidedBy(officerId);
        claim.setDecidedAt(OffsetDateTime.now());
        claim.setDecisionReason(reason);
        claimDao.update(claim);
    }

    @Override
    public void updateStatus(String claimId, String newStatus) {
        Claim claim = claimDao.findById(claimId);
        if (claim == null)
            throw new IllegalArgumentException("Claim not found: " + claimId);

        List<String> validStatuses = List.of(
                "SUBMITTED", "IN_REVIEW", "PENDING_DOCS",
                "FIELD_APPROVED", "FIELD_REJECTED",
                "APPROVED", "REJECTED", "CLOSED");
        if (!validStatuses.contains(newStatus))
            throw new IllegalArgumentException("Invalid claim status: " + newStatus);

        claim.setStatus(newStatus);
        claimDao.update(claim);
    }

    @Override
    public void assignFieldOfficer(String claimId, String fieldOfficerId) {
        Claim claim = claimDao.findById(claimId);
        if (claim == null)
            throw new IllegalArgumentException("Claim not found: " + claimId);
        if (fieldOfficerId == null || fieldOfficerId.isBlank())
            throw new IllegalArgumentException("Field officer ID is required");

        claim.setAssignedOfficerId(fieldOfficerId);
        claim.setFieldInvestigationRequired(true);
        if ("SUBMITTED".equals(claim.getStatus()))
            claim.setStatus("IN_REVIEW");
        claimDao.update(claim);
    }


    private java.math.BigDecimal getSumInsuredForClaim(String planId, String claimTypeId) {
        try {
            // Find the claim type to get its linked coverage type
            com.insurance.dao.ClaimTypeDao ctDao = new com.insurance.dao.impl.ClaimTypeDaoImpl();
            com.insurance.entity.ClaimType ct = ctDao.findById(claimTypeId);
            if (ct == null || ct.getCoverageTypeId() == null) return null;

            // Get plan coverage for this coverage type
            List<PlanCoverage> coverages = planCoverageDao.findByPlanId(planId);
            for (PlanCoverage pc : coverages) {
                String[] parts = pc.getCoverageTypeId().split("\\|");
                String covTypeId = parts[0];
                if (ct.getCoverageTypeId().equals(covTypeId)) {
                    return pc.getDefaultLimit();
                }
            }
        } catch (Exception e) {
            // If we can't determine sum insured, don't block
        }
        return null;
    }

    private String generateClaimReference() {
        String year = String.valueOf(java.time.LocalDate.now().getYear());
        String unique = String.format("%06d", (int)(Math.random() * 999999) + 1);
        return "CLM-" + year + "-" + unique;
    }

    @Override
    public void submitFieldFindings(String claimId, String outcome, String fieldOfficerId) {
        Claim claim = claimDao.findById(claimId);
        if (claim == null)
            throw new IllegalArgumentException("Claim not found: " + claimId);
        if (!fieldOfficerId.equals(claim.getAssignedOfficerId()))
            throw new IllegalStateException("You are not the assigned field officer for this claim");
        if (!"FIELD_APPROVED".equals(outcome) && !"FIELD_REJECTED".equals(outcome))
            throw new IllegalArgumentException("Outcome must be FIELD_APPROVED or FIELD_REJECTED");

        claim.setStatus(outcome);
        claimDao.update(claim);
    }


}