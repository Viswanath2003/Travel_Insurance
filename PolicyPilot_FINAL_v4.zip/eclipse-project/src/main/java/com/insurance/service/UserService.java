package com.insurance.service;

import com.insurance.dto.UserDto;
import com.insurance.entity.User;
import java.util.List;

public interface UserService {
    User registerUser(UserDto dto);
    User findByEmail(String email);
    User findById(String id);
    List<User> findAll();
    void updateStatus(String userId, String newStatus);
}
