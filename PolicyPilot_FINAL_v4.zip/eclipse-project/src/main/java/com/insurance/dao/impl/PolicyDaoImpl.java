package com.insurance.dao.impl;

import com.insurance.config.DatabaseConnection;
import com.insurance.dao.PolicyDao;
import com.insurance.entity.Policy;

import java.sql.*;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PolicyDaoImpl implements PolicyDao {

    @Override
    public Policy findById(String id) {
        final String sql = "SELECT * FROM policies WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding policy by id: " + id, e);
        }
        return null;
    }

    @Override
    public Policy findByPolicyNumber(String policyNumber) {
        final String sql = "SELECT * FROM policies WHERE policy_number = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, policyNumber);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding policy by number: " + policyNumber, e);
        }
        return null;
    }

    @Override
    public List<Policy> findAll() {
        final String sql = "SELECT * FROM policies ORDER BY created_at DESC";
        List<Policy> policies = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) policies.add(mapRow(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error finding all policies", e);
        }
        return policies;
    }

    @Override
    public List<Policy> findByCustomerId(String customerId) {
        final String sql = "SELECT * FROM policies WHERE customer_id = ? ORDER BY created_at DESC";
        List<Policy> policies = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(customerId));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) policies.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding policies for customer: " + customerId, e);
        }
        return policies;
    }

    @Override
    public List<Policy> findByStatus(String status) {
        final String sql = "SELECT * FROM policies WHERE status = ? ORDER BY created_at DESC";
        List<Policy> policies = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) policies.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding policies by status: " + status, e);
        }
        return policies;
    }

    @Override
    public List<Policy> findByPlanId(String planId) {
        final String sql = "SELECT * FROM policies WHERE plan_id = ? ORDER BY created_at DESC";
        List<Policy> policies = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(planId));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) policies.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding policies by plan: " + planId, e);
        }
        return policies;
    }

    @Override
    public void save(Policy policy) {
        final String sql = "INSERT INTO policies (id, policy_number, quote_id, customer_id, product_id, plan_id, " +
                "destination_country_code, destination_zone_id, trip_start_date, trip_end_date, num_travelers, " +
                "trip_purpose, total_premium, currency, risk_score, risk_level, status, issue_date, expiry_date, " +
                "parent_policy_id, renewal_count, cancellation_reason, created_at, updated_at, version) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(policy.getId()));
            stmt.setString(2, policy.getPolicyNumber());
            setNullableUuid(stmt, 3, policy.getQuoteId());
            stmt.setObject(4, UUID.fromString(policy.getCustomerId()));
            setNullableUuid(stmt, 5, policy.getProductId());
            stmt.setObject(6, UUID.fromString(policy.getPlanId()));
            stmt.setString(7, policy.getDestinationCountryCode());
            setNullableUuid(stmt, 8, policy.getDestinationZoneId());
            stmt.setObject(9, policy.getTripStartDate());
            stmt.setObject(10, policy.getTripEndDate());
            stmt.setInt(11, policy.getNumTravelers());
            stmt.setString(12, policy.getTripPurpose());
            stmt.setBigDecimal(13, policy.getTotalPremium());
            stmt.setString(14, policy.getCurrency());
            stmt.setBigDecimal(15, policy.getRiskScore());
            stmt.setString(16, policy.getRiskLevel());
            stmt.setString(17, policy.getStatus());
            stmt.setObject(18, policy.getIssueDate());
            stmt.setObject(19, policy.getExpiryDate());
            setNullableUuid(stmt, 20, policy.getParentPolicyId());
            stmt.setInt(21, policy.getRenewalCount());
            stmt.setString(22, policy.getCancellationReason());
            stmt.setObject(23, policy.getCreatedAt());
            stmt.setObject(24, policy.getUpdatedAt());
            stmt.setLong(25, policy.getVersion());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error saving policy: " + policy.getPolicyNumber(), e);
        }
    }

    @Override
    public void update(Policy policy) {
        final String sql = "UPDATE policies SET status=?, risk_score=?, risk_level=?, total_premium=?, " +
                "num_travelers=?, trip_purpose=?, issue_date=?, expiry_date=?, " +
                "cancellation_reason=?, updated_at=?, version=? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, policy.getStatus());
            stmt.setBigDecimal(2, policy.getRiskScore());
            stmt.setString(3, policy.getRiskLevel());
            stmt.setBigDecimal(4, policy.getTotalPremium());
            stmt.setInt(5, policy.getNumTravelers());
            stmt.setString(6, policy.getTripPurpose());
            stmt.setObject(7, policy.getIssueDate());
            stmt.setObject(8, policy.getExpiryDate());
            stmt.setString(9, policy.getCancellationReason());
            stmt.setObject(10, OffsetDateTime.now());
            stmt.setLong(11, policy.getVersion() + 1);
            stmt.setObject(12, UUID.fromString(policy.getId()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error updating policy: " + policy.getId(), e);
        }
    }

    @Override
    public void delete(String id) {
        final String sql = "DELETE FROM policies WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting policy: " + id, e);
        }
    }

    private void setNullableUuid(PreparedStatement stmt, int index, String id) throws SQLException {
        if (id != null) stmt.setObject(index, UUID.fromString(id));
        else stmt.setNull(index, Types.OTHER);
    }

    private Policy mapRow(ResultSet rs) throws SQLException {
        Policy policy = new Policy();
        policy.setId(rs.getString("id"));
        policy.setPolicyNumber(rs.getString("policy_number"));
        policy.setQuoteId(rs.getString("quote_id"));
        policy.setCustomerId(rs.getString("customer_id"));
        policy.setProductId(rs.getString("product_id"));
        policy.setPlanId(rs.getString("plan_id"));
        policy.setDestinationCountryCode(rs.getString("destination_country_code"));
        policy.setDestinationZoneId(rs.getString("destination_zone_id"));
        policy.setTripStartDate(rs.getObject("trip_start_date", LocalDate.class));
        policy.setTripEndDate(rs.getObject("trip_end_date", LocalDate.class));
        policy.setNumTravelers(rs.getInt("num_travelers"));
        policy.setTripPurpose(rs.getString("trip_purpose"));
        policy.setTotalPremium(rs.getBigDecimal("total_premium"));
        policy.setCurrency(rs.getString("currency"));
        policy.setRiskScore(rs.getBigDecimal("risk_score"));
        policy.setRiskLevel(rs.getString("risk_level"));
        policy.setStatus(rs.getString("status"));
        policy.setIssueDate(rs.getObject("issue_date", OffsetDateTime.class));
        policy.setExpiryDate(rs.getObject("expiry_date", LocalDate.class));
        policy.setParentPolicyId(rs.getString("parent_policy_id"));
        policy.setRenewalCount(rs.getInt("renewal_count"));
        policy.setCancellationReason(rs.getString("cancellation_reason"));
        policy.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        policy.setUpdatedAt(rs.getObject("updated_at", OffsetDateTime.class));
        policy.setVersion(rs.getLong("version"));
        return policy;
    }
}
