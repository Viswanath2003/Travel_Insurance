package com.insurance.dao;

import com.insurance.entity.Addon;
import java.util.List;

public interface AddonDao {
    List<Addon> findByPlanId(String planId);
    Addon findById(String id);
}
