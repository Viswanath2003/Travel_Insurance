package com.insurance.dao;

import com.insurance.entity.UnderwritingCase;
import java.util.List;

public interface UnderwritingCaseDao {
    UnderwritingCase findById(String id);
    UnderwritingCase findByPolicyId(String policyId);
    List<UnderwritingCase> findAll();
    List<UnderwritingCase> findByState(String state);
    List<UnderwritingCase> findByAssignedTo(String userId);
    void save(UnderwritingCase uwCase);
    void update(UnderwritingCase uwCase);
}
