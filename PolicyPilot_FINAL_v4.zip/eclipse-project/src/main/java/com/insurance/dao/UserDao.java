package com.insurance.dao;

import com.insurance.entity.User;
import java.util.List;

public interface UserDao {
    User findById(String id);
    User findByEmail(String email);
    User findByUsername(String username);
    List<User> findAll();
    List<User> findByRole(String role);
    List<User> findByNameOrEmail(String searchTerm);   // LIKE search
    String findFullNameById(String userId);             // quick name lookup
    void save(User user);
    void update(User user);
    void delete(String id);
}
