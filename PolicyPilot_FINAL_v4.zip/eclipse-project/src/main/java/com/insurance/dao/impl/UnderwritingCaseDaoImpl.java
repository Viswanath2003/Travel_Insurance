package com.insurance.dao.impl;

import com.insurance.config.DatabaseConnection;
import com.insurance.dao.UnderwritingCaseDao;
import com.insurance.entity.UnderwritingCase;

import java.sql.*;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class UnderwritingCaseDaoImpl implements UnderwritingCaseDao {

    @Override
    public UnderwritingCase findById(String id) {
        final String sql = "SELECT * FROM underwriting_cases WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding UW case by id: " + id, e);
        }
        return null;
    }

    @Override
    public UnderwritingCase findByPolicyId(String policyId) {
        final String sql = "SELECT * FROM underwriting_cases WHERE policy_id = ? AND is_active = TRUE LIMIT 1";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(policyId));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding UW case by policy: " + policyId, e);
        }
        return null;
    }

    @Override
    public List<UnderwritingCase> findAll() {
        final String sql = "SELECT * FROM underwriting_cases ORDER BY created_at DESC";
        List<UnderwritingCase> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error finding all UW cases", e);
        }
        return list;
    }

    @Override
    public List<UnderwritingCase> findByState(String state) {
        final String sql = "SELECT * FROM underwriting_cases WHERE current_state = ? AND is_active = TRUE ORDER BY created_at";
        List<UnderwritingCase> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, state);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding UW cases by state: " + state, e);
        }
        return list;
    }

    @Override
    public List<UnderwritingCase> findByAssignedTo(String userId) {
        final String sql = "SELECT * FROM underwriting_cases WHERE assigned_to_user_id = ? AND is_active = TRUE ORDER BY created_at";
        List<UnderwritingCase> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding UW cases by assignee: " + userId, e);
        }
        return list;
    }

    @Override
    public void save(UnderwritingCase uc) {
        final String sql = "INSERT INTO underwriting_cases (id, case_reference, policy_id, customer_id, " +
                "risk_score, risk_level, uw_level, current_state, assigned_to_user_id, assigned_by_user_id, " +
                "assigned_at, sla_hours, sla_due_at, sla_breached, is_locked, locked_by, locked_at, " +
                "premium_loading_percent, final_premium, is_active, created_at, updated_at, version) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(uc.getId()));
            stmt.setString(2, uc.getCaseReference());
            stmt.setObject(3, UUID.fromString(uc.getPolicyId()));
            stmt.setObject(4, UUID.fromString(uc.getCustomerId()));
            stmt.setBigDecimal(5, uc.getRiskScore());
            stmt.setString(6, uc.getRiskLevel());
            stmt.setInt(7, uc.getUwLevel());
            stmt.setString(8, uc.getCurrentState());
            setNullableUuid(stmt, 9, uc.getAssignedToUserId());
            setNullableUuid(stmt, 10, uc.getAssignedByUserId());
            stmt.setObject(11, uc.getAssignedAt());
            stmt.setInt(12, uc.getSlaHours());
            stmt.setObject(13, uc.getSlaDueAt());
            stmt.setBoolean(14, uc.isSlaBreached());
            stmt.setBoolean(15, uc.isLocked());
            setNullableUuid(stmt, 16, uc.getLockedBy());
            stmt.setObject(17, uc.getLockedAt());
            stmt.setBigDecimal(18, uc.getPremiumLoadingPercent());
            stmt.setBigDecimal(19, uc.getFinalPremium());
            stmt.setBoolean(20, uc.isActive());
            stmt.setObject(21, uc.getCreatedAt());
            stmt.setObject(22, uc.getUpdatedAt());
            stmt.setLong(23, uc.getVersion());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error saving UW case: " + uc.getCaseReference(), e);
        }
    }

    @Override
    public void update(UnderwritingCase uc) {
        final String sql = "UPDATE underwriting_cases SET current_state=?, assigned_to_user_id=?, " +
                "premium_loading_percent=?, final_premium=?, is_active=?, sla_breached=?, " +
                "updated_at=?, version=? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, uc.getCurrentState());
            setNullableUuid(stmt, 2, uc.getAssignedToUserId());
            stmt.setBigDecimal(3, uc.getPremiumLoadingPercent());
            stmt.setBigDecimal(4, uc.getFinalPremium());
            stmt.setBoolean(5, uc.isActive());
            stmt.setBoolean(6, uc.isSlaBreached());
            stmt.setObject(7, OffsetDateTime.now());
            stmt.setLong(8, uc.getVersion() + 1);
            stmt.setObject(9, UUID.fromString(uc.getId()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error updating UW case: " + uc.getId(), e);
        }
    }

    private void setNullableUuid(PreparedStatement stmt, int index, String id) throws SQLException {
        if (id != null) stmt.setObject(index, UUID.fromString(id));
        else stmt.setNull(index, Types.OTHER);
    }

    private UnderwritingCase mapRow(ResultSet rs) throws SQLException {
        UnderwritingCase uc = new UnderwritingCase();
        uc.setId(rs.getString("id"));
        uc.setCaseReference(rs.getString("case_reference"));
        uc.setPolicyId(rs.getString("policy_id"));
        uc.setCustomerId(rs.getString("customer_id"));
        uc.setRiskScore(rs.getBigDecimal("risk_score"));
        uc.setRiskLevel(rs.getString("risk_level"));
        uc.setUwLevel(rs.getInt("uw_level"));
        uc.setCurrentState(rs.getString("current_state"));
        uc.setAssignedToUserId(rs.getString("assigned_to_user_id"));
        uc.setAssignedByUserId(rs.getString("assigned_by_user_id"));
        uc.setAssignedAt(rs.getObject("assigned_at", OffsetDateTime.class));
        uc.setSlaHours(rs.getInt("sla_hours"));
        uc.setSlaDueAt(rs.getObject("sla_due_at", OffsetDateTime.class));
        uc.setSlaBreached(rs.getBoolean("sla_breached"));
        uc.setLocked(rs.getBoolean("is_locked"));
        uc.setLockedBy(rs.getString("locked_by"));
        uc.setLockedAt(rs.getObject("locked_at", OffsetDateTime.class));
        uc.setPremiumLoadingPercent(rs.getBigDecimal("premium_loading_percent"));
        uc.setFinalPremium(rs.getBigDecimal("final_premium"));
        uc.setActive(rs.getBoolean("is_active"));
        uc.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        uc.setUpdatedAt(rs.getObject("updated_at", OffsetDateTime.class));
        uc.setVersion(rs.getLong("version"));
        return uc;
    }
}
