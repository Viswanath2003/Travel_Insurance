package com.insurance.dao;

import com.insurance.entity.CustomerProfile;

public interface CustomerProfileDao {
    CustomerProfile findByUserId(String userId);
    void save(CustomerProfile profile);
    void update(CustomerProfile profile);
}
