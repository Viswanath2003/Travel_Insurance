package com.insurance.dao.impl;

import com.insurance.config.DatabaseConnection;
import com.insurance.dao.AddonDao;
import com.insurance.entity.Addon;

import java.sql.*;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AddonDaoImpl implements AddonDao {

    @Override
    public List<Addon> findByPlanId(String planId) {
        final String sql =
            "SELECT a.* FROM addons a " +
            "JOIN plan_addon_mappings pam ON pam.addon_id = a.id " +
            "WHERE pam.plan_id = ? AND pam.is_active = TRUE AND a.is_active = TRUE " +
            "ORDER BY a.sort_order";
        List<Addon> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(planId));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding addons for plan: " + planId, e);
        }
        return list;
    }

    @Override
    public Addon findById(String id) {
        final String sql = "SELECT * FROM addons WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding addon: " + id, e);
        }
        return null;
    }

    private Addon mapRow(ResultSet rs) throws SQLException {
        Addon a = new Addon();
        a.setId(rs.getString("id"));
        a.setAddonCode(rs.getString("addon_code"));
        a.setAddonName(rs.getString("addon_name"));
        a.setAddonCategory(rs.getString("addon_category"));
        a.setDescription(rs.getString("description"));
        a.setPricingType(rs.getString("pricing_type"));
        a.setPricingValue(rs.getBigDecimal("pricing_value"));
        a.setCurrency(rs.getString("currency"));
        a.setActive(rs.getBoolean("is_active"));
        a.setSortOrder(rs.getInt("sort_order"));
        a.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        a.setUpdatedAt(rs.getObject("updated_at", OffsetDateTime.class));
        return a;
    }
}
