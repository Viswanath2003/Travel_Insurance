package com.insurance.dao.impl;

import com.insurance.config.DatabaseConnection;
import com.insurance.dao.UserDao;
import com.insurance.entity.User;

import java.sql.*;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class UserDaoImpl implements UserDao {

    @Override
    public User findById(String id) {
        final String sql = "SELECT * FROM users WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding user by id: " + id, e);
        }
        return null;
    }

    @Override
    public User findByEmail(String email) {
        final String sql = "SELECT * FROM users WHERE email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding user by email: " + email, e);
        }
        return null;
    }

    @Override
    public User findByUsername(String username) {
        final String sql = "SELECT * FROM users WHERE username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding user by username: " + username, e);
        }
        return null;
    }

    @Override
    public List<User> findAll() {
        final String sql = "SELECT * FROM users ORDER BY created_at";
        List<User> users = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) users.add(mapRow(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error finding all users", e);
        }
        return users;
    }

    @Override
    public List<User> findByRole(String role) {
        final String sql = "SELECT * FROM users WHERE role = ? ORDER BY full_name";
        List<User> users = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, role);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) users.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding users by role: " + role, e);
        }
        return users;
    }

    @Override
    public List<User> findByNameOrEmail(String searchTerm) {
        final String sql = "SELECT * FROM users WHERE " +
                "LOWER(full_name) LIKE LOWER(?) OR LOWER(email) LIKE LOWER(?) " +
                "ORDER BY full_name";
        String pattern = "%" + (searchTerm != null ? searchTerm.trim() : "") + "%";
        List<User> users = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, pattern);
            stmt.setString(2, pattern);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) users.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error searching users: " + searchTerm, e);
        }
        return users;
    }

    @Override
    public String findFullNameById(String userId) {
        if (userId == null) return "-";
        final String sql = "SELECT full_name FROM users WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String name = rs.getString("full_name");
                    return name != null ? name : "-";
                }
            }
        } catch (Exception e) {
            return "-";
        }
        return "-";
    }

    @Override
    public void save(User user) {
        final String sql = "INSERT INTO users (id, username, email, mobile, full_name, " +
                "password_hash, role, status, age, is_default_password, failed_login_attempts, locked_until, " +
                "last_login_at, email_verified, mobile_verified, profile_photo_path, " +
                "created_at, updated_at, version) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1,  UUID.fromString(user.getId()));
            stmt.setString(2,  user.getUsername());
            stmt.setString(3,  user.getEmail());
            stmt.setString(4,  user.getMobile());
            stmt.setString(5,  user.getFullName());
            stmt.setString(6,  user.getPasswordHash());
            stmt.setString(7,  user.getRole());
            stmt.setString(8,  user.getStatus());
            stmt.setInt(9,     user.getAge());
            stmt.setBoolean(10, user.isDefaultPassword());
            stmt.setInt(11,    user.getFailedLoginAttempts());
            stmt.setObject(12, user.getLockedUntil());
            stmt.setObject(13, user.getLastLoginAt());
            stmt.setBoolean(14, user.isEmailVerified());
            stmt.setBoolean(15, user.isMobileVerified());
            stmt.setString(16, user.getProfilePhotoPath());
            stmt.setObject(17, user.getCreatedAt());
            stmt.setObject(18, user.getUpdatedAt());
            stmt.setLong(19,   user.getVersion());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error saving user: " + user.getEmail(), e);
        }
    }

    @Override
    public void update(User user) {
        final String sql = "UPDATE users SET username=?, email=?, mobile=?, full_name=?, " +
                "password_hash=?, role=?, status=?, age=?, is_default_password=?, failed_login_attempts=?, " +
                "locked_until=?, last_login_at=?, email_verified=?, " +
                "mobile_verified=?, profile_photo_path=?, updated_at=?, version=? " +
                "WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1,  user.getUsername());
            stmt.setString(2,  user.getEmail());
            stmt.setString(3,  user.getMobile());
            stmt.setString(4,  user.getFullName());
            stmt.setString(5,  user.getPasswordHash());
            stmt.setString(6,  user.getRole());
            stmt.setString(7,  user.getStatus());
            stmt.setInt(8,     user.getAge());
            stmt.setBoolean(9, user.isDefaultPassword());
            stmt.setInt(10,    user.getFailedLoginAttempts());
            stmt.setObject(11, user.getLockedUntil());
            stmt.setObject(12, user.getLastLoginAt());
            stmt.setBoolean(13, user.isEmailVerified());
            stmt.setBoolean(14, user.isMobileVerified());
            stmt.setString(15, user.getProfilePhotoPath());
            stmt.setObject(16, user.getUpdatedAt());
            stmt.setLong(17,   user.getVersion());
            stmt.setObject(18, UUID.fromString(user.getId()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error updating user: " + user.getId(), e);
        }
    }

    @Override
    public void delete(String id) {
        final String sql = "DELETE FROM users WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting user: " + id, e);
        }
    }

    private User mapRow(ResultSet rs) throws SQLException {
        User user = new User();
        user.setId(rs.getString("id"));
        user.setUsername(rs.getString("username"));
        user.setEmail(rs.getString("email"));
        user.setMobile(rs.getString("mobile"));
        user.setFullName(rs.getString("full_name"));
        user.setPasswordHash(rs.getString("password_hash"));
        user.setRole(rs.getString("role"));
        user.setStatus(rs.getString("status"));
        // age column: default 0 if null (for existing rows before migration)
        try { user.setAge(rs.getInt("age")); } catch (SQLException e) { user.setAge(0); }
        try { user.setDefaultPassword(rs.getBoolean("is_default_password")); } catch (SQLException e) { user.setDefaultPassword(false); }
        user.setFailedLoginAttempts(rs.getInt("failed_login_attempts"));
        user.setLockedUntil(rs.getObject("locked_until", OffsetDateTime.class));
        user.setLastLoginAt(rs.getObject("last_login_at", OffsetDateTime.class));
        user.setEmailVerified(rs.getBoolean("email_verified"));
        user.setMobileVerified(rs.getBoolean("mobile_verified"));
        user.setProfilePhotoPath(rs.getString("profile_photo_path"));
        user.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        user.setUpdatedAt(rs.getObject("updated_at", OffsetDateTime.class));
        user.setVersion(rs.getLong("version"));
        return user;
    }
}
