package com.insurance.dao;

import com.insurance.entity.ClaimType;
import java.util.List;

public interface ClaimTypeDao {
    ClaimType findById(String id);
    List<ClaimType> findAll();
}
