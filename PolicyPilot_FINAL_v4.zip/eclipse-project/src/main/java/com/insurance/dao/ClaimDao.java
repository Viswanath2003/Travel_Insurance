package com.insurance.dao;

import com.insurance.entity.Claim;
import java.util.List;

public interface ClaimDao {
    Claim findById(String id);
    Claim findByClaimReference(String claimReference);
    List<Claim> findAll();
    List<Claim> findByPolicyId(String policyId);
    List<Claim> findByCustomerId(String customerId);
    List<Claim> findByStatus(String status);
    List<Claim> findByAssignedOfficerId(String officerId);
    void save(Claim claim);
    void update(Claim claim);
    void delete(String id);
}
