package com.insurance.dao;

import com.insurance.entity.PlanCoverage;
import com.insurance.entity.CoverageType;
import java.util.List;

public interface PlanCoverageDao {
    List<PlanCoverage> findByPlanId(String planId);
    CoverageType findCoverageTypeById(String id);
}
