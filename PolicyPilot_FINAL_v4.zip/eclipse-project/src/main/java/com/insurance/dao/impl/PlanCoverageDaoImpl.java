package com.insurance.dao.impl;

import com.insurance.config.DatabaseConnection;
import com.insurance.dao.PlanCoverageDao;
import com.insurance.entity.CoverageType;
import com.insurance.entity.PlanCoverage;

import java.sql.*;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PlanCoverageDaoImpl implements PlanCoverageDao {

    @Override
    public List<PlanCoverage> findByPlanId(String planId) {
        final String sql =
            "SELECT pc.*, ct.coverage_name, ct.coverage_code, ct.coverage_category, ct.description AS ct_desc " +
            "FROM plan_coverages pc " +
            "JOIN coverage_types ct ON ct.id = pc.coverage_type_id " +
            "WHERE pc.plan_id = ? AND pc.is_active = TRUE " +
            "ORDER BY ct.sort_order";
        List<PlanCoverage> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(planId));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding coverages for plan: " + planId, e);
        }
        return list;
    }

    @Override
    public CoverageType findCoverageTypeById(String id) {
        final String sql = "SELECT * FROM coverage_types WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapCoverageType(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding coverage type: " + id, e);
        }
        return null;
    }

    private PlanCoverage mapRow(ResultSet rs) throws SQLException {
        PlanCoverage pc = new PlanCoverage();
        pc.setId(rs.getString("id"));
        pc.setPlanId(rs.getString("plan_id"));
        pc.setCoverageTypeId(rs.getString("coverage_type_id"));
        pc.setMinLimit(rs.getBigDecimal("min_limit"));
        pc.setMaxLimit(rs.getBigDecimal("max_limit"));
        pc.setDefaultLimit(rs.getBigDecimal("default_limit"));
        pc.setLimitStep(rs.getBigDecimal("limit_step"));
        pc.setCurrency(rs.getString("currency"));
        pc.setDeductible(rs.getBigDecimal("deductible"));
        pc.setMandatory(rs.getBoolean("is_mandatory"));
        pc.setAdjustable(rs.getBoolean("is_adjustable"));
        pc.setActive(rs.getBoolean("is_active"));
        // store coverage name in a transient field via coverageTypeId string for display
        // We embed it into the coverageTypeId field as "id|name" for UI convenience
        String name = rs.getString("coverage_name");
        String code = rs.getString("coverage_code");
        String cat  = rs.getString("coverage_category");
        pc.setCoverageTypeId(rs.getString("coverage_type_id") + "|" + name + "|" + code + "|" + cat);
        return pc;
    }

    private CoverageType mapCoverageType(ResultSet rs) throws SQLException {
        CoverageType ct = new CoverageType();
        ct.setId(rs.getString("id"));
        ct.setCoverageCode(rs.getString("coverage_code"));
        ct.setCoverageName(rs.getString("coverage_name"));
        ct.setCoverageCategory(rs.getString("coverage_category"));
        ct.setDescription(rs.getString("description"));
        ct.setActive(rs.getBoolean("is_active"));
        ct.setSortOrder(rs.getInt("sort_order"));
        ct.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        return ct;
    }
}
