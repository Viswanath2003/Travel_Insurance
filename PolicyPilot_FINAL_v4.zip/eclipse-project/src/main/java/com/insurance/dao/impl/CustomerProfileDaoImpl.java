package com.insurance.dao.impl;

import com.insurance.config.DatabaseConnection;
import com.insurance.dao.CustomerProfileDao;
import com.insurance.entity.CustomerProfile;

import java.sql.*;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.UUID;

public class CustomerProfileDaoImpl implements CustomerProfileDao {

    @Override
    public CustomerProfile findByUserId(String userId) {
        final String sql = "SELECT * FROM customer_profiles WHERE user_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(userId));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding profile for user: " + userId, e);
        }
        return null;
    }

    @Override
    public void save(CustomerProfile cp) {
        final String sql = "INSERT INTO customer_profiles (id, user_id, date_of_birth, gender, nationality, " +
                "passport_number, passport_expiry_date, address_line1, address_line2, city, " +
                "state_province, postal_code, country_code, emergency_contact_name, " +
                "emergency_contact_phone, occupation, annual_income_band, created_at, updated_at) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(cp.getId()));
            stmt.setObject(2, UUID.fromString(cp.getUserId()));
            stmt.setObject(3, cp.getDateOfBirth());
            stmt.setString(4, cp.getGender());
            stmt.setString(5, cp.getNationality());
            stmt.setString(6, cp.getPassportNumber());
            stmt.setObject(7, cp.getPassportExpiryDate());
            stmt.setString(8, cp.getAddressLine1());
            stmt.setString(9, cp.getAddressLine2());
            stmt.setString(10, cp.getCity());
            stmt.setString(11, cp.getStateProvince());
            stmt.setString(12, cp.getPostalCode());
            stmt.setString(13, cp.getCountryCode());
            stmt.setString(14, cp.getEmergencyContactName());
            stmt.setString(15, cp.getEmergencyContactPhone());
            stmt.setString(16, cp.getOccupation());
            stmt.setString(17, cp.getAnnualIncomeBand());
            stmt.setObject(18, cp.getCreatedAt());
            stmt.setObject(19, cp.getUpdatedAt());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error saving customer profile for user: " + cp.getUserId(), e);
        }
    }

    @Override
    public void update(CustomerProfile cp) {
        final String sql = "UPDATE customer_profiles SET date_of_birth=?, gender=?, nationality=?, " +
                "passport_number=?, passport_expiry_date=?, address_line1=?, address_line2=?, " +
                "city=?, state_province=?, postal_code=?, country_code=?, emergency_contact_name=?, " +
                "emergency_contact_phone=?, occupation=?, annual_income_band=?, updated_at=? " +
                "WHERE user_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, cp.getDateOfBirth());
            stmt.setString(2, cp.getGender());
            stmt.setString(3, cp.getNationality());
            stmt.setString(4, cp.getPassportNumber());
            stmt.setObject(5, cp.getPassportExpiryDate());
            stmt.setString(6, cp.getAddressLine1());
            stmt.setString(7, cp.getAddressLine2());
            stmt.setString(8, cp.getCity());
            stmt.setString(9, cp.getStateProvince());
            stmt.setString(10, cp.getPostalCode());
            stmt.setString(11, cp.getCountryCode());
            stmt.setString(12, cp.getEmergencyContactName());
            stmt.setString(13, cp.getEmergencyContactPhone());
            stmt.setString(14, cp.getOccupation());
            stmt.setString(15, cp.getAnnualIncomeBand());
            stmt.setObject(16, OffsetDateTime.now());
            stmt.setObject(17, UUID.fromString(cp.getUserId()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error updating customer profile for user: " + cp.getUserId(), e);
        }
    }

    private CustomerProfile mapRow(ResultSet rs) throws SQLException {
        CustomerProfile cp = new CustomerProfile();
        cp.setId(rs.getString("id"));
        cp.setUserId(rs.getString("user_id"));
        cp.setDateOfBirth(rs.getObject("date_of_birth", LocalDate.class));
        cp.setGender(rs.getString("gender"));
        cp.setNationality(rs.getString("nationality"));
        cp.setPassportNumber(rs.getString("passport_number"));
        cp.setPassportExpiryDate(rs.getObject("passport_expiry_date", LocalDate.class));
        cp.setAddressLine1(rs.getString("address_line1"));
        cp.setAddressLine2(rs.getString("address_line2"));
        cp.setCity(rs.getString("city"));
        cp.setStateProvince(rs.getString("state_province"));
        cp.setPostalCode(rs.getString("postal_code"));
        cp.setCountryCode(rs.getString("country_code"));
        cp.setEmergencyContactName(rs.getString("emergency_contact_name"));
        cp.setEmergencyContactPhone(rs.getString("emergency_contact_phone"));
        cp.setOccupation(rs.getString("occupation"));
        cp.setAnnualIncomeBand(rs.getString("annual_income_band"));
        cp.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        cp.setUpdatedAt(rs.getObject("updated_at", OffsetDateTime.class));
        return cp;
    }
}
