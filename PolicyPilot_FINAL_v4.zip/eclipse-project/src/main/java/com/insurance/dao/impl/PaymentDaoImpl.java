package com.insurance.dao.impl;

import com.insurance.config.DatabaseConnection;
import com.insurance.dao.PaymentDao;
import com.insurance.entity.Payment;

import java.math.BigDecimal;
import java.sql.*;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PaymentDaoImpl implements PaymentDao {

    @Override
    public Payment findById(String id) {
        final String sql = "SELECT * FROM payments WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding payment by id: " + id, e);
        }
        return null;
    }

    @Override
    public Payment findByPaymentReference(String paymentReference) {
        final String sql = "SELECT * FROM payments WHERE payment_reference = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, paymentReference);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding payment by reference: " + paymentReference, e);
        }
        return null;
    }

    @Override
    public List<Payment> findAll() {
        final String sql = "SELECT * FROM payments ORDER BY created_at DESC";
        List<Payment> payments = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) payments.add(mapRow(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error finding all payments", e);
        }
        return payments;
    }

    @Override
    public List<Payment> findByPolicyId(String policyId) {
        final String sql = "SELECT * FROM payments WHERE policy_id = ? ORDER BY created_at DESC";
        List<Payment> payments = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(policyId));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) payments.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding payments for policy: " + policyId, e);
        }
        return payments;
    }

    @Override
    public List<Payment> findByStatus(String status) {
        final String sql = "SELECT * FROM payments WHERE status = ? ORDER BY created_at DESC";
        List<Payment> payments = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) payments.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding payments by status: " + status, e);
        }
        return payments;
    }

    @Override
    public List<Payment> findByType(String paymentType) {
        final String sql = "SELECT * FROM payments WHERE payment_type = ? ORDER BY created_at DESC";
        List<Payment> payments = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, paymentType);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) payments.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding payments by type: " + paymentType, e);
        }
        return payments;
    }

    @Override
    public List<Payment> findByClaimId(String claimId) {
        final String sql = "SELECT * FROM payments WHERE claim_id = ? ORDER BY created_at DESC";
        List<Payment> payments = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(claimId));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) payments.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding payments for claim: " + claimId, e);
        }
        return payments;
    }

    @Override
    public BigDecimal sumByType(String paymentType, String status) {
        final String sql = "SELECT COALESCE(SUM(amount), 0) FROM payments " +
                "WHERE payment_type = ? AND status = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, paymentType);
            stmt.setString(2, status);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return rs.getBigDecimal(1);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error summing payments by type: " + paymentType, e);
        }
        return BigDecimal.ZERO;
    }

    @Override
    public void save(Payment payment) {
        final String sql = "INSERT INTO payments (id, policy_id, claim_id, payment_reference, " +
                "amount, currency, payment_type, status, paid_at, created_at) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(payment.getId()));
            stmt.setObject(2, UUID.fromString(payment.getPolicyId()));
            if (payment.getClaimId() != null)
                stmt.setObject(3, UUID.fromString(payment.getClaimId()));
            else
                stmt.setNull(3, Types.OTHER);
            stmt.setString(4, payment.getPaymentReference());
            stmt.setBigDecimal(5, payment.getAmount());
            stmt.setString(6, payment.getCurrency());
            stmt.setString(7, payment.getPaymentType() != null ? payment.getPaymentType() : "PREMIUM_RECEIVED");
            stmt.setString(8, payment.getStatus());
            stmt.setObject(9, payment.getPaidAt());
            stmt.setObject(10, payment.getCreatedAt());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error saving payment: " + payment.getPaymentReference(), e);
        }
    }

    @Override
    public void update(Payment payment) {
        final String sql = "UPDATE payments SET status=?, paid_at=?, payment_type=? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, payment.getStatus());
            stmt.setObject(2, payment.getPaidAt());
            stmt.setString(3, payment.getPaymentType());
            stmt.setObject(4, UUID.fromString(payment.getId()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error updating payment: " + payment.getId(), e);
        }
    }

    @Override
    public void delete(String id) {
        final String sql = "DELETE FROM payments WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting payment: " + id, e);
        }
    }

    private Payment mapRow(ResultSet rs) throws SQLException {
        Payment payment = new Payment();
        payment.setId(rs.getString("id"));
        payment.setPolicyId(rs.getString("policy_id"));
        payment.setClaimId(rs.getString("claim_id"));
        payment.setPaymentReference(rs.getString("payment_reference"));
        payment.setAmount(rs.getBigDecimal("amount"));
        payment.setCurrency(rs.getString("currency"));
        payment.setPaymentType(rs.getString("payment_type"));
        payment.setStatus(rs.getString("status"));
        payment.setPaidAt(rs.getObject("paid_at", OffsetDateTime.class));
        payment.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        return payment;
    }
}
