package com.insurance.dao.impl;

import com.insurance.config.DatabaseConnection;
import com.insurance.dao.ClaimTypeDao;
import com.insurance.entity.ClaimType;

import java.sql.*;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ClaimTypeDaoImpl implements ClaimTypeDao {

    @Override
    public ClaimType findById(String id) {
        final String sql = "SELECT * FROM claim_types WHERE id = ? AND is_active = TRUE";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding claim type: " + id, e);
        }
        return null;
    }

    @Override
    public List<ClaimType> findAll() {
        final String sql = "SELECT * FROM claim_types WHERE is_active = TRUE ORDER BY name";
        List<ClaimType> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error finding all claim types", e);
        }
        return list;
    }

    /**
     * Returns claim types relevant to the given policy.
     * Includes base coverage claim types that the policy's plan covers,
     * plus addon-specific claim types (coverage_type_id IS NULL).
     * This ensures customers can only file claims for coverages they actually have.
     */
    public List<ClaimType> findByPlanId(String planId) {
        // Get coverage types for this plan, plus addon claims (null coverage_type_id)
        final String sql =
            "SELECT ct.* FROM claim_types ct " +
            "WHERE ct.is_active = TRUE AND (" +
            "  ct.coverage_type_id IN (" +
            "    SELECT pc.coverage_type_id FROM plan_coverages pc " +
            "    WHERE pc.plan_id = ? AND pc.is_active = TRUE" +
            "  ) OR ct.coverage_type_id IS NULL" +
            ") ORDER BY ct.name";
        List<ClaimType> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(planId));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding claim types for plan: " + planId, e);
        }
        return list;
    }

    private ClaimType mapRow(ResultSet rs) throws SQLException {
        ClaimType ct = new ClaimType();
        ct.setId(rs.getString("id"));
        ct.setCode(rs.getString("code"));
        ct.setName(rs.getString("name"));
        ct.setDescription(rs.getString("description"));
        ct.setCoverageTypeId(rs.getString("coverage_type_id"));
        ct.setDefaultSlaHours(rs.getInt("default_sla_hours"));
        ct.setActive(rs.getBoolean("is_active"));
        ct.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        ct.setUpdatedAt(rs.getObject("updated_at", OffsetDateTime.class));
        return ct;
    }
}
