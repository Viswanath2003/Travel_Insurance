package com.insurance.dao;

import com.insurance.entity.Policy;
import java.util.List;

public interface PolicyDao {
    Policy findById(String id);
    Policy findByPolicyNumber(String policyNumber);
    List<Policy> findAll();
    List<Policy> findByCustomerId(String customerId);
    List<Policy> findByStatus(String status);
    List<Policy> findByPlanId(String planId);
    void save(Policy policy);
    void update(Policy policy);
    void delete(String id);
}
