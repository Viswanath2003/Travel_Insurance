package com.insurance.dao;

import com.insurance.entity.Plan;
import java.util.List;

public interface PlanDao {
    Plan findById(String id);
    List<Plan> findAll();
    List<Plan> findByStatus(String status);
}
