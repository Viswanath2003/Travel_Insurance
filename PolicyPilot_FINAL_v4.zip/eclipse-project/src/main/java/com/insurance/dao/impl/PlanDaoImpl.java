package com.insurance.dao.impl;

import com.insurance.config.DatabaseConnection;
import com.insurance.dao.PlanDao;
import com.insurance.entity.Plan;

import java.sql.*;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class PlanDaoImpl implements PlanDao {

    @Override
    public Plan findById(String id) {
        final String sql = "SELECT * FROM plans WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding plan by id: " + id, e);
        }
        return null;
    }

    @Override
    public List<Plan> findAll() {
        final String sql = "SELECT * FROM plans ORDER BY plan_code";
        List<Plan> plans = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) plans.add(mapRow(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error finding all plans", e);
        }
        return plans;
    }

    @Override
    public List<Plan> findByStatus(String status) {
        final String sql = "SELECT * FROM plans WHERE status = ? ORDER BY plan_code";
        List<Plan> plans = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) plans.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding plans by status: " + status, e);
        }
        return plans;
    }

    private Plan mapRow(ResultSet rs) throws SQLException {
        Plan plan = new Plan();
        plan.setId(rs.getString("id"));
        plan.setPlanCode(rs.getString("plan_code"));
        plan.setPlanName(rs.getString("plan_name"));
        plan.setProductId(rs.getString("product_id"));
        plan.setBasePremium(rs.getBigDecimal("base_premium"));
        plan.setDailyRate(rs.getBigDecimal("daily_rate"));
        plan.setCurrency(rs.getString("currency"));
        plan.setMinTripDays(rs.getInt("min_trip_days"));
        plan.setMaxTripDays(rs.getInt("max_trip_days"));
        plan.setMinTravelerAge(rs.getInt("min_traveler_age"));
        plan.setMaxTravelerAge(rs.getInt("max_traveler_age"));
        plan.setMaxTravelers(rs.getInt("max_travelers"));
        plan.setStatus(rs.getString("status"));
        plan.setVersion(rs.getInt("version"));
        plan.setPublishedAt(rs.getObject("published_at", OffsetDateTime.class));
        plan.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        plan.setUpdatedAt(rs.getObject("updated_at", OffsetDateTime.class));
        return plan;
    }
}
