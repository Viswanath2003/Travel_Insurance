package com.insurance.dao.impl;

import com.insurance.config.DatabaseConnection;
import com.insurance.dao.ClaimDao;
import com.insurance.entity.Claim;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class ClaimDaoImpl implements ClaimDao {

    @Override
    public Claim findById(String id) {
        final String sql = "SELECT * FROM claims WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding claim by id: " + id, e);
        }
        return null;
    }

    @Override
    public Claim findByClaimReference(String ref) {
        final String sql = "SELECT * FROM claims WHERE claim_reference = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, ref);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding claim by reference: " + ref, e);
        }
        return null;
    }

    @Override
    public List<Claim> findAll() {
        final String sql = "SELECT * FROM claims ORDER BY created_at DESC";
        List<Claim> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error finding all claims", e);
        }
        return list;
    }

    @Override
    public List<Claim> findByPolicyId(String policyId) {
        final String sql = "SELECT * FROM claims WHERE policy_id = ? ORDER BY created_at DESC";
        List<Claim> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(policyId));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding claims for policy: " + policyId, e);
        }
        return list;
    }

    @Override
    public List<Claim> findByCustomerId(String customerId) {
        final String sql = "SELECT * FROM claims WHERE customer_id = ? ORDER BY created_at DESC";
        List<Claim> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(customerId));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding claims for customer: " + customerId, e);
        }
        return list;
    }

    @Override
    public List<Claim> findByStatus(String status) {
        final String sql = "SELECT * FROM claims WHERE status = ? ORDER BY created_at DESC";
        List<Claim> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding claims by status: " + status, e);
        }
        return list;
    }

    @Override
    public List<Claim> findByAssignedOfficerId(String officerId) {
        final String sql = "SELECT * FROM claims WHERE assigned_officer_id = ? ORDER BY created_at DESC";
        List<Claim> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(officerId));
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error finding claims for officer: " + officerId, e);
        }
        return list;
    }

    @Override
    public void save(Claim claim) {
        // 19 columns: id, claim_reference, policy_id, customer_id, claim_type_id,
        // status, incident_date, incident_description, claimed_amount, approved_amount,
        // assigned_officer_id, decided_by, decision_reason, decided_at,
        // is_high_value, field_investigation_required, created_at, updated_at, version
        final String sql = "INSERT INTO claims (" +
                "id, claim_reference, policy_id, customer_id, claim_type_id, " +
                "status, incident_date, incident_description, claimed_amount, approved_amount, " +
                "assigned_officer_id, decided_by, decision_reason, decided_at, " +
                "is_high_value, field_investigation_required, created_at, updated_at, version) " +
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1,  UUID.fromString(claim.getId()));
            stmt.setString(2,  claim.getClaimReference());
            stmt.setObject(3,  UUID.fromString(claim.getPolicyId()));
            stmt.setObject(4,  UUID.fromString(claim.getCustomerId()));
            stmt.setObject(5,  UUID.fromString(claim.getClaimTypeId()));
            stmt.setString(6,  claim.getStatus());
            stmt.setObject(7,  claim.getIncidentDate());
            stmt.setString(8,  claim.getIncidentDescription());
            stmt.setBigDecimal(9,  claim.getClaimedAmount());
            stmt.setBigDecimal(10, claim.getApprovedAmount());
            if (claim.getAssignedOfficerId() != null)
                stmt.setObject(11, UUID.fromString(claim.getAssignedOfficerId()));
            else
                stmt.setNull(11, Types.OTHER);
            if (claim.getDecidedBy() != null)
                stmt.setObject(12, UUID.fromString(claim.getDecidedBy()));
            else
                stmt.setNull(12, Types.OTHER);
            stmt.setString(13, claim.getDecisionReason());
            stmt.setObject(14, claim.getDecidedAt());
            stmt.setBoolean(15, claim.isHighValue());
            stmt.setBoolean(16, claim.isFieldInvestigationRequired());
            stmt.setObject(17, claim.getCreatedAt());
            stmt.setObject(18, claim.getUpdatedAt());
            stmt.setLong(19,   claim.getVersion());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error saving claim: " + claim.getClaimReference(), e);
        }
    }

    @Override
    public void update(Claim claim) {
        // 9 SET columns + 1 WHERE = 10 params
        final String sql = "UPDATE claims SET " +
                "status=?, approved_amount=?, assigned_officer_id=?, decided_by=?, " +
                "decision_reason=?, decided_at=?, is_high_value=?, " +
                "field_investigation_required=?, updated_at=?, version=? " +
                "WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1,  claim.getStatus());
            stmt.setBigDecimal(2, claim.getApprovedAmount());
            if (claim.getAssignedOfficerId() != null)
                stmt.setObject(3, UUID.fromString(claim.getAssignedOfficerId()));
            else
                stmt.setNull(3, Types.OTHER);
            if (claim.getDecidedBy() != null)
                stmt.setObject(4, UUID.fromString(claim.getDecidedBy()));
            else
                stmt.setNull(4, Types.OTHER);
            stmt.setString(5,  claim.getDecisionReason());
            stmt.setObject(6,  claim.getDecidedAt());
            stmt.setBoolean(7, claim.isHighValue());
            stmt.setBoolean(8, claim.isFieldInvestigationRequired());
            stmt.setObject(9,  OffsetDateTime.now());
            stmt.setLong(10,   claim.getVersion() + 1);
            stmt.setObject(11, UUID.fromString(claim.getId()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error updating claim: " + claim.getId(), e);
        }
    }

    @Override
    public void delete(String id) {
        final String sql = "DELETE FROM claims WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setObject(1, UUID.fromString(id));
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting claim: " + id, e);
        }
    }

    private Claim mapRow(ResultSet rs) throws SQLException {
        Claim claim = new Claim();
        claim.setId(rs.getString("id"));
        claim.setClaimReference(rs.getString("claim_reference"));
        claim.setPolicyId(rs.getString("policy_id"));
        claim.setCustomerId(rs.getString("customer_id"));
        claim.setClaimTypeId(rs.getString("claim_type_id"));
        claim.setStatus(rs.getString("status"));
        claim.setIncidentDate(rs.getObject("incident_date", LocalDate.class));
        claim.setIncidentDescription(rs.getString("incident_description"));
        claim.setClaimedAmount(rs.getBigDecimal("claimed_amount"));
        claim.setApprovedAmount(rs.getBigDecimal("approved_amount"));
        claim.setAssignedOfficerId(rs.getString("assigned_officer_id"));
        claim.setDecidedBy(rs.getString("decided_by"));
        claim.setDecisionReason(rs.getString("decision_reason"));
        claim.setDecidedAt(rs.getObject("decided_at", OffsetDateTime.class));
        claim.setHighValue(rs.getBoolean("is_high_value"));
        claim.setFieldInvestigationRequired(rs.getBoolean("field_investigation_required"));
        claim.setCreatedAt(rs.getObject("created_at", OffsetDateTime.class));
        claim.setUpdatedAt(rs.getObject("updated_at", OffsetDateTime.class));
        claim.setVersion(rs.getLong("version"));
        return claim;
    }
}
