package com.insurance.dao;

import com.insurance.entity.Payment;
import java.math.BigDecimal;
import java.util.List;

public interface PaymentDao {
    Payment findById(String id);
    Payment findByPaymentReference(String paymentReference);
    List<Payment> findAll();
    List<Payment> findByPolicyId(String policyId);
    List<Payment> findByStatus(String status);
    List<Payment> findByType(String paymentType);
    List<Payment> findByClaimId(String claimId);
    BigDecimal sumByType(String paymentType, String status);
    void save(Payment payment);
    void update(Payment payment);
    void delete(String id);
}
