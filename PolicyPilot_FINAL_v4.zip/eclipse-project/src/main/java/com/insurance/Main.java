package com.insurance;

import com.insurance.ui.ConsoleUI;

public class Main {
    public static void main(String[] args) {
        new ConsoleUI().run();
    }
}
