-- =============================================================
--  POLICY PILOT - TRAVEL INSURANCE SCHEMA SEED
--  Plans: PolicyPilot Basic | PolicyPilot Plus | PolicyPilot Pro
-- =============================================================

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =============================================================
-- 1. users
-- =============================================================
CREATE TABLE IF NOT EXISTS users (
    id                    UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    username              VARCHAR(50)  NOT NULL,
    email                 VARCHAR(100) NOT NULL,
    mobile                VARCHAR(15),
    full_name             VARCHAR(100),
    password_hash         TEXT         NOT NULL,
    role                  VARCHAR(30),
    status                VARCHAR(30),
    age                   INT          DEFAULT 0,
    is_default_password   BOOLEAN      DEFAULT FALSE,
    failed_login_attempts SMALLINT,
    locked_until          TIMESTAMPTZ,
    last_login_at         TIMESTAMPTZ,
    email_verified        BOOLEAN      DEFAULT FALSE,
    mobile_verified       BOOLEAN      DEFAULT FALSE,
    profile_photo_path    TEXT,
    created_at            TIMESTAMPTZ,
    updated_at            TIMESTAMPTZ,
    version               BIGINT
);

INSERT INTO users (
    id, username, email, mobile, full_name, password_hash,
    role, status, age, is_default_password, failed_login_attempts, locked_until, last_login_at,
    email_verified, mobile_verified, profile_photo_path, created_at, updated_at, version
) VALUES
-- Customers
('a1000000-0000-0000-0000-000000000001',
 'shankar_rajan', 'shannu@gmail.com', '9876543210', 'Shankar Rajan',
 'Shannu@123', 'CUSTOMER', 'ACTIVE', 33, FALSE,
 0, NULL, '2026-05-18 09:00:00+00', TRUE, TRUE, NULL,
 '2025-01-10 08:00:00+00', '2026-05-18 09:00:00+00', 5),

('a1000000-0000-0000-0000-000000000002',
 'priya_nair', 'priya.nair@gmail.com', '9845001122', 'Priya Nair',
 'Priya@456', 'CUSTOMER', 'ACTIVE', 30, FALSE,
 0, NULL, '2026-05-17 14:30:00+00', TRUE, TRUE, NULL,
 '2025-03-15 10:00:00+00', '2026-05-17 14:30:00+00', 3),

('a1000000-0000-0000-0000-000000000003',
 'rahul_mehta', 'rahul.mehta@outlook.com', '9900112233', 'Rahul Mehta',
 'Rahul@789', 'CUSTOMER', 'ACTIVE', 45, FALSE,
 0, NULL, '2026-05-19 07:00:00+00', TRUE, TRUE, NULL,
 '2024-11-01 08:00:00+00', '2026-05-19 07:00:00+00', 8),

-- Staff
('a1000000-0000-0000-0000-000000000004',
 'anuj_uw', 'anuj.underwriter@policypilot.com', '9100000001', 'Anuj Sharma',
 'Anuj@uw2026', 'UW_OFFICER', 'ACTIVE', 0, FALSE,
 0, NULL, '2026-05-19 08:00:00+00', TRUE, TRUE, NULL,
 '2024-06-01 08:00:00+00', '2026-05-19 08:00:00+00', 12),

('a1000000-0000-0000-0000-000000000005',
 'suheal_claims', 'suheal.claims@policypilot.com', '9100000002', 'Suheal Khan',
 'Suheal@claims2026', 'CLAIMS_OFFICER', 'ACTIVE', 0, FALSE,
 0, NULL, '2026-05-19 08:15:00+00', TRUE, TRUE, NULL,
 '2024-06-01 08:00:00+00', '2026-05-19 08:15:00+00', 7),

('a1000000-0000-0000-0000-000000000006',
 'gowtham_agent', 'gowtham.agent@policypilot.com', '9100000003', 'Gowtham Ravi',
 'Gowtham@agent2026', 'AGENT', 'ACTIVE', 0, FALSE,
 0, NULL, '2026-05-19 08:30:00+00', TRUE, TRUE, NULL,
 '2024-06-01 08:00:00+00', '2026-05-19 08:30:00+00', 9),

('a1000000-0000-0000-0000-000000000007',
 'udbhav_finance', 'udbhav.finance@policypilot.com', '9100000004', 'Udbhav Mishra',
 'Udbhav@fin2026', 'FINANCE_OFFICER', 'ACTIVE', 0, FALSE,
 0, NULL, '2026-05-19 08:45:00+00', TRUE, TRUE, NULL,
 '2024-06-01 08:00:00+00', '2026-05-19 08:45:00+00', 6),

('a1000000-0000-0000-0000-000000000008',
 'hari_rm', 'hari.rm@policypilot.com', '9100000005', 'Hari Menon',
 'Hari@rm2026', 'RM', 'ACTIVE', 0, FALSE,
 0, NULL, '2026-05-19 09:00:00+00', TRUE, TRUE, NULL,
 '2024-06-01 08:00:00+00', '2026-05-19 09:00:00+00', 4),

('a1000000-0000-0000-0000-000000000009',
 'manav_field', 'manav.field@policypilot.com', '9100000006', 'Manav Singh',
 'Manav@field2026', 'FIELD_OFFICER', 'ACTIVE', 0, FALSE,
 0, NULL, '2026-05-19 09:15:00+00', TRUE, TRUE, NULL,
 '2024-06-01 08:00:00+00', '2026-05-19 09:15:00+00', 3),

('a1000000-0000-0000-0000-000000000010',
 'vignesh_iam', 'vignesh.iam@policypilot.com', '9100000007', 'Vignesh Kumar',
 'Vignesh@iam2026', 'IAM_ADMIN', 'ACTIVE', 0, FALSE,
 0, NULL, '2026-05-19 09:30:00+00', TRUE, TRUE, NULL,
 '2024-06-01 08:00:00+00', '2026-05-19 09:30:00+00', 1);


-- =============================================================
-- 2. customer_profiles
-- =============================================================
CREATE TABLE IF NOT EXISTS customer_profiles (
    id                      UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id                 UUID         NOT NULL,
    date_of_birth           DATE,
    gender                  VARCHAR(10),
    nationality             VARCHAR(50),
    passport_number         VARCHAR(20),
    passport_expiry_date    DATE,
    address_line1           VARCHAR(100),
    address_line2           VARCHAR(100),
    city                    VARCHAR(50),
    state_province          VARCHAR(50),
    postal_code             VARCHAR(15),
    country_code            VARCHAR(10),
    emergency_contact_name  VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    occupation              VARCHAR(50),
    annual_income_band      VARCHAR(50),
    created_at              TIMESTAMPTZ,
    updated_at              TIMESTAMPTZ,
    CONSTRAINT fk_customer_profiles_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE NO ACTION ON UPDATE NO ACTION
);

INSERT INTO customer_profiles (
    id, user_id, date_of_birth, gender, nationality,
    passport_number, passport_expiry_date,
    address_line1, address_line2, city, state_province, postal_code, country_code,
    emergency_contact_name, emergency_contact_phone,
    occupation, annual_income_band, created_at, updated_at
) VALUES
('b1000000-0000-0000-0000-000000000001',
 'a1000000-0000-0000-0000-000000000001',
 '1992-04-15', 'MALE', 'Indian', 'P98765432', '2031-04-14',
 '12 MG Road', 'Apt 3A', 'Bengaluru', 'Karnataka', '560001', 'IN',
 'Meena Rajan', '9876543000', 'Software Engineer', '75000-100000',
 '2025-01-10 08:05:00+00', '2025-01-10 08:05:00+00'),

('b1000000-0000-0000-0000-000000000002',
 'a1000000-0000-0000-0000-000000000002',
 '1995-08-22', 'FEMALE', 'Indian', 'P87651234', '2029-08-21',
 '45 Anna Salai', NULL, 'Chennai', 'Tamil Nadu', '600002', 'IN',
 'Suresh Nair', '9845000000', 'Marketing Manager', '50000-75000',
 '2025-03-15 10:05:00+00', '2025-03-15 10:05:00+00'),

('b1000000-0000-0000-0000-000000000003',
 'a1000000-0000-0000-0000-000000000003',
 '1980-11-30', 'MALE', 'Indian', 'P11334455', '2028-11-29',
 '789 Business Park', 'Block B', 'Mumbai', 'Maharashtra', '400001', 'IN',
 'Anjali Mehta', '9900000001', 'Business Director', '150000+',
 '2024-11-01 08:05:00+00', '2024-11-01 08:05:00+00');


-- =============================================================
-- 3. coverage_types
-- =============================================================
CREATE TABLE IF NOT EXISTS coverage_types (
    id                UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    coverage_code     VARCHAR(30),
    coverage_name     VARCHAR(100),
    coverage_category VARCHAR(50),
    description       TEXT,
    is_active         BOOLEAN,
    sort_order        INT,
    created_at        TIMESTAMPTZ
);

INSERT INTO coverage_types (id, coverage_code, coverage_name, coverage_category, description, is_active, sort_order, created_at) VALUES
('c1000000-0000-0000-0000-000000000001',
 'MED_EXP', 'Emergency Medical Expenses', 'MEDICAL',
 'Covers emergency medical treatment, hospitalisation and related expenses during the trip', TRUE, 1, '2024-01-01 00:00:00+00'),

('c1000000-0000-0000-0000-000000000002',
 'TRIP_CANCEL', 'Trip Cancellation', 'TRIP',
 'Reimburses non-refundable trip costs if trip is cancelled due to covered reasons', TRUE, 2, '2024-01-01 00:00:00+00'),

('c1000000-0000-0000-0000-000000000003',
 'BAG_LOSS', 'Baggage Loss & Damage', 'BAGGAGE',
 'Covers loss, theft or damage to checked and carry-on baggage', TRUE, 3, '2024-01-01 00:00:00+00'),

('c1000000-0000-0000-0000-000000000004',
 'EVAC', 'Emergency Evacuation', 'MEDICAL',
 'Covers emergency medical evacuation to the nearest adequate medical facility', TRUE, 4, '2024-01-01 00:00:00+00'),

('c1000000-0000-0000-0000-000000000005',
 'FLIGHT_DELAY', 'Flight Delay', 'TRIP',
 'Covers additional expenses (meals, accommodation) if flight is delayed beyond 4 hours', TRUE, 5, '2024-01-01 00:00:00+00'),

('c1000000-0000-0000-0000-000000000006',
 'PASSPORT_LOSS', 'Passport & Document Loss', 'TRAVEL',
 'Covers expenses for emergency replacement of passport or travel documents', TRUE, 6, '2024-01-01 00:00:00+00'),

('c1000000-0000-0000-0000-000000000007',
 'PERS_ACCIDENT', 'Personal Accident', 'ACCIDENT',
 'Provides compensation in case of accidental death or permanent disability during travel', TRUE, 7, '2024-01-01 00:00:00+00'),

('c1000000-0000-0000-0000-000000000008',
 'HOSP_ALLOWANCE', 'Daily Hospital Allowance', 'MEDICAL',
 'Daily cash benefit for each day of hospitalisation during the trip', TRUE, 8, '2024-01-01 00:00:00+00');


-- =============================================================
-- 4. addons
-- =============================================================
CREATE TABLE IF NOT EXISTS addons (
    id             UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    addon_code     VARCHAR(30),
    addon_name     VARCHAR(100),
    addon_category VARCHAR(50),
    description    TEXT,
    pricing_type   VARCHAR(30),
    pricing_value  NUMERIC(12,2),
    currency       VARCHAR(10),
    is_active      BOOLEAN,
    sort_order     INT,
    created_at     TIMESTAMPTZ,
    updated_at     TIMESTAMPTZ
);

INSERT INTO addons (id, addon_code, addon_name, addon_category, description, pricing_type, pricing_value, currency, is_active, sort_order, created_at, updated_at) VALUES
('d1000000-0000-0000-0000-000000000001',
 'ADVENTURE', 'Adventure Sports Cover', 'SPORTS',
 'Covers injuries from adventure activities - skiing, scuba diving, paragliding, bungee jumping and 50+ more',
 'FLAT', 500.00, 'INR', TRUE, 1, '2024-01-15 00:00:00+00', '2024-01-15 00:00:00+00'),

('d1000000-0000-0000-0000-000000000002',
 'RENTAL_CAR', 'Rental Car Protection', 'VEHICLE',
 'Collision damage waiver for rental vehicles during the trip',
 'FLAT', 400.00, 'INR', TRUE, 2, '2024-01-15 00:00:00+00', '2024-01-15 00:00:00+00'),

('d1000000-0000-0000-0000-000000000003',
 'BUSINESS_EQP', 'Business Equipment Cover', 'GADGET',
 'Covers laptops, cameras and business instruments up to defined limit',
 'FLAT', 600.00, 'INR', TRUE, 3, '2024-02-01 00:00:00+00', '2024-02-01 00:00:00+00'),

('d1000000-0000-0000-0000-000000000004',
 'HOME_BURGLARY', 'Home Burglary Cover', 'HOME',
 'Protects your home contents from burglary while you are travelling',
 'FLAT', 300.00, 'INR', TRUE, 4, '2024-02-01 00:00:00+00', '2024-02-01 00:00:00+00'),

('d1000000-0000-0000-0000-000000000005',
 'PRE_EXIST', 'Pre-existing Conditions Cover', 'MEDICAL',
 'Extended medical cover for declared pre-existing medical conditions',
 'FLAT', 800.00, 'INR', TRUE, 5, '2024-02-01 00:00:00+00', '2024-02-01 00:00:00+00');


-- =============================================================
-- 5. plans  (3 plans: Basic / Plus / Pro - matching webapp)
-- =============================================================
CREATE TABLE IF NOT EXISTS plans (
    id               UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    plan_code        VARCHAR(30)   NOT NULL,
    plan_name        VARCHAR(100),
    product_id       UUID,
    base_premium     NUMERIC(12,2),
    daily_rate       NUMERIC(12,2),
    currency         VARCHAR(10),
    min_trip_days    INT,
    max_trip_days    INT,
    min_traveler_age INT,
    max_traveler_age INT,
    max_travelers    INT,
    status           VARCHAR(30),
    version          INT,
    published_at     TIMESTAMPTZ,
    created_at       TIMESTAMPTZ,
    updated_at       TIMESTAMPTZ
);

INSERT INTO plans (id, plan_code, plan_name, product_id, base_premium, daily_rate, currency,
    min_trip_days, max_trip_days, min_traveler_age, max_traveler_age, max_travelers,
    status, version, published_at, created_at, updated_at) VALUES
-- PolicyPilot Basic
('e1000000-0000-0000-0000-000000000001',
 'PP_BASIC', 'PolicyPilot Basic', NULL,
 499.00, 150.00, 'INR', 1, 30, 18, 70, 6,
 'ACTIVE', 1, '2025-01-01 00:00:00+00', '2024-12-01 00:00:00+00', '2025-01-01 00:00:00+00'),

-- PolicyPilot Plus
('e1000000-0000-0000-0000-000000000002',
 'PP_PLUS', 'PolicyPilot Plus', NULL,
 999.00, 300.00, 'INR', 1, 60, 18, 75, 10,
 'ACTIVE', 1, '2025-01-01 00:00:00+00', '2024-12-01 00:00:00+00', '2025-01-01 00:00:00+00'),

-- PolicyPilot Pro
('e1000000-0000-0000-0000-000000000003',
 'PP_PRO', 'PolicyPilot Pro', NULL,
 1999.00, 550.00, 'INR', 1, 90, 18, 80, 15,
 'ACTIVE', 1, '2025-02-01 00:00:00+00', '2025-01-15 00:00:00+00', '2025-02-01 00:00:00+00');


-- =============================================================
-- 6. plan_coverages
-- =============================================================
CREATE TABLE IF NOT EXISTS plan_coverages (
    id               UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    plan_id          UUID          NOT NULL,
    coverage_type_id UUID          NOT NULL,
    min_limit        NUMERIC(12,2),
    max_limit        NUMERIC(12,2),
    default_limit    NUMERIC(12,2),
    limit_step       NUMERIC(12,2),
    currency         VARCHAR(10),
    deductible       NUMERIC(12,2),
    is_mandatory     BOOLEAN,
    is_adjustable    BOOLEAN,
    is_active        BOOLEAN,
    CONSTRAINT plan_coverages_plan_coverage_uq UNIQUE (plan_id, coverage_type_id),
    CONSTRAINT fk_plan_coverages_plan_id
        FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT fk_plan_coverages_coverage_type_id
        FOREIGN KEY (coverage_type_id) REFERENCES coverage_types(id) ON DELETE NO ACTION ON UPDATE NO ACTION
);

INSERT INTO plan_coverages (id, plan_id, coverage_type_id, min_limit, max_limit, default_limit, limit_step, currency, deductible, is_mandatory, is_adjustable, is_active) VALUES
-- PP_BASIC coverages
('f1000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000001', 'c1000000-0000-0000-0000-000000000001',
 500000.00, 2500000.00, 2500000.00, 500000.00, 'INR', 500.00, TRUE, TRUE, TRUE),

('f1000000-0000-0000-0000-000000000002', 'e1000000-0000-0000-0000-000000000001', 'c1000000-0000-0000-0000-000000000002',
 25000.00, 100000.00, 50000.00, 25000.00, 'INR', 0.00, TRUE, TRUE, TRUE),

('f1000000-0000-0000-0000-000000000003', 'e1000000-0000-0000-0000-000000000001', 'c1000000-0000-0000-0000-000000000003',
 10000.00, 50000.00, 25000.00, 10000.00, 'INR', 500.00, TRUE, TRUE, TRUE),

('f1000000-0000-0000-0000-000000000004', 'e1000000-0000-0000-0000-000000000001', 'c1000000-0000-0000-0000-000000000006',
 5000.00, 15000.00, 10000.00, 5000.00, 'INR', 0.00, TRUE, FALSE, TRUE),

('f1000000-0000-0000-0000-000000000005', 'e1000000-0000-0000-0000-000000000001', 'c1000000-0000-0000-0000-000000000007',
 500000.00, 1000000.00, 1000000.00, 500000.00, 'INR', 0.00, TRUE, FALSE, TRUE),

('f1000000-0000-0000-0000-000000000006', 'e1000000-0000-0000-0000-000000000001', 'c1000000-0000-0000-0000-000000000008',
 500.00, 1000.00, 500.00, 500.00, 'INR', 0.00, FALSE, FALSE, TRUE),

-- PP_PLUS coverages
('f1000000-0000-0000-0000-000000000007', 'e1000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000001',
 2500000.00, 7500000.00, 7500000.00, 2500000.00, 'INR', 250.00, TRUE, TRUE, TRUE),

('f1000000-0000-0000-0000-000000000008', 'e1000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000002',
 75000.00, 200000.00, 150000.00, 25000.00, 'INR', 0.00, TRUE, TRUE, TRUE),

('f1000000-0000-0000-0000-000000000009', 'e1000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000003',
 25000.00, 100000.00, 75000.00, 25000.00, 'INR', 250.00, TRUE, TRUE, TRUE),

('f1000000-0000-0000-0000-000000000010', 'e1000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000004',
 1000000.00, 3000000.00, 3000000.00, 1000000.00, 'INR', 0.00, TRUE, FALSE, TRUE),

('f1000000-0000-0000-0000-000000000011', 'e1000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000005',
 3000.00, 15000.00, 12000.00, 3000.00, 'INR', 0.00, TRUE, TRUE, TRUE),

('f1000000-0000-0000-0000-000000000012', 'e1000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000006',
 10000.00, 25000.00, 20000.00, 5000.00, 'INR', 0.00, TRUE, FALSE, TRUE),

('f1000000-0000-0000-0000-000000000013', 'e1000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000007',
 1500000.00, 3000000.00, 3000000.00, 500000.00, 'INR', 0.00, TRUE, FALSE, TRUE),

('f1000000-0000-0000-0000-000000000014', 'e1000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000008',
 1000.00, 2000.00, 1000.00, 500.00, 'INR', 0.00, TRUE, FALSE, TRUE),

-- PP_PRO coverages
('f1000000-0000-0000-0000-000000000015', 'e1000000-0000-0000-0000-000000000003', 'c1000000-0000-0000-0000-000000000001',
 5000000.00, 20000000.00, 20000000.00, 5000000.00, 'INR', 0.00, TRUE, TRUE, TRUE),

('f1000000-0000-0000-0000-000000000016', 'e1000000-0000-0000-0000-000000000003', 'c1000000-0000-0000-0000-000000000002',
 100000.00, 300000.00, 300000.00, 50000.00, 'INR', 0.00, TRUE, TRUE, TRUE),

('f1000000-0000-0000-0000-000000000017', 'e1000000-0000-0000-0000-000000000003', 'c1000000-0000-0000-0000-000000000003',
 50000.00, 200000.00, 200000.00, 50000.00, 'INR', 0.00, TRUE, TRUE, TRUE),

('f1000000-0000-0000-0000-000000000018', 'e1000000-0000-0000-0000-000000000003', 'c1000000-0000-0000-0000-000000000004',
 5000000.00, 10000000.00, 10000000.00, 5000000.00, 'INR', 0.00, TRUE, FALSE, TRUE),

('f1000000-0000-0000-0000-000000000019', 'e1000000-0000-0000-0000-000000000003', 'c1000000-0000-0000-0000-000000000005',
 5000.00, 30000.00, 25000.00, 5000.00, 'INR', 0.00, TRUE, TRUE, TRUE),

('f1000000-0000-0000-0000-000000000020', 'e1000000-0000-0000-0000-000000000003', 'c1000000-0000-0000-0000-000000000006',
 20000.00, 50000.00, 40000.00, 10000.00, 'INR', 0.00, TRUE, FALSE, TRUE),

('f1000000-0000-0000-0000-000000000021', 'e1000000-0000-0000-0000-000000000003', 'c1000000-0000-0000-0000-000000000007',
 5000000.00, 10000000.00, 10000000.00, 5000000.00, 'INR', 0.00, TRUE, FALSE, TRUE),

('f1000000-0000-0000-0000-000000000022', 'e1000000-0000-0000-0000-000000000003', 'c1000000-0000-0000-0000-000000000008',
 2000.00, 5000.00, 2500.00, 500.00, 'INR', 0.00, TRUE, FALSE, TRUE);


-- =============================================================
-- 7. plan_addon_mappings
-- =============================================================
CREATE TABLE IF NOT EXISTS plan_addon_mappings (
    id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    plan_id    UUID        NOT NULL,
    addon_id   UUID        NOT NULL,
    is_active  BOOLEAN,
    created_at TIMESTAMPTZ,
    CONSTRAINT plan_addon_mappings_plan_addon_uq UNIQUE (plan_id, addon_id),
    CONSTRAINT fk_plan_addon_mappings_plan_id
        FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT fk_plan_addon_mappings_addon_id
        FOREIGN KEY (addon_id) REFERENCES addons(id) ON DELETE NO ACTION ON UPDATE NO ACTION
);

INSERT INTO plan_addon_mappings (id, plan_id, addon_id, is_active, created_at) VALUES
-- Basic: Adventure, Rental Car
('aa000000-0000-0000-0000-000000000001', 'e1000000-0000-0000-0000-000000000001', 'd1000000-0000-0000-0000-000000000001', TRUE, '2025-01-01 00:00:00+00'),
('aa000000-0000-0000-0000-000000000002', 'e1000000-0000-0000-0000-000000000001', 'd1000000-0000-0000-0000-000000000002', TRUE, '2025-01-01 00:00:00+00'),
-- Plus: Adventure, Rental, Business Equip, Home Burglary
('aa000000-0000-0000-0000-000000000003', 'e1000000-0000-0000-0000-000000000002', 'd1000000-0000-0000-0000-000000000001', TRUE, '2025-01-01 00:00:00+00'),
('aa000000-0000-0000-0000-000000000004', 'e1000000-0000-0000-0000-000000000002', 'd1000000-0000-0000-0000-000000000002', TRUE, '2025-01-01 00:00:00+00'),
('aa000000-0000-0000-0000-000000000005', 'e1000000-0000-0000-0000-000000000002', 'd1000000-0000-0000-0000-000000000003', TRUE, '2025-01-01 00:00:00+00'),
('aa000000-0000-0000-0000-000000000006', 'e1000000-0000-0000-0000-000000000002', 'd1000000-0000-0000-0000-000000000004', TRUE, '2025-01-01 00:00:00+00'),
-- Pro: All addons
('aa000000-0000-0000-0000-000000000007', 'e1000000-0000-0000-0000-000000000003', 'd1000000-0000-0000-0000-000000000001', TRUE, '2025-02-01 00:00:00+00'),
('aa000000-0000-0000-0000-000000000008', 'e1000000-0000-0000-0000-000000000003', 'd1000000-0000-0000-0000-000000000002', TRUE, '2025-02-01 00:00:00+00'),
('aa000000-0000-0000-0000-000000000009', 'e1000000-0000-0000-0000-000000000003', 'd1000000-0000-0000-0000-000000000003', TRUE, '2025-02-01 00:00:00+00'),
('aa000000-0000-0000-0000-000000000010', 'e1000000-0000-0000-0000-000000000003', 'd1000000-0000-0000-0000-000000000004', TRUE, '2025-02-01 00:00:00+00'),
('aa000000-0000-0000-0000-000000000011', 'e1000000-0000-0000-0000-000000000003', 'd1000000-0000-0000-0000-000000000005', TRUE, '2025-02-01 00:00:00+00');


-- =============================================================
-- 8. policies
-- =============================================================
CREATE TABLE IF NOT EXISTS policies (
    id                       UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_number            VARCHAR(50)   NOT NULL,
    quote_id                 UUID,
    customer_id              UUID          NOT NULL,
    product_id               UUID,
    plan_id                  UUID          NOT NULL,
    destination_country_code VARCHAR(10),
    destination_zone_id      UUID,
    trip_start_date          DATE          NOT NULL,
    trip_end_date            DATE          NOT NULL,
    num_travelers            INT,
    trip_purpose             VARCHAR(50),
    total_premium            NUMERIC(12,2),
    currency                 VARCHAR(10),
    risk_score               NUMERIC(5,2),
    risk_level               VARCHAR(20),
    status                   VARCHAR(30),
    issue_date               TIMESTAMPTZ,
    expiry_date              DATE,
    parent_policy_id         UUID,
    renewal_count            INT,
    cancellation_reason      VARCHAR(255),
    created_at               TIMESTAMPTZ,
    updated_at               TIMESTAMPTZ,
    version                  BIGINT,
    CONSTRAINT chk_trip_dates CHECK (trip_end_date >= trip_start_date),
    CONSTRAINT fk_policies_customer_id
        FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT fk_policies_plan_id
        FOREIGN KEY (plan_id) REFERENCES plans(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT fk_policies_parent_policy_id
        FOREIGN KEY (parent_policy_id) REFERENCES policies(id) ON DELETE NO ACTION ON UPDATE NO ACTION
);

INSERT INTO policies (id, policy_number, quote_id, customer_id, product_id, plan_id,
    destination_country_code, destination_zone_id, trip_start_date, trip_end_date,
    num_travelers, trip_purpose, total_premium, currency, risk_score, risk_level,
    status, issue_date, expiry_date, parent_policy_id, renewal_count,
    cancellation_reason, created_at, updated_at, version) VALUES
('ab000000-0000-0000-0000-000000000001',
 'POL-2026-000001', NULL,
 'a1000000-0000-0000-0000-000000000001', NULL,
 'e1000000-0000-0000-0000-000000000001',
 'FR', NULL, '2026-06-01', '2026-06-08', 2, 'LEISURE',
 2248.50, 'INR', 3.50, 'MEDIUM', 'ACTIVE',
 '2026-05-10 10:00:00+00', '2026-06-08', NULL, 0, NULL,
 '2026-05-10 09:00:00+00', '2026-05-10 10:00:00+00', 1),

('ab000000-0000-0000-0000-000000000002',
 'POL-2026-000002', NULL,
 'a1000000-0000-0000-0000-000000000002', NULL,
 'e1000000-0000-0000-0000-000000000002',
 'JP', NULL, '2026-07-10', '2026-07-20', 1, 'LEISURE',
 5489.00, 'INR', 3.50, 'MEDIUM', 'ACTIVE',
 '2026-05-15 11:00:00+00', '2026-07-20', NULL, 0, NULL,
 '2026-05-15 10:00:00+00', '2026-05-15 11:00:00+00', 1),

('ab000000-0000-0000-0000-000000000003',
 'POL-2026-000003', NULL,
 'a1000000-0000-0000-0000-000000000003', NULL,
 'e1000000-0000-0000-0000-000000000003',
 'DE', NULL, '2026-08-01', '2026-08-15', 2, 'BUSINESS',
 15840.00, 'INR', 6.50, 'HIGH', 'PENDING_UW',
 NULL, '2026-08-15', NULL, 0, NULL,
 '2026-05-18 13:00:00+00', '2026-05-18 14:00:00+00', 1);


-- =============================================================
-- 9. policy_versions
-- =============================================================
CREATE TABLE IF NOT EXISTS policy_versions (
    id             UUID    PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_id      UUID    NOT NULL,
    version_number INT,
    data_snapshot  JSONB,
    created_at     TIMESTAMPTZ,
    CONSTRAINT fk_policy_versions_policy_id
        FOREIGN KEY (policy_id) REFERENCES policies(id) ON DELETE NO ACTION ON UPDATE NO ACTION
);

INSERT INTO policy_versions (id, policy_id, version_number, data_snapshot, created_at) VALUES
('ac000000-0000-0000-0000-000000000001',
 'ab000000-0000-0000-0000-000000000001', 1,
 '{"policy_number":"POL-2026-000001","status":"ACTIVE","total_premium":2248.50}',
 '2026-05-10 10:00:00+00'),

('ac000000-0000-0000-0000-000000000002',
 'ab000000-0000-0000-0000-000000000002', 1,
 '{"policy_number":"POL-2026-000002","status":"ACTIVE","total_premium":5489.00}',
 '2026-05-15 11:00:00+00'),

('ac000000-0000-0000-0000-000000000003',
 'ab000000-0000-0000-0000-000000000003', 1,
 '{"policy_number":"POL-2026-000003","status":"PENDING_UW","total_premium":15840.00}',
 '2026-05-18 14:00:00+00');


-- =============================================================
-- 10. payments
-- =============================================================
CREATE TABLE IF NOT EXISTS payments (
    id                UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_id         UUID          NOT NULL,
    claim_id          UUID,
    payment_reference VARCHAR(50)   NOT NULL,
    amount            NUMERIC(12,2),
    currency          VARCHAR(10),
    payment_type      VARCHAR(30)   DEFAULT 'PREMIUM_RECEIVED',
    status            VARCHAR(30),
    paid_at           TIMESTAMPTZ,
    created_at        TIMESTAMPTZ,
    CONSTRAINT fk_payments_policy_id
        FOREIGN KEY (policy_id) REFERENCES policies(id) ON DELETE NO ACTION ON UPDATE NO ACTION
    -- claim_id FK added after claims table is created (see ALTER TABLE below)
);

INSERT INTO payments (id, policy_id, claim_id, payment_reference, amount, currency, payment_type, status, paid_at, created_at) VALUES
('ad000000-0000-0000-0000-000000000001',
 'ab000000-0000-0000-0000-000000000001',
 NULL, 'PAY-2026-000001', 2248.50, 'INR', 'PREMIUM_RECEIVED', 'COMPLETED',
 '2026-05-10 10:05:00+00', '2026-05-10 09:30:00+00'),

('ad000000-0000-0000-0000-000000000002',
 'ab000000-0000-0000-0000-000000000002',
 NULL, 'PAY-2026-000002', 5489.00, 'INR', 'PREMIUM_RECEIVED', 'COMPLETED',
 '2026-05-15 11:10:00+00', '2026-05-15 10:45:00+00');


-- =============================================================
-- 11. underwriting_cases
-- =============================================================
CREATE TABLE IF NOT EXISTS underwriting_cases (
    id                      UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    case_reference          VARCHAR(50),
    policy_id               UUID          NOT NULL,
    customer_id             UUID          NOT NULL,
    risk_score              NUMERIC(5,2),
    risk_level              VARCHAR(20),
    uw_level                SMALLINT,
    current_state           VARCHAR(30),
    assigned_to_user_id     UUID,
    assigned_by_user_id     UUID,
    assigned_at             TIMESTAMPTZ,
    sla_hours               INT,
    sla_due_at              TIMESTAMPTZ,
    sla_breached            BOOLEAN,
    is_locked               BOOLEAN,
    locked_by               UUID,
    locked_at               TIMESTAMPTZ,
    premium_loading_percent NUMERIC(5,2),
    final_premium           NUMERIC(12,2),
    is_active               BOOLEAN,
    created_at              TIMESTAMPTZ,
    updated_at              TIMESTAMPTZ,
    version                 BIGINT,
    CONSTRAINT fk_uw_cases_policy_id
        FOREIGN KEY (policy_id) REFERENCES policies(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT fk_uw_cases_customer_id
        FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT fk_uw_cases_assigned_to
        FOREIGN KEY (assigned_to_user_id) REFERENCES users(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT fk_uw_cases_assigned_by
        FOREIGN KEY (assigned_by_user_id) REFERENCES users(id) ON DELETE NO ACTION ON UPDATE NO ACTION
);

INSERT INTO underwriting_cases (id, case_reference, policy_id, customer_id,
    risk_score, risk_level, uw_level, current_state,
    assigned_to_user_id, assigned_by_user_id, assigned_at,
    sla_hours, sla_due_at, sla_breached, is_locked, locked_by, locked_at,
    premium_loading_percent, final_premium, is_active, created_at, updated_at, version) VALUES
('ae000000-0000-0000-0000-000000000001',
 'UWC-2026-000001',
 'ab000000-0000-0000-0000-000000000003',
 'a1000000-0000-0000-0000-000000000003',
 6.50, 'HIGH', 2, 'PENDING_REVIEW',
 'a1000000-0000-0000-0000-000000000004',
 'a1000000-0000-0000-0000-000000000004',
 '2026-05-18 15:00:00+00',
 48, '2026-05-20 15:00:00+00', FALSE,
 FALSE, NULL, NULL,
 0.00, 15840.00, TRUE,
 '2026-05-18 14:30:00+00', '2026-05-18 15:05:00+00', 1);


-- =============================================================
-- 12. claim_types  (linked to coverage types for addon-aware claims)
-- =============================================================
CREATE TABLE IF NOT EXISTS claim_types (
    id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    code              VARCHAR(30),
    name              VARCHAR(100),
    description       TEXT,
    coverage_type_id  UUID,
    default_sla_hours INT,
    is_active         BOOLEAN,
    created_at        TIMESTAMPTZ,
    updated_at        TIMESTAMPTZ,
    CONSTRAINT fk_claim_types_coverage_type_id
        FOREIGN KEY (coverage_type_id) REFERENCES coverage_types(id) ON DELETE NO ACTION ON UPDATE NO ACTION
);

INSERT INTO claim_types (id, code, name, description, coverage_type_id, default_sla_hours, is_active, created_at, updated_at) VALUES
('af000000-0000-0000-0000-000000000001',
 'MED_CLAIM', 'Medical Claim',
 'Claim for emergency medical expenses incurred during the trip',
 'c1000000-0000-0000-0000-000000000001', 72, TRUE, '2024-01-01 00:00:00+00', '2024-01-01 00:00:00+00'),

('af000000-0000-0000-0000-000000000002',
 'CANCEL_CLAIM', 'Trip Cancellation Claim',
 'Claim for reimbursement of non-refundable trip costs',
 'c1000000-0000-0000-0000-000000000002', 96, TRUE, '2024-01-01 00:00:00+00', '2024-01-01 00:00:00+00'),

('af000000-0000-0000-0000-000000000003',
 'BAG_CLAIM', 'Baggage Claim',
 'Claim for lost, stolen or damaged baggage',
 'c1000000-0000-0000-0000-000000000003', 48, TRUE, '2024-01-01 00:00:00+00', '2024-01-01 00:00:00+00'),

('af000000-0000-0000-0000-000000000004',
 'EVAC_CLAIM', 'Emergency Evacuation Claim',
 'Claim for emergency medical evacuation costs',
 'c1000000-0000-0000-0000-000000000004', 24, TRUE, '2024-01-01 00:00:00+00', '2024-01-01 00:00:00+00'),

('af000000-0000-0000-0000-000000000005',
 'DELAY_CLAIM', 'Flight Delay Claim',
 'Claim for additional expenses due to flight delay beyond 4 hours',
 'c1000000-0000-0000-0000-000000000005', 48, TRUE, '2024-01-01 00:00:00+00', '2024-01-01 00:00:00+00'),

('af000000-0000-0000-0000-000000000006',
 'PASSPORT_CLAIM', 'Passport Loss Claim',
 'Claim for emergency passport replacement expenses',
 'c1000000-0000-0000-0000-000000000006', 48, TRUE, '2024-01-01 00:00:00+00', '2024-01-01 00:00:00+00'),

('af000000-0000-0000-0000-000000000007',
 'ACCIDENT_CLAIM', 'Personal Accident Claim',
 'Claim for accidental death or permanent disability during travel',
 'c1000000-0000-0000-0000-000000000007', 120, TRUE, '2024-01-01 00:00:00+00', '2024-01-01 00:00:00+00'),

-- Addon-specific claim types
('af000000-0000-0000-0000-000000000008',
 'ADVENTURE_CLAIM', 'Adventure Sports Injury Claim',
 'Claim for injuries sustained during adventure sports activities',
 NULL, 72, TRUE, '2024-01-01 00:00:00+00', '2024-01-01 00:00:00+00'),

('af000000-0000-0000-0000-000000000009',
 'RENTAL_CLAIM', 'Rental Car Damage Claim',
 'Claim for damage to rental vehicle during trip',
 NULL, 72, TRUE, '2024-01-01 00:00:00+00', '2024-01-01 00:00:00+00'),

('af000000-0000-0000-0000-000000000010',
 'EQUIP_CLAIM', 'Business Equipment Claim',
 'Claim for loss or damage to business equipment',
 NULL, 72, TRUE, '2024-01-01 00:00:00+00', '2024-01-01 00:00:00+00'),

('af000000-0000-0000-0000-000000000011',
 'HOME_CLAIM', 'Home Burglary Claim',
 'Claim for home contents stolen while travelling',
 NULL, 96, TRUE, '2024-01-01 00:00:00+00', '2024-01-01 00:00:00+00'),

('af000000-0000-0000-0000-000000000012',
 'PREEXIST_CLAIM', 'Pre-existing Condition Claim',
 'Claim for medical expenses related to declared pre-existing conditions',
 NULL, 96, TRUE, '2024-01-01 00:00:00+00', '2024-01-01 00:00:00+00');


-- =============================================================
-- 13. claims
-- =============================================================
CREATE TABLE IF NOT EXISTS claims (
    id                           UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    claim_reference              VARCHAR(50)   NOT NULL,
    policy_id                    UUID          NOT NULL,
    customer_id                  UUID          NOT NULL,
    claim_type_id                UUID          NOT NULL,
    status                       VARCHAR(30),
    incident_date                DATE,
    incident_description         TEXT,
    claimed_amount               NUMERIC(12,2) NOT NULL,
    approved_amount              NUMERIC(12,2),
    assigned_officer_id          UUID,
    decided_by                   UUID,
    decision_reason              TEXT,
    decided_at                   TIMESTAMPTZ,
    is_high_value                BOOLEAN,
    field_investigation_required BOOLEAN,
    created_at                   TIMESTAMPTZ,
    updated_at                   TIMESTAMPTZ,
    version                      BIGINT,
    CONSTRAINT chk_approved_amount CHECK (approved_amount IS NULL OR approved_amount <= claimed_amount),
    CONSTRAINT fk_claims_policy_id
        FOREIGN KEY (policy_id) REFERENCES policies(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT fk_claims_customer_id
        FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT fk_claims_claim_type_id
        FOREIGN KEY (claim_type_id) REFERENCES claim_types(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT fk_claims_assigned_officer_id
        FOREIGN KEY (assigned_officer_id) REFERENCES users(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT fk_claims_decided_by
        FOREIGN KEY (decided_by) REFERENCES users(id) ON DELETE NO ACTION ON UPDATE NO ACTION
);

-- Add payments->claims FK now that claims table exists
ALTER TABLE payments
    ADD CONSTRAINT fk_payments_claim_id
        FOREIGN KEY (claim_id) REFERENCES claims(id) ON DELETE NO ACTION ON UPDATE NO ACTION;

INSERT INTO claims (id, claim_reference, policy_id, customer_id, claim_type_id,
    status, incident_date, incident_description, claimed_amount, approved_amount,
    assigned_officer_id, decided_by, decision_reason, decided_at,
    is_high_value, field_investigation_required, created_at, updated_at, version) VALUES
('ba000000-0000-0000-0000-000000000001',
 'CLM-2026-000001',
 'ab000000-0000-0000-0000-000000000001',
 'a1000000-0000-0000-0000-000000000001',
 'af000000-0000-0000-0000-000000000001',
 'APPROVED', '2026-06-05',
 'Emergency hospital visit for fracture after accidental fall.',
 18000.00, 16500.00,
 'a1000000-0000-0000-0000-000000000005',
 'a1000000-0000-0000-0000-000000000005',
 'Claim approved. Non-covered pharmacy charges of Rs 1500 deducted.',
 '2026-06-10 12:00:00+00',
 FALSE, FALSE, '2026-06-06 09:00:00+00', '2026-06-10 12:00:00+00', 3),

('ba000000-0000-0000-0000-000000000002',
 'CLM-2026-000002',
 'ab000000-0000-0000-0000-000000000002',
 'a1000000-0000-0000-0000-000000000002',
 'af000000-0000-0000-0000-000000000003',
 'SUBMITTED', '2026-07-12',
 'Checked baggage delayed by 36 hours on outbound flight to Japan.',
 12000.00, NULL,
 'a1000000-0000-0000-0000-000000000005',
 NULL, NULL, NULL,
 FALSE, FALSE, '2026-07-13 10:00:00+00', '2026-07-13 10:00:00+00', 1);


-- =============================================================
-- 14. claim_status_history
-- =============================================================
CREATE TABLE IF NOT EXISTS claim_status_history (
    id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    claim_id   UUID        NOT NULL,
    status     VARCHAR(30),
    changed_by UUID,
    changed_at TIMESTAMPTZ,
    remarks    TEXT,
    CONSTRAINT fk_claim_status_history_claim_id
        FOREIGN KEY (claim_id) REFERENCES claims(id) ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT fk_claim_status_history_changed_by
        FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE NO ACTION ON UPDATE NO ACTION
);

INSERT INTO claim_status_history (id, claim_id, status, changed_by, changed_at, remarks) VALUES
('bb000000-0000-0000-0000-000000000001',
 'ba000000-0000-0000-0000-000000000001',
 'SUBMITTED', 'a1000000-0000-0000-0000-000000000001',
 '2026-06-06 09:00:00+00', 'Claim submitted by customer.'),

('bb000000-0000-0000-0000-000000000002',
 'ba000000-0000-0000-0000-000000000001',
 'IN_REVIEW', 'a1000000-0000-0000-0000-000000000005',
 '2026-06-07 10:00:00+00', 'Assigned to claims officer for review.'),

('bb000000-0000-0000-0000-000000000003',
 'ba000000-0000-0000-0000-000000000001',
 'APPROVED', 'a1000000-0000-0000-0000-000000000005',
 '2026-06-10 12:00:00+00', 'Approved with deduction for non-covered items.'),

('bb000000-0000-0000-0000-000000000004',
 'ba000000-0000-0000-0000-000000000002',
 'SUBMITTED', 'a1000000-0000-0000-0000-000000000002',
 '2026-07-13 10:00:00+00', 'Baggage delay claim submitted.');


-- =============================================================
-- 15. notifications
-- =============================================================
CREATE TABLE IF NOT EXISTS notifications (
    id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    notification_ref  VARCHAR(50),
    user_id           UUID        NOT NULL,
    title             VARCHAR(100),
    message           TEXT,
    notification_type VARCHAR(30),
    is_read           BOOLEAN,
    read_at           TIMESTAMPTZ,
    delivery_channel  VARCHAR(30),
    delivery_status   VARCHAR(30),
    created_at        TIMESTAMPTZ,
    CONSTRAINT fk_notifications_user_id
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE NO ACTION ON UPDATE NO ACTION
);

INSERT INTO notifications (id, notification_ref, user_id, title, message, notification_type, is_read, read_at, delivery_channel, delivery_status, created_at) VALUES
('bc000000-0000-0000-0000-000000000001',
 'NTF-2026-000001', 'a1000000-0000-0000-0000-000000000001',
 'Policy Issued',
 'Your policy POL-2026-000001 is now ACTIVE. Coverage starts 2026-06-01.',
 'POLICY_ISSUED', TRUE, '2026-05-10 11:00:00+00', 'EMAIL', 'DELIVERED',
 '2026-05-10 10:05:00+00'),

('bc000000-0000-0000-0000-000000000002',
 'NTF-2026-000002', 'a1000000-0000-0000-0000-000000000001',
 'Claim Approved',
 'Your claim CLM-2026-000001 has been approved. Settlement: INR 16,500. Finance will process payout shortly.',
 'CLAIM_DECISION', FALSE, NULL, 'EMAIL', 'DELIVERED',
 '2026-06-10 12:05:00+00');


-- =============================================================
-- 16. audit_logs
-- =============================================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id               BIGINT      PRIMARY KEY,
    event_time       TIMESTAMPTZ,
    request_id       VARCHAR(50),
    service_name     VARCHAR(50),
    action           VARCHAR(50),
    actor_user_id    UUID,
    actor_ip         INET,
    entity_name      VARCHAR(50),
    entity_id        UUID,
    entity_reference VARCHAR(50),
    result           VARCHAR(20),
    failure_reason   TEXT,
    CONSTRAINT fk_audit_logs_actor_user_id
        FOREIGN KEY (actor_user_id) REFERENCES users(id) ON DELETE NO ACTION ON UPDATE NO ACTION
);

INSERT INTO audit_logs (id, event_time, request_id, service_name, action, actor_user_id, actor_ip, entity_name, entity_id, entity_reference, result, failure_reason) VALUES
(1, '2026-05-10 09:00:00+00', 'REQ-0001', 'policy-service', 'CREATE_POLICY',
 'a1000000-0000-0000-0000-000000000001', '192.168.1.101',
 'policies', 'ab000000-0000-0000-0000-000000000001', 'POL-2026-000001', 'SUCCESS', NULL),

(2, '2026-05-10 10:05:00+00', 'REQ-0002', 'payment-service', 'PROCESS_PAYMENT',
 'a1000000-0000-0000-0000-000000000001', '192.168.1.101',
 'payments', 'ad000000-0000-0000-0000-000000000001', 'PAY-2026-000001', 'SUCCESS', NULL),

(3, '2026-05-15 10:00:00+00', 'REQ-0003', 'policy-service', 'CREATE_POLICY',
 'a1000000-0000-0000-0000-000000000002', '10.0.0.55',
 'policies', 'ab000000-0000-0000-0000-000000000002', 'POL-2026-000002', 'SUCCESS', NULL);

-- =============================================================
-- END OF SCRIPT
-- =============================================================
