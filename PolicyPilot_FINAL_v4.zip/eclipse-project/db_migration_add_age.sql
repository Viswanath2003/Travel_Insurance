-- ============================================================
--  MIGRATION: Run this ONLY if you already have existing data
--  and don't want to drop/recreate tables.
--  Safe to run on existing data -- defaults to 0 for old rows.
-- ============================================================

ALTER TABLE users ADD COLUMN IF NOT EXISTS age INT DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_default_password BOOLEAN DEFAULT FALSE;
ALTER TABLE policies ADD COLUMN IF NOT EXISTS cancellation_reason VARCHAR(255);
ALTER TABLE payments ADD COLUMN IF NOT EXISTS claim_id UUID;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS payment_type VARCHAR(30) DEFAULT 'PREMIUM_RECEIVED';

-- Add FK for payments->claims after both tables exist
ALTER TABLE payments DROP CONSTRAINT IF EXISTS fk_payments_claim_id;
ALTER TABLE payments
    ADD CONSTRAINT fk_payments_claim_id
        FOREIGN KEY (claim_id) REFERENCES claims(id) ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Update existing seed users with correct ages
UPDATE users SET age = 33 WHERE username = 'shankar_rajan';
UPDATE users SET age = 30 WHERE username = 'priya_nair';
UPDATE users SET age = 45 WHERE username = 'rahul_mehta';

-- Verify
SELECT username, full_name, role, age, is_default_password FROM users ORDER BY role, full_name;
